import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';

class Ristriction extends StatelessWidget {
  const Ristriction({
    Key key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 23.0, end: 23.0),
            Pin(size: 186.0, middle: 0.5128),
            child: Stack(
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xffecf9fe),
                    borderRadius: BorderRadius.circular(17.0),
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 22.0, end: 21.0),
                  Pin(size: 21.0, start: 18.0),
                  child: const Text(
                    'Only member allowed to use the feature',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 16,
                      color: Color(0xff004c98),
                      fontWeight: FontWeight.w700,
                    ),
                    softWrap: false,
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 42.0, end: 41.0),
                  Pin(size: 19.0, middle: 0.2575),
                  child: const Text(
                    'To become a member please click here',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 14,
                      color: Color(0xff004c98),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 86.0, end: 43.0),
                  Pin(size: 32.0, end: 15.0),
                  child: Stack(
                    children: <Widget>[
                      Container(
                        decoration: BoxDecoration(
                          color: const Color(0xff004c98),
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                      const Center(
                        child: SizedBox(
                          width: 50.0,
                          height: 16.0,
                          child: Text(
                            'Join Now',
                            style: TextStyle(
                              fontFamily: 'Roboto',
                              fontSize: 12,
                              color: Color(0xffffffff),
                              fontWeight: FontWeight.w700,
                            ),
                            softWrap: false,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const Align(
                  alignment: Alignment(-0.016, 0.114),
                  child: SizedBox(
                    width: 201.0,
                    height: 19.0,
                    child: Text(
                      'EXCLUSIVE MEMBER BENEFITS',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 14,
                        color: Color(0xff2f302f),
                        fontWeight: FontWeight.w700,
                      ),
                      softWrap: false,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
