import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import './MemberHome.dart';
import 'package:adobe_xd/page_link.dart';
import './About.dart';
import './ExclusiveMembership.dart';
import 'package:flutter_svg/flutter_svg.dart';

class Menu extends StatelessWidget {
  const Menu({
    Key key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              color: const Color(0xed2f302f),
              borderRadius: BorderRadius.circular(27.0),
            ),
            margin: const EdgeInsets.fromLTRB(26.0, 78.0, 34.0, 31.0),
          ),
          Pinned.fromPins(
            Pin(size: 212.0, start: 50.0),
            Pin(size: 39.0, end: 105.0),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(20.0),
                border: Border.all(width: 1.0, color: Colors.transparent),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 49.0, middle: 0.8037),
            Pin(size: 19.0, end: 54.0),
            child: const Text(
              'Log Out',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 14,
                color: Color(0xfffcfcfc),
                height: 3.857142857142857,
              ),
              textHeightBehavior:
                  TextHeightBehavior(applyHeightToFirstAscent: false),
              softWrap: false,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 67.0, middle: 0.5422),
            Pin(size: 19.0, start: 110.0),
            child: const Text(
              'Username ',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 14,
                color: Color(0xfffcfcfc),
                height: 3.857142857142857,
              ),
              textHeightBehavior:
                  TextHeightBehavior(applyHeightToFirstAscent: false),
              softWrap: false,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 58.0, middle: 0.7981),
            Pin(size: 58.0, start: 90.0),
            child: Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(''),
                  fit: BoxFit.cover,
                ),
                borderRadius:
                    BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
              ),
            ),
          ),
          Container(),
          Pinned.fromPins(
            Pin(size: 212.0, start: 50.0),
            Pin(size: 39.0, middle: 0.1915),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => const MemberHome(),
                ),
              ],
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(20.0),
                  border: Border.all(width: 1.0, color: Colors.transparent),
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 212.0, start: 50.0),
            Pin(size: 39.0, middle: 0.6624),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(20.0),
                border: Border.all(width: 1.0, color: Colors.transparent),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 212.0, start: 50.0),
            Pin(size: 39.0, middle: 0.2587),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => const About(),
                ),
              ],
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(20.0),
                  border: Border.all(width: 1.0, color: Colors.transparent),
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 212.0, start: 50.0),
            Pin(size: 39.0, middle: 0.7296),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(20.0),
                border: Border.all(width: 1.0, color: Colors.transparent),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 212.0, start: 50.0),
            Pin(size: 39.0, middle: 0.326),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => const ExclusiveMembership(),
                ),
              ],
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(20.0),
                  border: Border.all(width: 1.0, color: Colors.transparent),
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 212.0, start: 50.0),
            Pin(size: 39.0, middle: 0.7969),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(20.0),
                border: Border.all(width: 1.0, color: Colors.transparent),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 212.0, start: 50.0),
            Pin(size: 39.0, middle: 0.3933),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(20.0),
                border: Border.all(width: 1.0, color: Colors.transparent),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 212.0, start: 50.0),
            Pin(size: 39.0, middle: 0.4605),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(20.0),
                border: Border.all(width: 1.0, color: Colors.transparent),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 212.0, start: 50.0),
            Pin(size: 39.0, middle: 0.5278),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(20.0),
                border: Border.all(width: 1.0, color: Colors.transparent),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 212.0, start: 50.0),
            Pin(size: 39.0, middle: 0.5951),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(20.0),
                border: Border.all(width: 1.0, color: Colors.transparent),
              ),
            ),
          ),
          const Align(
            alignment: Alignment(-0.033, 0.131),
            child: SizedBox(
              width: 135.0,
              height: 529.0,
              child: Text.rich(
                TextSpan(
                  style: TextStyle(
                    fontFamily: 'Roboto',
                    fontSize: 14,
                    color: Color(0xfffcfcfc),
                    height: 3.642857142857143,
                  ),
                  children: [
                    TextSpan(
                      text:
                          'HOME\nABOUT US\nMEMBERSHIP\nSERVICES\nPOLICY & ADVOCACY\nEVENTS\nNEWS\nCONTACT US\nADVERTISE\nFAVOURITES\n',
                    ),
                    TextSpan(
                      text: 'Purchase',
                    ),
                  ],
                ),
                textHeightBehavior:
                    TextHeightBehavior(applyHeightToFirstAscent: false),
                softWrap: false,
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 28.5, middle: 0.1991),
            Pin(size: 545.0, end: 114.1),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 2.0, end: 1.1),
                  Pin(size: 23.1, start: 0.0),
                  child: SvgPicture.string(
                    _svg_k3hyvs,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 2.0, end: 1.1),
                  Pin(size: 25.4, start: 50.3),
                  child: Stack(
                    children: <Widget>[
                      Stack(
                        children: <Widget>[
                          SizedBox.expand(
                              child: SvgPicture.string(
                            _svg_gmfkkg,
                            allowDrawingOutsideViewBox: true,
                            fit: BoxFit.fill,
                          )),
                          Container(
                            color: const Color(0xffffffff),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 2.0, end: 1.1),
                  Pin(size: 22.3, middle: 0.1971),
                  child: Stack(
                    children: <Widget>[
                      Stack(
                        children: <Widget>[
                          Align(
                            alignment: Alignment.bottomLeft,
                            child: SizedBox(
                              width: 20.0,
                              height: 18.0,
                              child: SvgPicture.string(
                                _svg_b4y4ty,
                                allowDrawingOutsideViewBox: true,
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.bottomRight,
                            child: SizedBox(
                              width: 16.0,
                              height: 11.0,
                              child: SvgPicture.string(
                                _svg_eb2cs,
                                allowDrawingOutsideViewBox: true,
                              ),
                            ),
                          ),
                          Align(
                            alignment: const Alignment(-0.19, -1.0),
                            child: SizedBox(
                              width: 9.0,
                              height: 4.0,
                              child: SvgPicture.string(
                                _svg_a8ijd2,
                                allowDrawingOutsideViewBox: true,
                              ),
                            ),
                          ),
                          Container(
                            color: const Color(0xffffffff),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 2.0, end: 1.1),
                  Pin(size: 25.4, middle: 0.2937),
                  child: Stack(
                    children: <Widget>[
                      Stack(
                        children: <Widget>[
                          Pinned.fromPins(
                            Pin(size: 21.0, end: 0.0),
                            Pin(size: 10.7, end: 3.0),
                            child: SvgPicture.string(
                              _svg_cnvh16,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            ),
                          ),
                          Align(
                            alignment: Alignment.bottomLeft,
                            child: SizedBox(
                              width: 7.0,
                              height: 11.0,
                              child: SvgPicture.string(
                                _svg_i6ckk6,
                                allowDrawingOutsideViewBox: true,
                              ),
                            ),
                          ),
                          Align(
                            alignment: const Alignment(0.087, -0.423),
                            child: SizedBox(
                              width: 9.0,
                              height: 4.0,
                              child: SvgPicture.string(
                                _svg_queik,
                                allowDrawingOutsideViewBox: true,
                              ),
                            ),
                          ),
                          Align(
                            alignment: const Alignment(0.074, -1.0),
                            child: SizedBox(
                              width: 6.0,
                              height: 6.0,
                              child: SvgPicture.string(
                                _svg_eyh1sg,
                                allowDrawingOutsideViewBox: true,
                              ),
                            ),
                          ),
                          Container(
                            color: const Color(0xffffffff),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 1.0, end: 1.1),
                  Pin(size: 23.7, middle: 0.3938),
                  child: Stack(
                    children: <Widget>[
                      Stack(
                        children: <Widget>[
                          Align(
                            alignment: Alignment.bottomLeft,
                            child: SizedBox(
                              width: 16.0,
                              height: 5.0,
                              child: SvgPicture.string(
                                _svg_m7748,
                                allowDrawingOutsideViewBox: true,
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 4.0, vertical: 0.0),
                            child: SizedBox.expand(
                                child: SvgPicture.string(
                              _svg_atlxg8,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            )),
                          ),
                          Align(
                            alignment: Alignment.topRight,
                            child: SizedBox(
                              width: 4.0,
                              height: 6.0,
                              child: SvgPicture.string(
                                _svg_ahrudf,
                                allowDrawingOutsideViewBox: true,
                              ),
                            ),
                          ),
                          Pinned.fromPins(
                            Pin(size: 6.3, middle: 0.4623),
                            Pin(size: 7.9, start: 3.2),
                            child: SvgPicture.string(
                              _svg_u20suy,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            ),
                          ),
                          Container(
                            color: const Color(0xffffffff),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 1.0, end: 1.1),
                  Pin(size: 24.7, middle: 0.4925),
                  child: Stack(
                    children: <Widget>[
                      Stack(
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.fromLTRB(0.0, 7.2, 0.0, 0.0),
                            child: SizedBox.expand(
                                child: SvgPicture.string(
                              _svg_dgdaar,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            )),
                          ),
                          Pinned.fromPins(
                            Pin(start: 0.0, end: 0.1),
                            Pin(size: 5.4, start: 0.0),
                            child: SvgPicture.string(
                              _svg_o0jvhs,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            ),
                          ),
                          Container(
                            color: const Color(0xffffffff),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 2.0, end: 1.1),
                  Pin(size: 25.4, middle: 0.5932),
                  child: Stack(
                    children: <Widget>[
                      Stack(
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.fromLTRB(0.0, 0.0, 3.4, 0.0),
                            child: SizedBox.expand(
                                child: SvgPicture.string(
                              _svg_ezxow9,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            )),
                          ),
                          Pinned.fromPins(
                            Pin(size: 3.0, end: 0.0),
                            Pin(size: 20.4, end: 0.6),
                            child: SvgPicture.string(
                              _svg_m7lbm,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            ),
                          ),
                          Align(
                            alignment: const Alignment(-0.337, -0.573),
                            child: Container(
                              width: 12.0,
                              height: 4.0,
                              color: const Color(0xffffffff),
                            ),
                          ),
                          Align(
                            alignment: const Alignment(-0.572, 0.279),
                            child: Container(
                              width: 4.0,
                              height: 4.0,
                              color: const Color(0xffffffff),
                            ),
                          ),
                          Container(
                            color: const Color(0xffffffff),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 1.0, end: 0.0),
                  Pin(size: 25.4, middle: 0.6946),
                  child: Stack(
                    children: <Widget>[
                      Stack(
                        children: <Widget>[
                          Pinned.fromPins(
                            Pin(size: 18.4, start: 0.0),
                            Pin(start: 0.0, end: 0.0),
                            child: SvgPicture.string(
                              _svg_jm55xi,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            ),
                          ),
                          Align(
                            alignment: const Alignment(1.0, -0.109),
                            child: SizedBox(
                              width: 20.0,
                              height: 14.0,
                              child: SvgPicture.string(
                                _svg_nagfe3,
                                allowDrawingOutsideViewBox: true,
                              ),
                            ),
                          ),
                          Pinned.fromPins(
                            Pin(size: 16.3, end: 1.3),
                            Pin(size: 6.6, middle: 0.2217),
                            child: SvgPicture.string(
                              _svg_lkynt9,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            ),
                          ),
                          Container(
                            color: const Color(0xffffffff),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 1.0, end: 1.0),
                  Pin(size: 25.5, end: 53.4),
                  child: SvgPicture.string(
                    _svg_aykux2,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 2.0, end: 2.6),
                  Pin(size: 31.1, end: 0.0),
                  child: Stack(
                    children: <Widget>[
                      Stack(
                        children: <Widget>[
                          SizedBox.expand(
                              child: SvgPicture.string(
                            _svg_gpfr1,
                            allowDrawingOutsideViewBox: true,
                            fit: BoxFit.fill,
                          )),
                          Container(
                            color: const Color(0xffffffff),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.2),
                  Pin(size: 30.3, middle: 0.7939),
                  child: Stack(
                    children: <Widget>[
                      Stack(
                        children: <Widget>[
                          Pinned.fromPins(
                            Pin(size: 20.5, end: 1.8),
                            Pin(size: 20.6, start: 1.8),
                            child: SvgPicture.string(
                              _svg_m8tva,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            ),
                          ),
                          Pinned.fromPins(
                            Pin(size: 10.9, start: 1.7),
                            Pin(size: 10.9, end: 3.8),
                            child: SvgPicture.string(
                              _svg_gzza,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            ),
                          ),
                          Align(
                            alignment: const Alignment(-0.053, 1.0),
                            child: SizedBox(
                              width: 6.0,
                              height: 6.0,
                              child: SvgPicture.string(
                                _svg_twafwq,
                                allowDrawingOutsideViewBox: true,
                              ),
                            ),
                          ),
                          Pinned.fromPins(
                            Pin(size: 5.2, start: 0.0),
                            Pin(size: 5.3, end: 2.0),
                            child: SvgPicture.string(
                              _svg_qldvta,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            ),
                          ),
                          Pinned.fromPins(
                            Pin(size: 4.1, end: 3.0),
                            Pin(size: 4.1, start: 3.0),
                            child: SvgPicture.string(
                              _svg_x6onw,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            ),
                          ),
                          Align(
                            alignment: const Alignment(0.308, -1.0),
                            child: SizedBox(
                              width: 2.0,
                              height: 4.0,
                              child: SvgPicture.string(
                                _svg_grpj7z,
                                allowDrawingOutsideViewBox: true,
                              ),
                            ),
                          ),
                          Align(
                            alignment: const Alignment(1.0, -0.358),
                            child: SizedBox(
                              width: 4.0,
                              height: 2.0,
                              child: SvgPicture.string(
                                _svg_re93b8,
                                allowDrawingOutsideViewBox: true,
                              ),
                            ),
                          ),
                          Container(
                            color: const Color(0xffffffff),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_gmfkkg =
    '<svg viewBox="0.0 0.0 25.4 25.4" ><path transform="translate(0.0, 0.0)" d="M 25.42219543457031 11.96581554412842 L 25.42219543457031 13.45508766174316 C 25.40753173828125 13.52649116516113 25.38458251953125 13.59789562225342 25.38011932373047 13.66993618011475 C 25.25580215454102 15.44354724884033 24.796142578125 17.12981414794922 23.92591094970703 18.67646598815918 C 21.58362197875977 22.8382682800293 18.01408767700195 25.11042785644531 13.24344444274902 25.39859199523926 C 10.73794841766357 25.55032348632812 8.372071266174316 24.95295715332031 6.232517719268799 23.63263130187988 C 2.374818086624146 21.25208854675293 0.2888172268867493 17.77244758605957 0.0216918271034956 13.24597835540771 C -0.1134647130966187 10.95277976989746 0.3850843906402588 8.766687393188477 1.4937504529953 6.750813961029053 C 3.465633392333984 3.165978193283081 6.472867012023926 0.9747846722602844 10.49759864807129 0.2008222043514252 C 10.98275947570801 0.1077427119016647 11.47748374938965 0.06566567718982697 11.96774482727051 0 L 13.45701694488525 0 C 13.52077007293701 0.01402567885816097 13.58388519287109 0.03697678819298744 13.64827632904053 0.04143950343132019 C 15.42124843597412 0.1625703573226929 17.10114288330078 0.6286054253578186 18.65608215332031 1.484171867370605 C 22.24856567382812 3.459242343902588 24.44677352905273 6.465837955474854 25.22201156616211 10.49821949005127 C 25.31509208679199 10.98210620880127 25.35652923583984 11.47619247436523 25.42219543457031 11.96581554412842 M 15.56150722503662 18.85306358337402 C 15.18026351928711 18.93466567993164 14.83854579925537 19.03667068481445 14.48917865753174 19.07683563232422 C 13.50036907196045 19.19095230102539 13.06748580932617 18.75296974182129 13.24726867675781 17.78201103210449 C 13.38625144958496 17.0284481048584 13.59408664703369 16.28700065612793 13.78024482727051 15.54236507415771 C 14.03780746459961 14.51147651672363 14.42606353759766 13.51437950134277 14.48662948608398 12.43312644958496 C 14.53890705108643 11.51189422607422 14.11686038970947 10.74494457244873 13.27149486541748 10.39239025115967 C 12.71493148803711 10.15969085693359 12.13031578063965 10.1303653717041 11.54123783111572 10.20368099212646 C 10.72966003417969 10.30568695068359 9.982473373413086 10.62700176239014 9.22763729095459 10.91707801818848 C 9.177272796630859 10.93684196472168 9.10905647277832 10.97381782531738 9.09758186340332 11.01525783538818 C 9.025539398193359 11.27919483184814 8.966887474060059 11.54632186889648 8.896121978759766 11.84787273406982 C 9.084831237792969 11.78667068481445 9.225725173950195 11.74204254150391 9.366620063781738 11.69614124298096 C 9.775277137756348 11.56289577484131 10.19030857086182 11.52719497680664 10.6136302947998 11.61708641052246 C 10.9476957321167 11.68848991394043 11.14851760864258 11.85297298431396 11.16509437561035 12.19468975067139 C 11.18358135223389 12.59378433227539 11.1797571182251 13.00945472717285 11.09050273895264 13.39579772949219 C 10.89095497131348 14.26411533355713 10.63849258422852 15.12031745910645 10.39686870574951 15.9790735244751 C 10.17947101593018 16.75112342834473 9.95952320098877 17.52126121520996 9.933383941650391 18.33092498779297 C 9.905332565307617 19.2068920135498 10.35032939910889 19.91582489013672 11.15043067932129 20.25116539001465 C 11.81282424926758 20.52913093566895 12.51474571228027 20.57949447631836 13.19499206542969 20.41883850097656 C 13.89818859100342 20.25244331359863 14.57333374023438 19.9693775177002 15.25931644439697 19.73221588134766 C 15.30649375915527 19.71627807617188 15.36196041107178 19.66463851928711 15.37470817565918 19.6193733215332 C 15.44356346130371 19.36627388000488 15.5003023147583 19.10998725891113 15.56150722503662 18.85306358337402 M 11.84470176696777 6.642433643341064 C 11.92758083343506 6.931234836578369 11.96519470214844 7.242987632751465 12.1016263961792 7.503738403320312 C 12.5026330947876 8.271963119506836 13.36011219024658 8.646830558776855 14.2443675994873 8.485535621643066 C 15.25357913970947 8.301926612854004 15.9095983505249 7.385795116424561 15.74766635894775 6.382958889007568 C 15.63099670410156 5.663186550140381 14.89273738861084 4.929388523101807 13.91476440429688 4.893049240112305 C 12.87112522125244 4.854159832000732 11.97284507751465 5.608358860015869 11.84470176696777 6.642433643341064" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_k3hyvs =
    '<svg viewBox="71.0 152.9 25.4 23.1" ><path transform="translate(68.43, 150.06)" d="M 27.99283409118652 16.75075531005859 L 15.28176784515381 6.884137153625488 L 2.570700645446777 16.75080680847168 L 2.570700645446777 12.72800064086914 L 15.28176784515381 2.861382484436035 L 27.99283409118652 12.72805118560791 L 27.99283409118652 16.75075531005859 Z M 24.81506729125977 16.39216423034668 L 24.81506729125977 25.92546463012695 L 18.45953369140625 25.92546463012695 L 18.45953369140625 19.56993293762207 L 12.10400104522705 19.56993293762207 L 12.10400104522705 25.92546463012695 L 5.748466968536377 25.92546463012695 L 5.748466968536377 16.39216423034668 L 15.28176784515381 9.242189407348633 L 24.81506729125977 16.39216423034668 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_b4y4ty =
    '<svg viewBox="0.0 4.3 19.9 18.0" ><path transform="translate(0.0, -52.35)" d="M 15.59195423126221 56.65433502197266 C 16.31962394714355 56.65562438964844 17.04728889465332 56.65350341796875 17.77495574951172 56.65925598144531 C 18.30166625976562 56.66342926025391 18.63272666931152 56.91788482666016 18.75836181640625 57.42436218261719 C 19.12170028686523 58.88977813720703 19.47867965698242 60.35669708251953 19.83663940429688 61.82347106933594 C 19.84944725036621 61.87590789794922 19.84588241577148 61.93236541748047 19.85255241394043 62.02177429199219 L 19.50459289550781 62.02177429199219 C 17.08517646789551 62.0218505859375 14.66583442687988 62.01502990722656 12.24649333953857 62.02389526367188 C 10.03970050811768 62.03200531005859 8.263082504272461 63.45597076416016 7.804493427276611 65.58258819580078 C 7.733492851257324 65.91175842285156 7.712123870849609 66.25691986083984 7.710381507873535 66.59494018554688 C 7.701287269592285 68.33397674560547 7.715911865234375 70.0732421875 7.702347755432129 71.81227111816406 C 7.694619655609131 72.80598449707031 7.929522037506104 73.71785736083984 8.497453689575195 74.53835296630859 C 8.517459869384766 74.56729888916016 8.52867317199707 74.60231018066406 8.55686092376709 74.66156005859375 C 8.474343299865723 74.66823577880859 8.41288948059082 74.67754364013672 8.351436614990234 74.67761993408203 C 6.442439079284668 74.67838287353516 4.533366203308105 74.68276977539062 2.624368667602539 74.6766357421875 C 1.365671753883362 74.67255401611328 0.3902972042560577 73.95101928710938 0.08234794437885284 72.81780242919922 C -0.0344969630241394 72.38785552978516 -0.02184255607426167 71.95980834960938 0.0831814631819725 71.52962493896484 C 1.229352474212646 66.83628845214844 2.373932600021362 62.14248657226562 3.520407199859619 57.44914245605469 C 3.651422262191772 56.91280364990234 3.977405548095703 56.66176605224609 4.540791988372803 56.65873718261719 C 5.258986473083496 56.65478515625 5.977257251739502 56.65554809570312 6.695451736450195 56.65426635742188 L 6.687268257141113 56.64675903320312 C 6.685601234436035 57.55393218994141 6.680220603942871 58.46103668212891 6.684085845947266 59.36821746826172 C 6.685752868652344 59.76845550537109 6.91474437713623 60.09095764160156 7.267324924468994 60.22417449951172 C 7.878601551055908 60.45505523681641 8.4866943359375 60.00722503662109 8.495181083679199 59.30995178222656 C 8.505941390991211 58.42201232910156 8.50609302520752 57.53400421142578 8.510790824890137 56.64599609375 L 8.502076148986816 56.65471649169922 L 13.78517818450928 56.65471649169922 L 13.77654075622559 56.64608001708984 C 13.78063201904297 57.54377746582031 13.77979850769043 58.44156646728516 13.79071044921875 59.33919525146484 C 13.79737758636475 59.89128875732422 14.19451427459717 60.28820037841797 14.71236038208008 60.28168487548828 C 15.21535396575928 60.275390625 15.59915542602539 59.87734985351562 15.60188293457031 59.34055328369141 C 15.6064281463623 58.442626953125 15.60112571716309 57.54469299316406 15.5999870300293 56.64675903320312 L 15.59195423126221 56.65433502197266 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_eb2cs =
    '<svg viewBox="9.5 11.5 15.9 10.9" ><path transform="translate(-116.13, -139.93)" d="M 133.5901947021484 151.4147491455078 C 135.2817993164062 151.4147491455078 136.9743041992188 151.4503021240234 138.6646118164062 151.4048309326172 C 140.3829650878906 151.3585968017578 141.5875701904297 152.6981658935547 141.5464935302734 154.2788238525391 C 141.5018463134766 155.9977874755859 141.5376892089844 157.7187805175781 141.5359497070312 159.4388885498047 C 141.5343627929688 161.0961456298828 140.4071502685547 162.2480773925781 138.7497100830078 162.2527008056641 C 135.3099060058594 162.2623291015625 131.8700256347656 162.2624816894531 128.4302368164062 162.2527008056641 C 126.7701416015625 162.2480010986328 125.6498107910156 161.1016693115234 125.6476898193359 159.4387969970703 C 125.6455841064453 157.6997680664062 125.6455841064453 155.9607391357422 125.6477661132812 154.2217559814453 C 125.6498107910156 152.5388031005859 126.7700805664062 151.4192199707031 128.4588012695312 151.4155883789062 C 130.1692657470703 151.4119720458984 131.8797302246094 151.4148406982422 133.5901947021484 151.4147491455078 M 136.4588928222656 159.0402221679688 C 136.8173828125 159.0402221679688 137.1759338378906 159.0441589355469 137.5343627929688 159.0392303466797 C 138.0524444580078 159.0321044921875 138.4432678222656 158.6598968505859 138.4614562988281 158.1638793945312 C 138.4786529541016 157.6945343017578 138.1044769287109 157.2520904541016 137.6149139404297 157.2360229492188 C 136.8610992431641 157.2112274169922 136.1052398681641 157.2108612060547 135.3514251708984 157.2366180419922 C 134.8628387451172 157.2532958984375 134.4910888671875 157.6980895996094 134.5095825195312 158.1684265136719 C 134.5286712646484 158.6530303955078 134.9135437011719 159.0288391113281 135.4118347167969 159.0387878417969 C 135.7606964111328 159.0456695556641 136.10986328125 159.0400695800781 136.4588928222656 159.0402221679688 M 136.4872131347656 156.4281921386719 C 136.8269195556641 156.4281921386719 137.1666259765625 156.4309997558594 137.5063171386719 156.4275817871094 C 138.0531158447266 156.4220581054688 138.4634246826172 156.0302124023438 138.4619293212891 155.5196228027344 C 138.4604797363281 155.0190734863281 138.0612945556641 154.6220092773438 137.5302734375 154.6154937744141 C 136.8321533203125 154.6068725585938 136.1337280273438 154.6065521240234 135.4356231689453 154.61572265625 C 134.9050445556641 154.6226196289062 134.5079803466797 155.0218048095703 134.5091247558594 155.5233612060547 C 134.51025390625 156.0245971679688 134.9138336181641 156.4196319580078 135.4398651123047 156.4271087646484 C 135.7888946533203 156.43212890625 136.1381378173828 156.4280395507812 136.4872131347656 156.4281921386719 M 130.5177459716797 159.0401458740234 C 130.8291778564453 159.0401458740234 131.1407012939453 159.0450134277344 131.4519805908203 159.0390014648438 C 131.9562530517578 159.0292358398438 132.3390808105469 158.6580047607422 132.3529510498047 158.1737365722656 C 132.3673400878906 157.6714172363281 132.0059661865234 157.2513275146484 131.4956359863281 157.2333679199219 C 130.8641204833984 157.2112274169922 130.2308654785156 157.2135009765625 129.5992126464844 157.2321624755859 C 129.0919647216797 157.2470855712891 128.7080230712891 157.6717987060547 128.7196044921875 158.1586608886719 C 128.7314453125 158.6530914306641 129.1232757568359 159.0306701660156 129.64013671875 159.0393218994141 C 129.9326171875 159.0442352294922 130.2252655029297 159.0402221679688 130.5177459716797 159.0401458740234 M 131.4544677734375 155.530029296875 C 131.4583435058594 155.0233764648438 131.0729675292969 154.62451171875 130.5695037841797 154.6142730712891 C 130.0612182617188 154.6039123535156 129.6430053710938 155.0162048339844 129.6457366943359 155.5250244140625 C 129.6483764648438 156.016357421875 130.0602874755859 156.4266662597656 130.5519256591797 156.4276580810547 C 131.0529479980469 156.4287109375 131.4506225585938 156.0331726074219 131.4544677734375 155.530029296875" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_a8ijd2 =
    '<svg viewBox="6.7 0.0 8.9 4.3" ><path transform="translate(-81.57, 0.0)" d="M 88.26617431640625 4.301264762878418 C 88.19691467285156 2.646871089935303 88.9674072265625 1.452203631401062 90.34703063964844 0.6380024552345276 C 92.3677978515625 -0.5545430779457092 95.05909729003906 -0.02237590216100216 96.41084289550781 1.806451559066772 C 96.95733642578125 2.54578709602356 97.22822570800781 3.374385595321655 97.16268920898438 4.301340579986572 L 97.17071533203125 4.293686866760254 C 96.56292724609375 4.293459892272949 95.95506286621094 4.293232917785645 95.34725952148438 4.293005466461182 L 95.35591125488281 4.301643848419189 C 95.41168212890625 3.310583353042603 94.9398193359375 2.622168302536011 94.10122680664062 2.162442207336426 C 93.51919555664062 1.843429446220398 92.88670349121094 1.761365413665771 92.23336791992188 1.86116087436676 C 91.04719543457031 2.04226279258728 89.95512390136719 2.9774010181427 90.07279968261719 4.301719188690186 L 90.08151245117188 4.293005466461182 C 89.47364807128906 4.293232917785645 88.86585998535156 4.293535709381104 88.25799560546875 4.293763637542725 L 88.26617431640625 4.301264762878418" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_cnvh16 =
    '<svg viewBox="4.4 11.8 21.0 10.7" ><path transform="translate(-66.68, -177.18)" d="M 92.103759765625 190.9338531494141 C 91.91015625 191.2847747802734 91.74482727050781 191.6552124023438 91.51824951171875 191.9832916259766 C 90.23527526855469 193.8412933349609 88.93002319335938 195.6839141845703 87.6473388671875 197.5421600341797 C 86.67825317382812 198.946044921875 85.35118103027344 199.6308441162109 83.65141296386719 199.6275482177734 C 80.95390319824219 199.622314453125 78.25637817382812 199.6249237060547 75.55886840820312 199.629150390625 C 75.40231323242188 199.62939453125 75.31051635742188 199.5963134765625 75.23419952392578 199.4423828125 C 73.88740539550781 196.7250823974609 72.53326416015625 194.0114593505859 71.18087005615234 191.2970275878906 C 71.15580749511719 191.2467651367188 71.13229370117188 191.1958312988281 71.10398864746094 191.1366882324219 C 72.00926208496094 190.3033294677734 72.92454528808594 189.5057067871094 74.13381958007812 189.1658020019531 C 76.00686645507812 188.6393127441406 77.70576477050781 188.9715728759766 79.17726135253906 190.2645111083984 C 79.5264892578125 190.5713806152344 79.88226318359375 190.7016143798828 80.34164428710938 190.6928405761719 C 81.49967193603516 190.6707153320312 82.658447265625 190.6769866943359 83.81679534912109 190.6881866455078 C 84.90609741210938 190.6986999511719 85.60798645019531 191.6882476806641 85.25222778320312 192.6902770996094 C 85.04336547851562 193.2785949707031 84.48745727539062 193.6598510742188 83.80665588378906 193.6640930175781 C 82.84684753417969 193.6700592041016 81.88690185546875 193.6613006591797 80.92709350585938 193.6675720214844 C 80.3531494140625 193.6713104248047 79.99333953857422 194.1690063476562 80.1900634765625 194.6785736083984 C 80.30593872070312 194.9788665771484 80.53886413574219 195.1480407714844 80.85600280761719 195.1503448486328 C 82.03089141845703 195.1587982177734 83.20628356933594 195.1701812744141 84.38066101074219 195.1448669433594 C 84.85821533203125 195.1345367431641 85.26802062988281 194.9126129150391 85.57913208007812 194.529052734375 C 86.85086059570312 192.9612121582031 88.12774658203125 191.3975982666016 89.39854431152344 189.8289947509766 C 89.79049682617188 189.3451690673828 90.2791748046875 189.1067199707031 90.900634765625 189.2314758300781 C 91.52969360351562 189.3578033447266 91.91288757324219 189.7545013427734 92.06346130371094 190.3776397705078 C 92.06875610351562 190.3993988037109 92.08995056152344 190.4173889160156 92.103759765625 190.4371643066406 L 92.103759765625 190.9338531494141 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_i6ckk6 =
    '<svg viewBox="0.0 14.4 7.3 11.0" ><path transform="translate(0.0, -217.66)" d="M 5.011469841003418 243.0915832519531 C 4.720701217651367 242.9551696777344 4.557125568389893 242.7141723632812 4.416996955871582 242.4324188232422 C 3.004395008087158 239.5921478271484 1.583582520484924 236.7560729980469 0.165320098400116 233.9186706542969 C -0.1427382081747055 233.3023834228516 -0.02835919894278049 232.9582366943359 0.5841500759124756 232.6536102294922 C 0.8355475068092346 232.5285186767578 1.084705829620361 232.3986663818359 1.338342428207397 232.2783203125 C 2.181724548339844 231.8780822753906 3.009370803833008 232.1509857177734 3.42938232421875 232.9885406494141 C 4.677289009094238 235.4768218994141 5.919970512390137 237.9677734375 7.156309127807617 240.4619140625 C 7.578746795654297 241.3141937255859 7.291586399078369 242.1322021484375 6.441673755645752 242.5680694580078 C 6.098225593566895 242.7442169189453 5.753098487854004 242.9171905517578 5.408780097961426 243.0915832519531 L 5.011469841003418 243.0915832519531 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_queik =
    '<svg viewBox="8.9 6.0 9.0 4.5" ><path transform="translate(-134.63, -91.04)" d="M 151.3922424316406 97.11228942871094 C 152.0884094238281 97.90032196044922 152.4768829345703 98.80054473876953 152.5418853759766 99.83462524414062 C 152.5605316162109 100.1313629150391 152.5520172119141 100.4299697875977 152.551025390625 100.7276382446289 C 152.5490875244141 101.2779541015625 152.2581329345703 101.5727005004883 151.710693359375 101.5733795166016 C 150.1478118896484 101.5752487182617 148.5848083496094 101.5740737915039 147.0218200683594 101.5740737915039 C 146.1535034179688 101.5740737915039 145.2851715087891 101.5754318237305 144.4169311523438 101.5735092163086 C 143.8539886474609 101.572265625 143.5754089355469 101.280876159668 143.560791015625 100.7149505615234 C 143.5380249023438 99.83835601806641 143.590087890625 98.97383117675781 144.0104675292969 98.18151092529297 C 144.2095642089844 97.80633544921875 144.4571075439453 97.45685577392578 144.6905822753906 97.08299255371094 C 146.5206451416016 99.04155731201172 149.5327606201172 99.11134338378906 151.3922424316406 97.11228942871094" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_eyh1sg =
    '<svg viewBox="10.4 0.0 6.0 6.1" ><path transform="translate(-157.21, 0.0)" d="M 173.6390991210938 3.01821231842041 C 173.6439056396484 4.672695636749268 172.2989044189453 6.051464080810547 170.6737670898438 6.057994365692139 C 169.0294799804688 6.064525604248047 167.6310119628906 4.671016216278076 167.6320037841797 3.027168750762939 C 167.6328735351562 1.39308500289917 169.0184783935547 0.004428194370120764 170.6524353027344 -0.0001743323809932917 C 172.2785491943359 -0.004776859655976295 173.6342468261719 1.365345478057861 173.6390991210938 3.01821231842041" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_m7748 =
    '<svg viewBox="0.0 18.9 16.0 4.8" ><path transform="translate(0.0, -311.61)" d="M 0 330.4721374511719 C 0.0857585147023201 330.46875 0.1714599579572678 330.4624328613281 0.2572184503078461 330.4624328613281 C 4.925095081329346 330.4618835449219 9.59302806854248 330.4619445800781 14.26090526580811 330.4619445800781 L 14.57580947875977 330.4619445800781 C 14.57580947875977 330.7049255371094 14.56947422027588 330.9252319335938 14.57706451416016 331.1450500488281 C 14.59823322296143 331.7625427246094 14.57883262634277 332.3860778808594 14.66111278533936 332.9956970214844 C 14.77140426635742 333.8122253417969 15.18850040435791 334.4932250976562 15.78572750091553 335.0606994628906 C 15.84175872802734 335.1139221191406 15.8992166519165 335.1657409667969 15.95405006408691 335.2201843261719 C 15.96420478820801 335.2302856445312 15.96489238739014 335.2498168945312 15.98178195953369 335.3006286621094 L 15.67098331451416 335.3006286621094 C 11.53608894348145 335.3006286621094 7.401136875152588 335.30078125 3.266240835189819 335.300537109375 C 1.496580243110657 335.3004455566406 0.4142427146434784 334.4316101074219 0.0345202274620533 332.70849609375 C 0.02915675193071365 332.6841430664062 0.01175399590283632 332.6625061035156 0 332.6395874023438 L 0 330.4721374511719" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_atlxg8 =
    '<svg viewBox="4.0 0.0 18.3 23.7" ><path transform="translate(-65.96, 0.0)" d="M 69.95648956298828 18.04970169067383 C 69.95648956298828 17.9344425201416 69.95598602294922 17.85855865478516 69.95655822753906 17.7827262878418 C 69.99717712402344 12.56372547149658 70.04042816162109 7.344666481018066 70.07603454589844 2.12560772895813 C 70.08197021484375 1.252673983573914 70.42848205566406 0.584636390209198 71.22335052490234 0.2147278636693954 C 71.52342987060547 0.07504933327436447 71.8848876953125 0.009432364255189896 72.21862030029297 0.008690607734024525 C 77.48081970214844 -0.003748084884136915 82.74301910400391 -0.0001534168550278991 88.00520324707031 0.0003030489606317133 C 88.06380462646484 0.0003030489606317133 88.12240600585938 0.006351220421493053 88.2410888671875 0.01285585761070251 C 88.14466094970703 0.1333628445863724 88.07550811767578 0.2220883965492249 88.00389862060547 0.3088168799877167 C 87.57943725585938 0.8226832747459412 87.33528900146484 1.408899545669556 87.32798004150391 2.078192234039307 C 87.31787872314453 3.006701231002808 87.32284545898438 3.935380697250366 87.32279205322266 4.86400318145752 C 87.32244873046875 10.0918493270874 87.32353210449219 15.31963920593262 87.32199096679688 20.54748153686523 C 87.32159423828125 21.96360969543457 86.57225036621094 23.06711959838867 85.31428527832031 23.51862144470215 C 83.45407104492188 24.18631553649902 81.40705871582031 22.79900169372559 81.34868621826172 20.82107543945312 C 81.32814788818359 20.12519454956055 81.34262847900391 19.42828559875488 81.34178161621094 18.73177528381348 C 81.34109497070312 18.1557731628418 81.23724365234375 18.04970169067383 80.67003631591797 18.04970169067383 C 77.22206115722656 18.04964447021484 73.77408599853516 18.04970169067383 70.32611846923828 18.04970169067383 L 69.95648956298828 18.04970169067383 Z M 82.34109497070312 6.092352390289307 C 82.35011291503906 6.092352390289307 82.35918426513672 6.092352390289307 82.36826324462891 6.092295169830322 C 82.36826324462891 5.585162162780762 82.35684204101562 5.077686786651611 82.37252807617188 4.571066379547119 C 82.3818359375 4.271167755126953 82.25956726074219 4.099423408508301 81.99269866943359 3.971099376678467 C 80.90214538574219 3.446620225906372 79.81741333007812 2.910044193267822 78.734619140625 2.369703054428101 C 78.50786590576172 2.256556510925293 78.30633544921875 2.251820802688599 78.07759094238281 2.366222381591797 C 76.98749542236328 2.911071538925171 75.89499664306641 3.451412916183472 74.79703521728516 3.980171680450439 C 74.54517364501953 4.101420402526855 74.44121551513672 4.26979923248291 74.44314575195312 4.543449878692627 C 74.45023345947266 5.54910135269165 74.43003845214844 6.555095195770264 74.45017242431641 7.560347080230713 C 74.4735107421875 8.72336483001709 74.95228576660156 9.67138671875 75.90293121337891 10.35277652740479 C 76.62191772460938 10.86812591552734 77.36430358886719 11.35066699981689 78.090087890625 11.85666084289551 C 78.3106689453125 12.0103759765625 78.50284576416016 12.01699352264404 78.72560882568359 11.86139678955078 C 79.45800018310547 11.34981155395508 80.20484161376953 10.85876846313477 80.93238830566406 10.34056663513184 C 81.75350952148438 9.755719184875488 82.23085784912109 8.941954612731934 82.32979583740234 7.946517467498779 C 82.39068603515625 7.334167957305908 82.34109497070312 6.710806369781494 82.34109497070312 6.092352390289307 M 78.61456298828125 13.33190059661865 C 76.82573699951172 13.33190059661865 75.03696441650391 13.33098793029785 73.24812316894531 13.33269882202148 C 72.92581176757812 13.33304214477539 72.74629974365234 13.47779941558838 72.74515533447266 13.72366237640381 C 72.7440185546875 13.97021198272705 72.92694091796875 14.11616611480713 73.24401092529297 14.12084484100342 C 73.31277465820312 14.1218147277832 73.38158416748047 14.12101650238037 73.45039367675781 14.12101650238037 L 83.51239013671875 14.12101650238037 C 83.68441009521484 14.12101650238037 83.85649871826172 14.12512397766113 84.02836608886719 14.11964702606201 C 84.29972839355469 14.1109733581543 84.47136688232422 13.94864177703857 84.46463012695312 13.7151050567627 C 84.45818328857422 13.49052333831787 84.296142578125 13.34610748291016 84.03253173828125 13.33315563201904 C 83.95526885986328 13.32933330535889 83.87773132324219 13.33184432983398 83.80036163330078 13.33184432983398 C 82.07172393798828 13.33178615570068 80.34314727783203 13.33178615570068 78.61456298828125 13.33190059661865 M 78.60897064208984 15.43672180175781 C 76.87190246582031 15.43672180175781 75.13475799560547 15.43649578094482 73.39767456054688 15.43729400634766 C 73.29474639892578 15.43729400634766 73.19107055664062 15.43900394439697 73.0889892578125 15.45092868804932 C 72.87776184082031 15.47552013397217 72.76307678222656 15.61069297790527 72.75154876708984 15.81136608123779 C 72.73916625976562 16.02756118774414 72.85933685302734 16.16974830627441 73.07089996337891 16.21682167053223 C 73.16168212890625 16.23701858520508 73.2589111328125 16.23194122314453 73.35317230224609 16.23194122314453 C 76.85317993164062 16.23256874084473 80.35317993164062 16.23251152038574 83.85320281982422 16.23245239257812 C 83.91339111328125 16.23245239257812 83.97376251220703 16.23502349853516 84.03372192382812 16.23131370544434 C 84.29174041748047 16.21545219421387 84.46035003662109 16.0628776550293 84.46577453613281 15.84263324737549 C 84.47130584716797 15.61947917938232 84.31154632568359 15.46216869354248 84.05227661132812 15.44100284576416 C 83.966796875 15.43398284912109 83.88040924072266 15.43689250946045 83.79447937011719 15.43683433532715 C 82.06597137451172 15.43666458129883 80.33749389648438 15.43672180175781 78.60897064208984 15.43672180175781" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_ahrudf =
    '<svg viewBox="22.1 0.0 4.3 5.8" ><path transform="translate(-365.98, -0.27)" d="M 392.3745422363281 6.066280364990234 L 388.1458129882812 6.066280364990234 C 388.1390686035156 5.991876602172852 388.1279907226562 5.925917148590088 388.1278991699219 5.859958171844482 C 388.1268310546875 4.751202583312988 388.1220703125 3.642390012741089 388.128662109375 2.533634662628174 C 388.1345520019531 1.526328563690186 388.7106018066406 0.6852902770042419 389.5742797851562 0.3999420702457428 C 390.8857727050781 -0.03330099582672119 392.2566833496094 0.7703641057014465 392.3546142578125 2.140446186065674 C 392.447265625 3.437436819076538 392.3745422363281 4.746238708496094 392.3745422363281 6.066280364990234" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_u20suy =
    '<svg viewBox="9.3 3.2 6.3 7.9" ><path transform="translate(-153.39, -52.24)" d="M 169.0180816650391 58.56246566772461 C 168.9868927001953 59.17076110839844 169.0101013183594 59.7881965637207 168.9096984863281 60.38479232788086 C 168.8012847900391 61.02852630615234 168.4345245361328 61.55757141113281 167.8837890625 61.93620300292969 C 167.2534027099609 62.36961364746094 166.6182861328125 62.79624938964844 165.9924163818359 63.23598480224609 C 165.8607330322266 63.32848358154297 165.7743988037109 63.31307983398438 165.6517639160156 63.22721099853516 C 165.0321807861328 62.79339599609375 164.3991851806641 62.37841033935547 163.7844848632812 61.93785858154297 C 163.0675506591797 61.42399597167969 162.6932525634766 60.71173858642578 162.6784820556641 59.83036041259766 C 162.6631927490234 58.91890716552734 162.6780700683594 58.00694274902344 162.6719055175781 57.09526824951172 C 162.6709442138672 56.94777679443359 162.7127685546875 56.86754989624023 162.8514556884766 56.80034255981445 C 163.78662109375 56.34723663330078 164.7143096923828 55.87879180908203 165.651611328125 55.43042755126953 C 165.7542572021484 55.38129806518555 165.9226379394531 55.38694381713867 166.0269317626953 55.43704223632812 C 166.9478149414062 55.87998962402344 167.8583831787109 56.34427261352539 168.7789611816406 56.7877311706543 C 168.9482727050781 56.86920547485352 168.9955139160156 56.96694564819336 168.9917297363281 57.14199829101562 C 168.9814605712891 57.61484527587891 168.9882049560547 58.08802795410156 168.9882049560547 58.56109619140625 L 169.0180816650391 58.56246566772461 M 165.4051666259766 59.68685913085938 C 165.3752593994141 59.66973876953125 165.358154296875 59.66409301757812 165.3466949462891 59.65268325805664 C 165.1699066162109 59.47756195068359 164.9957275390625 59.29977035522461 164.8172454833984 59.12648391723633 C 164.5916290283203 58.90744018554688 164.3570098876953 58.88753128051758 164.18505859375 59.06800079345703 C 164.0184783935547 59.24277496337891 164.0365753173828 59.46432876586914 164.2468872070312 59.68257904052734 C 164.4970397949219 59.94213104248047 164.7526702880859 60.19650268554688 165.0083465576172 60.45063400268555 C 165.2953338623047 60.73587036132812 165.4793548583984 60.73461532592773 165.7716064453125 60.44356536865234 C 166.3068542480469 59.9105224609375 166.8405303955078 59.37594604492188 167.3732147216797 58.84040069580078 C 167.4331817626953 58.7801399230957 167.5235137939453 58.71240997314453 167.5285949707031 58.64292144775391 C 167.53955078125 58.49348068237305 167.5478820800781 58.31449127197266 167.4768981933594 58.19564056396484 C 167.3821411132812 58.03707504272461 167.1896514892578 58.01379776000977 167.0185699462891 58.10851287841797 C 166.9305725097656 58.15724182128906 166.8551483154297 58.23267364501953 166.7827911376953 58.30479049682617 C 166.3211822509766 58.76519393920898 165.8619842529297 59.22798919677734 165.4051666259766 59.68685913085938" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_dgdaar =
    '<svg viewBox="0.0 7.2 26.4 17.5" ><path transform="translate(0.0, -91.17)" d="M 0 98.35199737548828 L 26.42221069335938 98.35199737548828 L 26.42221069335938 98.73793792724609 C 26.42221069335938 103.5298614501953 26.42228317260742 108.3218383789062 26.4221363067627 113.1138305664062 C 26.42206573486328 114.5197143554688 25.4810619354248 115.6145782470703 24.0837230682373 115.8267822265625 C 23.87764549255371 115.8581237792969 23.66725921630859 115.8744049072266 23.45877265930176 115.8744812011719 C 16.43484115600586 115.8768920898438 9.410836219787598 115.8767395019531 2.386902809143066 115.8762969970703 C 0.9696291089057922 115.876220703125 0.07010422646999359 115.0100860595703 0.005038741510361433 113.5847778320312 C 0 113.4756011962891 0.00021907570771873 113.3662109375 0.00021907570771873 113.2568817138672 C 0 108.3920288085938 0 103.5271530151367 0 98.662353515625 L 0 98.35199737548828 Z M 21.15409660339355 103.1099548339844 C 21.15409660339355 102.7644805908203 21.15928077697754 102.4188461303711 21.15270805358887 102.0735168457031 C 21.14474868774414 101.6506195068359 20.89215469360352 101.396858215332 20.46831703186035 101.3929901123047 C 19.80466461181641 101.3870010375977 19.14093780517578 101.3875885009766 18.4772834777832 101.3925476074219 C 18.05213165283203 101.3957672119141 17.79128646850586 101.6371154785156 17.78223037719727 102.0655517578125 C 17.76806259155273 102.738037109375 17.76864624023438 103.4111862182617 17.78223037719727 104.0836791992188 C 17.79040718078613 104.489990234375 18.02452659606934 104.7447052001953 18.42390251159668 104.7554321289062 C 19.13232231140137 104.7743530273438 19.84219932556152 104.7742004394531 20.55046844482422 104.7515640258789 C 20.95692825317383 104.738639831543 21.14525985717773 104.5072174072266 21.15292549133301 104.0917816162109 C 21.15891647338867 103.7646331787109 21.15409660339355 103.437255859375 21.15409660339355 103.1099548339844 M 12.87091732025146 112.1674194335938 C 13.2073450088501 112.1674194335938 13.5437707901001 112.1715087890625 13.88005352020264 112.1663970947266 C 14.33434295654297 112.1595458984375 14.55831146240234 111.9584197998047 14.56882762908936 111.5041351318359 C 14.58438014984131 110.8317108154297 14.58328533172607 110.1585693359375 14.57006740570068 109.486083984375 C 14.56152439117432 109.0531921386719 14.31433391571045 108.8050537109375 13.88713645935059 108.7971649169922 C 13.21457386016846 108.7848205566406 12.54150104522705 108.7837219238281 11.86901092529297 108.7981109619141 C 11.43947601318359 108.8072357177734 11.20462703704834 109.0645751953125 11.20119476318359 109.4973297119141 C 11.19601058959961 110.15185546875 11.1961555480957 110.8065338134766 11.20104885101318 111.4610443115234 C 11.20448112487793 111.9157104492188 11.45554161071777 112.1604919433594 11.91640377044678 112.1668395996094 C 12.2345027923584 112.1712188720703 12.55274486541748 112.1676483154297 12.87091732025146 112.1674194335938 M 21.15314865112305 110.4960327148438 L 21.1545352935791 110.4960327148438 L 21.1545352935791 109.5413665771484 C 21.1545352935791 109.5231781005859 21.15482711791992 109.5050048828125 21.15424156188965 109.48681640625 C 21.14212226867676 109.0737152099609 20.9115047454834 108.8092956542969 20.5005931854248 108.7997131347656 C 19.81006622314453 108.7836456298828 19.11859321594238 108.7844543457031 18.42799186706543 108.8004455566406 C 18.05117988586426 108.8091430664062 17.79961013793945 109.0426025390625 17.78916549682617 109.4142303466797 C 17.76886558532715 110.1316986083984 17.76886558532715 110.8506317138672 17.79267120361328 111.5678863525391 C 17.80486679077148 111.9352111816406 18.07323455810547 112.1600494384766 18.44588470458984 112.1642913818359 C 19.13670349121094 112.1722412109375 19.82781028747559 112.172607421875 20.51863288879395 112.1634063720703 C 20.91932106018066 112.1580810546875 21.1405143737793 111.9324340820312 21.15117454528809 111.5323944091797 C 21.16045188903809 111.1871337890625 21.15314865112305 110.8415069580078 21.15314865112305 110.4960327148438 M 11.19980716705322 103.0624923706055 C 11.19980716705322 103.3897857666016 11.19659423828125 103.7170867919922 11.20061206817627 104.0443115234375 C 11.20608806610107 104.4910125732422 11.43648242950439 104.7501068115234 11.88105964660645 104.7599639892578 C 12.56253051757812 104.7750854492188 13.2448787689209 104.7753753662109 13.92620372772217 104.7574005126953 C 14.34544372558594 104.7463836669922 14.55393028259277 104.5436553955078 14.56481075286865 104.1309967041016 C 14.58328533172607 103.4315643310547 14.58357715606689 102.73095703125 14.56481075286865 102.0315933227539 C 14.55407619476318 101.6297378540039 14.29271793365479 101.3970031738281 13.8949499130249 101.3932113647461 C 13.22231578826904 101.3868560791016 12.54946041107178 101.3869247436523 11.87682437896729 101.3932800292969 C 11.45503044128418 101.3972930908203 11.2088623046875 101.6517181396484 11.20119476318359 102.0807418823242 C 11.19542598724365 102.4078979492188 11.20009994506836 102.7352676391602 11.19980716705322 103.0624923706055 M 4.696252822875977 110.4795227050781 C 4.696252822875977 110.8069610595703 4.69252872467041 111.1344757080078 4.697129249572754 111.4618530273438 C 4.703409194946289 111.9046783447266 4.950526714324951 112.1611480712891 5.387874603271484 112.1656036376953 C 6.024508953094482 112.1721649169922 6.661289215087891 112.1715087890625 7.29792308807373 112.1658172607422 C 7.749876022338867 112.1617279052734 8.05293083190918 111.8974456787109 8.065783500671387 111.4522857666016 C 8.085208892822266 110.7798767089844 8.082725524902344 110.1059875488281 8.062570571899414 109.4335784912109 C 8.051032066345215 109.0464782714844 7.80223560333252 108.8078918457031 7.413011074066162 108.7994232177734 C 6.722119331359863 108.7844543457031 6.030278205871582 108.7832946777344 5.339532852172852 108.8008880615234 C 4.930810451507568 108.8113250732422 4.703555583953857 109.0775756835938 4.697275638580322 109.4972534179688 C 4.692383289337158 109.8246307373047 4.696325778961182 110.1520690917969 4.696252822875977 110.4795227050781 M 6.386202812194824 101.3915252685547 C 6.049630165100098 101.3915252685547 5.713057041168213 101.3867797851562 5.376555919647217 101.3927001953125 C 4.95352029800415 101.4002227783203 4.701949119567871 101.6512756347656 4.698078632354736 102.0785522460938 C 4.692017555236816 102.7424926757812 4.692383289337158 103.4065856933594 4.697932243347168 104.0705261230469 C 4.701364517211914 104.4748687744141 4.923945903778076 104.7403259277344 5.323394298553467 104.7532501220703 C 6.004645824432373 104.7752227783203 6.68765115737915 104.7741317749023 7.369050025939941 104.7533187866211 C 7.779159545898438 104.7408294677734 8.053515434265137 104.4654541015625 8.06505298614502 104.0545349121094 C 8.084185600280762 103.3730010986328 8.082798004150391 102.6899871826172 8.060014724731445 102.0085906982422 C 8.047088623046875 101.6238250732422 7.781714916229248 101.4005889892578 7.39585018157959 101.3929138183594 C 7.059422492980957 101.3862686157227 6.722775936126709 101.3915252685547 6.386202812194824 101.3915252685547" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_o0jvhs =
    '<svg viewBox="0.0 0.0 26.3 5.4" ><path transform="translate(-0.33, 0.0)" d="M 26.6696949005127 5.427774429321289 L 0.3749136924743652 5.427774429321289 C 0.3749136924743652 4.272368431091309 0.3267900943756104 3.132882833480835 0.3898108601570129 1.999604225158691 C 0.442389041185379 1.052978277206421 1.21565318107605 -0.04962982982397079 2.672872066497803 0.003897670190781355 C 3.327908039093018 0.02799599803984165 3.984551429748535 0.007987082935869694 4.640537261962891 0.007987082935869694 L 4.938479900360107 0.007987082935869694 L 4.938479900360107 0.6029237508773804 C 4.938479900360107 1.176901936531067 4.93731164932251 1.750807285308838 4.938918113708496 2.324785709381104 C 4.940524578094482 2.923884630203247 5.263004302978516 3.298211812973022 5.77111291885376 3.294998645782471 C 6.270751953125 3.291858673095703 6.586002349853516 2.926586627960205 6.588338375091553 2.340558767318726 C 6.590968132019043 1.675518155097961 6.58906888961792 1.010404467582703 6.589142322540283 0.3453636467456818 L 6.589142322540283 0.0279229748994112 L 19.74128150939941 0.0279229748994112 C 19.7464656829834 0.1258498132228851 19.75573921203613 0.222243145108223 19.75595664978027 0.3186364471912384 C 19.75756454467773 1.029244899749756 19.75070381164551 1.73992645740509 19.7601203918457 2.450462102890015 C 19.76552391052246 2.8607177734375 20.00358772277832 3.168299913406372 20.3606071472168 3.269293785095215 C 20.68768692016602 3.361744165420532 21.07406425476074 3.244319200515747 21.24706077575684 2.943674325942993 C 21.34578895568848 2.772138357162476 21.3955192565918 2.551382780075073 21.40099716186523 2.351001739501953 C 21.41939926147461 1.677343726158142 21.40807914733887 1.002809882164001 21.40815353393555 0.3287139236927032 L 21.40815353393555 0.008060108870267868 C 22.22304344177246 0.008060108870267868 23.00506973266602 -0.0147967915982008 23.78483200073242 0.01777246594429016 C 24.16916465759277 0.03383801877498627 24.57182693481445 0.09517921507358551 24.92680168151855 0.235606774687767 C 25.82048606872559 0.5891948938369751 26.45916366577148 1.202825903892517 26.65122032165527 2.191806554794312 C 26.65991020202637 2.236425161361694 26.66889381408691 2.281919717788696 26.66896629333496 2.327049255371094 C 26.66991424560547 3.355098724365234 26.6696949005127 4.38307523727417 26.6696949005127 5.427774429321289" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_ezxow9 =
    '<svg viewBox="0.0 0.0 22.0 25.4" ><path transform="translate(0.0, 0.0)" d="M 0.5527756810188293 0 L 20.30935287475586 0 C 20.74086761474609 0.1968906968832016 20.86248970031738 0.5393438935279846 20.86189460754395 0.9996396899223328 C 20.85254287719727 8.029678344726562 20.86315536499023 15.05978298187256 20.84803581237793 22.08982086181641 C 20.84538269042969 23.30677795410156 21.14698600769043 24.38937759399414 21.93560981750488 25.32469177246094 C 21.94966888427734 25.34127044677734 21.95543479919434 25.36487770080566 21.97944259643555 25.41547584533691 L 21.74753952026367 25.41547584533691 C 15.7512903213501 25.41547584533691 9.755043983459473 25.41640663146973 3.758797645568848 25.4123592376709 C 3.504212617874146 25.41216087341309 3.244653940200806 25.39014434814453 2.995837926864624 25.33802032470703 C 1.218185305595398 24.9654598236084 0.008060225285589695 23.4691162109375 0.007529701106250286 21.64325332641602 C 0.005540236830711365 14.76209354400635 0.009718112647533417 7.880932331085205 -3.026432386832312e-05 0.9996396899223328 C -0.0006271037273108959 0.5384154915809631 0.1229186579585075 0.1978190988302231 0.5527756810188293 0 M 10.42834568023682 2.978427410125732 C 8.245306015014648 2.978427410125732 6.06226634979248 2.978228807449341 3.879226684570312 2.978494167327881 C 3.264415740966797 2.978560447692871 2.985360145568848 3.25655460357666 2.985227584838867 3.869641542434692 C 2.984896183013916 5.754923820495605 2.984962463378906 7.640273571014404 2.985227584838867 9.52562427520752 C 2.985293865203857 10.14375019073486 3.261697053909302 10.42413139343262 3.872130870819092 10.42419815063477 C 8.246432304382324 10.42446422576904 12.62073516845703 10.42446422576904 16.99510383605957 10.42419815063477 C 17.59267234802246 10.42413139343262 17.87663650512695 10.14109706878662 17.87683486938477 9.545120239257812 C 17.87736511230469 7.651480674743652 17.87729835510254 5.757908344268799 17.87683486938477 3.864269971847534 C 17.8767032623291 3.254300355911255 17.59625434875488 2.978494167327881 16.97739791870117 2.978494167327881 C 14.79442501068115 2.978228807449341 12.61138534545898 2.978427410125732 10.42834568023682 2.978427410125732 M 10.43106460571289 15.65469932556152 C 10.43106460571289 14.6874885559082 10.43219184875488 13.72021007537842 10.43059921264648 12.7529993057251 C 10.42973804473877 12.20821762084961 10.13297653198242 11.91410827636719 9.58454704284668 11.91384315490723 C 7.666636943817139 11.9129810333252 5.748726844787598 11.9129810333252 3.830816507339478 11.91384315490723 C 3.282586097717285 11.91410827636719 2.985824584960938 12.20848274230957 2.985559225082397 12.75339603424072 C 2.984498262405396 14.67130756378174 2.984630823135376 16.58921813964844 2.985426425933838 18.50712776184082 C 2.985691785812378 19.06802558898926 3.278872728347778 19.35894966125488 3.843681573867798 19.3591480255127 C 5.753303050994873 19.35994529724121 7.662923336029053 19.35994529724121 9.572544097900391 19.3591480255127 C 10.13695526123047 19.35894966125488 10.43000316619873 19.06782531738281 10.43073272705078 18.5067310333252 C 10.43192672729492 17.5560302734375 10.43106460571289 16.60533142089844 10.43106460571289 15.65469932556152 M 10.43404865264893 20.94800186157227 C 8.218381881713867 20.94800186157227 6.00264835357666 20.94674110412598 3.78691554069519 20.94879722595215 C 3.198365688323975 20.94932746887207 2.848816633224487 21.43210411071777 3.041330337524414 21.96806716918945 C 3.15652060508728 22.2888355255127 3.4028160572052 22.43685150146484 3.829821825027466 22.43691635131836 C 8.22819709777832 22.4372501373291 12.62657070159912 22.4371166229248 17.02494430541992 22.43698310852051 C 17.09106254577637 22.43698310852051 17.15764427185059 22.43917083740234 17.22316360473633 22.43234062194824 C 17.52642440795898 22.40084075927734 17.74287796020508 22.21960067749023 17.83114242553711 21.92728233337402 C 17.99116325378418 21.39715766906738 17.65229225158691 20.94946098327637 17.08124732971191 20.9488639831543 C 14.86551475524902 20.94667625427246 12.64978122711182 20.94800186157227 10.43404865264893 20.94800186157227 M 14.90006446838379 11.91351127624512 C 14.18146991729736 11.91351127624512 13.46280956268311 11.91238403320312 12.74414920806885 11.91390895843506 C 12.23338794708252 11.91503620147705 11.91878700256348 12.20689105987549 11.92614650726318 12.66824817657471 C 11.93344116210938 13.12191200256348 12.24081516265869 13.40169620513916 12.74063301086426 13.40216159820557 C 14.17788982391357 13.40361976623535 15.61514568328857 13.40355396270752 17.05246734619141 13.40222835540771 C 17.5639591217041 13.40176391601562 17.87776374816895 13.10964393615723 17.87053489685059 12.64768981933594 C 17.86343955993652 12.194091796875 17.55580139160156 11.91510391235352 17.05598258972168 11.91397666931152 C 16.3373851776123 11.91231727600098 15.61872673034668 11.91351127624512 14.90006446838379 11.91351127624512 M 14.90364646911621 14.89200592041016 C 14.18498420715332 14.89200592041016 13.46632480621338 14.89087867736816 12.74773025512695 14.89227104187012 C 12.23464679718018 14.89326477050781 11.92090797424316 15.18160438537598 11.92614650726318 15.64309501647949 C 11.93132019042969 16.09702301025391 12.23915672302246 16.3799934387207 12.73705196380615 16.38052368164062 C 14.17430877685547 16.38211441040039 15.61162948608398 16.38191413879395 17.04888725280762 16.38065528869629 C 17.56269836425781 16.38025856018066 17.87557411193848 16.09178352355957 17.87053489685059 15.62963199615479 C 17.86556243896484 15.17583465576172 17.55745887756348 14.89359760284424 17.05956268310547 14.89240264892578 C 16.34090232849121 14.89061260223389 15.62224102020264 14.89200592041016 14.90364646911621 14.89200592041016 M 14.89741230010986 17.87030029296875 C 14.17875194549561 17.87030029296875 13.46015739440918 17.86910629272461 12.74149513244629 17.87069892883301 C 12.2405481338501 17.871826171875 11.93304347991943 18.14982032775879 11.92614650726318 18.60288619995117 C 11.91911697387695 19.06470680236816 12.233717918396 19.35848617553711 12.74328708648682 19.35894966125488 C 14.1805419921875 19.36034202575684 15.6177978515625 19.36034202575684 17.05512046813965 19.35894966125488 C 17.55673027038574 19.35848617553711 17.86317443847656 19.08042526245117 17.87053489685059 18.62656211853027 C 17.87802886962891 18.16507339477539 17.56296348571777 17.871826171875 17.05332946777344 17.87069892883301 C 16.33466720581055 17.86910629272461 15.61607360839844 17.87030029296875 14.89741230010986 17.87030029296875" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_m7lbm =
    '<svg viewBox="22.4 4.5 3.0 20.4" ><path transform="translate(-316.0, -62.79)" d="M 341.4188842773438 85.62132263183594 C 341.3860473632812 85.73849487304688 341.3518371582031 85.85528564453125 341.320556640625 85.97285461425781 C 341.1766967773438 86.51393127441406 340.8992309570312 86.976806640625 340.4947814941406 87.36123657226562 C 340.1459045410156 87.69288635253906 339.71240234375 87.69480895996094 339.3651733398438 87.36077880859375 C 338.7504272460938 86.76930236816406 338.4407348632812 86.04348754882812 338.440673828125 85.1884765625 C 338.4403991699219 82.11111450195312 338.4405212402344 79.03380584716797 338.4405212402344 75.95643615722656 L 338.4405212402344 67.59298706054688 L 338.4405212402344 67.27016448974609 C 338.5165405273438 67.26473236083984 338.5868835449219 67.25544738769531 338.6571960449219 67.25531005859375 C 339.2445373535156 67.25411987304688 339.832763671875 67.27421569824219 340.4189147949219 67.2484130859375 C 340.8810119628906 67.22805786132812 341.2216796875 67.36970520019531 341.4188842773438 67.80068969726562 L 341.4188842773438 85.62132263183594 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_jm55xi =
    '<svg viewBox="0.0 0.0 18.4 25.4" ><path transform="translate(0.0, 0.0)" d="M 5.568893432617188 8.059867858886719 C 5.856408596038818 8.883779525756836 6.10267448425293 9.72054386138916 6.436210632324219 10.52098369598389 C 7.510081768035889 13.09822845458984 8.929572105407715 15.46776390075684 10.80242156982422 17.55094146728516 C 11.03221797943115 17.80659484863281 11.26994228363037 18.17453193664551 11.55314636230469 18.2275562286377 C 11.81357288360596 18.27634620666504 12.14356899261475 17.9764404296875 12.43724060058594 17.81944847106934 C 12.93600559234619 17.55278778076172 13.42876529693604 17.27473831176758 13.92691516876221 17.00669479370117 C 14.77714729309082 16.54910087585449 15.61899089813232 16.7772045135498 16.10190200805664 17.6055793762207 C 16.80221939086914 18.80689430236816 17.49792098999023 20.01090049743652 18.18661689758301 21.21891212463379 C 18.6790714263916 22.08253479003906 18.39216995239258 23.00803184509277 17.4946117401123 23.44130516052246 C 16.13945770263672 24.09537124633789 14.78061008453369 24.74197196960449 13.41529846191406 25.37441444396973 C 13.28177547454834 25.43628692626953 13.08037853240967 25.41443061828613 12.9303092956543 25.36771583557129 C 11.72961235046387 24.99431800842285 10.69321823120117 24.32401275634766 9.727165222167969 23.53911972045898 C 7.75580883026123 21.93739128112793 6.168011665344238 19.99397087097168 4.768684864044189 17.89163208007812 C 2.940778732299805 15.1456184387207 1.481116771697998 12.22106266021729 0.597023606300354 9.029999732971191 C 0.1671362817287445 7.478296756744385 -0.1021396964788437 5.903582096099854 0.03599989041686058 4.283077716827393 C 0.0539310909807682 4.072982311248779 0.09079396724700928 3.864503145217896 0.1082634255290031 3.654330730438232 C 0.1465115398168564 3.195276498794556 0.3607625663280487 2.885443449020386 0.7612519860267639 2.625094890594482 C 1.878835797309875 1.898303747177124 2.963789224624634 1.121412873268127 4.06251859664917 0.3655316531658173 C 4.990246772766113 -0.2726039290428162 5.900121212005615 -0.06566395610570908 6.467147350311279 0.9141650199890137 C 7.134835243225098 2.06784200668335 7.800597667694092 3.222673654556274 8.465130805969238 4.378274440765381 C 8.978594779968262 5.271295547485352 8.768807411193848 6.102056980133057 7.888715267181396 6.64522647857666 C 7.139144897460938 7.107897758483887 6.38480281829834 7.562796115875244 5.568893432617188 8.059867858886719" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_nagfe3 =
    '<svg viewBox="7.2 5.0 20.3 14.2" ><path transform="translate(-86.49, -60.18)" d="M 98.27153015136719 76.78385925292969 C 96.24338531494141 74.42726135253906 94.7239990234375 71.80052185058594 93.69899749755859 68.86712646484375 C 94.37129974365234 68.44893646240234 95.02044677734375 68.04521179199219 95.68505096435547 67.6317138671875 C 97.23367309570312 68.69303894042969 98.80039215087891 69.76676940917969 100.366943359375 70.84056091308594 C 101.0792694091797 71.32878112792969 101.7910537719727 71.81761169433594 102.5035247802734 72.30552673339844 C 102.9371109008789 72.60243225097656 103.1468200683594 72.60397338867188 103.5765533447266 72.3094482421875 C 106.9320831298828 70.0096435546875 110.2872161865234 67.70921325683594 113.6426544189453 65.40933227539062 C 113.7345428466797 65.34629821777344 113.8282089233398 65.285888671875 113.9603424072266 65.197998046875 C 113.9733505249023 65.36814880371094 113.9905853271484 65.48936462402344 113.9906616210938 65.61064147949219 C 113.9920501708984 69.76760864257812 113.9925842285156 73.92464447021484 113.9911193847656 78.08168029785156 C 113.9908905029297 78.88243103027344 113.5429229736328 79.34394836425781 112.7491836547852 79.34548950195312 C 110.2722854614258 79.35026550292969 107.7953109741211 79.34518432617188 105.3183441162109 79.3515625 C 105.1364135742188 79.35203552246094 105.0458374023438 79.28208923339844 104.9617919921875 79.13323974609375 C 104.5847015380859 78.465087890625 104.1996841430664 77.80140686035156 103.8126678466797 77.13894653320312 C 102.9134902954102 75.59971618652344 101.2680435180664 75.14457702636719 99.70418548583984 75.99989318847656 C 99.24151611328125 76.2529296875 98.77899932861328 76.50619506835938 98.27153015136719 76.78385925292969" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_lkynt9 =
    '<svg viewBox="9.9 4.2 16.3 6.6" ><path transform="translate(-118.95, -50.06)" d="M 128.8890075683594 56.3374137878418 C 129.1322784423828 55.640869140625 129.1258087158203 54.94508743286133 128.8619995117188 54.23099899291992 L 145.1671600341797 54.23099899291992 C 145.0770416259766 54.30149078369141 145.0164031982422 54.35435485839844 144.9504547119141 54.39960861206055 C 141.8822021484375 56.50418090820312 138.8121948242188 58.60597991943359 135.7483520507812 60.71685791015625 C 135.5588073730469 60.84745788574219 135.4403533935547 60.84830474853516 135.2506561279297 60.71716690063477 C 133.2001953125 59.29890823364258 131.1421203613281 57.8917350769043 129.0862426757812 56.48124694824219 C 129.0237579345703 56.43838119506836 128.9637298583984 56.39205551147461 128.8890075683594 56.3374137878418" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_gpfr1 =
    '<svg viewBox="0.0 0.0 23.9 31.1" ><path transform="translate(0.0, 0.0)" d="M 22.99616813659668 31.08617973327637 L 0.880160927772522 31.08617973327637 C 0.1705034971237183 30.8265323638916 -0.06708017736673355 30.30960083007812 0.01582662761211395 29.58158874511719 C 0.07181966304779053 29.08992195129395 0.0684167742729187 28.59155464172363 0.09368065744638443 28.09627532958984 C 0.2019544690847397 25.97359848022461 0.3101251721382141 23.85091400146484 0.4199457764625549 21.72833442687988 C 0.5533803701400757 19.1510066986084 0.688155472278595 16.57367897033691 0.8230336308479309 13.99634647369385 C 0.9171803593635559 12.19735145568848 1.003902435302734 10.39784049987793 1.111660838127136 8.59967041015625 C 1.153423547744751 7.903314590454102 1.587550044059753 7.516519546508789 2.281946182250977 7.511879444122314 C 3.22351598739624 7.505692005157471 4.165188789367676 7.510127067565918 5.106758594512939 7.510023593902588 L 5.476333141326904 7.510023593902588 C 5.476333141326904 7.198297500610352 5.478085994720459 6.91781759262085 5.476024150848389 6.637336254119873 C 5.468908786773682 5.664213180541992 5.623379230499268 4.721199989318848 6.03574800491333 3.834591865539551 C 7.429283142089844 0.8386039137840271 10.53529739379883 -0.6103060245513916 13.72195053100586 0.2412417829036713 C 16.2945384979248 0.9286258220672607 18.29234313964844 3.436659574508667 18.3772087097168 6.09442138671875 C 18.3919563293457 6.556182861328125 18.37937355041504 7.018872737884521 18.37937355041504 7.510023593902588 L 18.7703971862793 7.510023593902588 C 19.67154693603516 7.510023593902588 20.57269477844238 7.508991718292236 21.4737377166748 7.510332107543945 C 22.31579780578613 7.511569976806641 22.72332000732422 7.861758232116699 22.7701358795166 8.692373275756836 C 22.9308967590332 11.5419340133667 23.07732391357422 14.39232158660889 23.22426795959473 17.24260520935059 C 23.4368953704834 21.36649322509766 23.64509010314941 25.49059295654297 23.85534858703613 29.61458587646484 C 23.8991756439209 30.47365951538086 23.75893402099609 30.71444320678711 22.99616813659668 31.08617973327637 M 15.09506893157959 7.491256713867188 C 15.09506893157959 7.101676464080811 15.10507297515869 6.729936599731445 15.09331703186035 6.3589186668396 C 15.05320262908936 5.093971729278564 14.23372554779053 3.932554244995117 13.04023742675781 3.503170967102051 C 11.827467918396 3.066878795623779 10.72173500061035 3.300956964492798 9.775835037231445 4.169518947601318 C 8.79188346862793 5.073038578033447 8.680309295654297 6.246623516082764 8.807764053344727 7.491256713867188 L 15.09506893157959 7.491256713867188 Z M 7.044240951538086 9.626312255859375 C 6.382121086120605 9.63105583190918 5.85322904586792 10.16819763183594 5.859519958496094 10.8295955657959 C 5.865706443786621 11.48769378662109 6.408622264862061 12.01957607269287 7.068060874938965 12.01369762420654 C 7.72935676574707 12.00782012939453 8.252884864807129 11.47140121459961 8.247110366821289 10.80556869506836 C 8.241335868835449 10.13654041290283 7.715950489044189 9.621465682983398 7.044240951538086 9.626312255859375 M 15.62911796569824 10.80876541137695 C 15.62468338012695 11.47428894042969 16.14986228942871 12.00946998596191 16.81136322021484 12.01380157470703 C 17.47049331665039 12.01813220977783 18.01237869262695 11.48439407348633 18.01701927185059 10.82639789581299 C 18.02155685424805 10.16510391235352 17.49142837524414 9.629405975341797 16.8289966583252 9.626106262207031 C 16.15800857543945 9.622806549072266 15.63355159759521 10.13973617553711 15.62911796569824 10.80876541137695" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_aykux2 =
    '<svg viewBox="70.0 619.1 26.5 25.5" ><path transform="translate(22.0, 563.1)" d="M 67.36824798583984 55.99999618530273 L 67.30455780029297 55.99999618530273 C 64.77519989013672 55.99999618530273 62.53892517089844 57.33794784545898 61.2519645690918 59.31298446655273 C 59.96501159667969 57.33794784545898 57.72871780395508 55.99999618530273 55.19938659667969 55.99999618530273 L 55.13566207885742 55.99999618530273 C 51.19194412231445 56.03823089599609 48.00000381469727 59.2429084777832 48.00000381469727 63.19939422607422 C 48.00000381469727 65.55670166015625 49.03213119506836 68.90153503417969 51.04541015625 71.65388488769531 C 54.88083267211914 76.89733123779297 61.2519645690918 81.48454284667969 61.2519645690918 81.48454284667969 C 61.2519645690918 81.48454284667969 67.62310791015625 76.89733123779297 71.45850372314453 71.65388488769531 C 73.47179412841797 68.90153503417969 74.50392150878906 65.55670166015625 74.50392150878906 63.19939422607422 C 74.50392150878906 59.2429084777832 71.31198883056641 56.03823089599609 67.36824798583984 55.99999618530273 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_m8tva =
    '<svg viewBox="6.0 1.8 20.5 20.6" ><path transform="translate(-64.72, -19.06)" d="M 79.77439880371094 41.37229919433594 C 76.73456573486328 38.33297729492188 73.71732330322266 35.31615447998047 70.67800140380859 32.27733993530273 C 70.70825958251953 32.2122688293457 70.74678039550781 32.11846160888672 70.79397583007812 32.02911758422852 C 72.63982391357422 28.53996467590332 74.48634338378906 25.0511474609375 76.33311462402344 21.56241607666016 C 76.80081176757812 20.67885208129883 77.48849487304688 20.57754135131836 78.20037078857422 21.28882598876953 C 82.37948608398438 25.46431350708008 86.55825805664062 29.64022445678711 90.7366943359375 33.81647109985352 C 91.42851257324219 34.50786209106445 91.32896423339844 35.21518325805664 90.47330474853516 35.6720085144043 C 86.98213195800781 37.53606033325195 83.49018859863281 39.39859771728516 79.99833679199219 41.26138305664062 C 79.92475891113281 41.30057525634766 79.84898376464844 41.33546829223633 79.77439880371094 41.37229919433594" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_gzza =
    '<svg viewBox="1.7 15.7 10.9 10.9" ><path transform="translate(-18.76, -170.09)" d="M 24.22100830078125 185.7420043945312 C 26.59860992431641 188.1210327148438 28.95986175537109 190.4836273193359 31.34656524658203 192.8715972900391 C 31.28807067871094 192.9340515136719 31.22106170654297 193.0098266601562 31.14967346191406 193.0811309814453 C 30.30918121337891 193.9198608398438 29.46919631958008 194.7591705322266 28.62667846679688 195.5958709716797 C 27.28233337402344 196.9311218261719 25.45789337158203 196.9295959472656 24.11750793457031 195.5926666259766 C 23.23217582702637 194.7096099853516 22.34709548950195 193.8262939453125 21.4652214050293 192.9398803710938 C 20.16975784301758 191.6380004882812 20.15964317321777 189.79931640625 21.44583511352539 188.4988098144531 C 22.34709548950195 187.5873413085938 23.25830459594727 186.6855773925781 24.16555023193359 185.7798461914062 C 24.18013000488281 185.7653503417969 24.1999397277832 185.7561645507812 24.22100830078125 185.7420043945312" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_twafwq =
    '<svg viewBox="10.5 24.2 6.0 6.1" ><path transform="translate(-114.34, -262.79)" d="M 124.8649978637695 290.4646301269531 C 126.0078277587891 289.3412780761719 127.1907653808594 288.1785583496094 128.4131469726562 286.9769897460938 C 129.0975494384766 287.6942749023438 129.8375701904297 288.3585205078125 130.4406280517578 289.1298217773438 C 131.2057800292969 290.1083374023438 131.0035705566406 291.5517578125 130.0960693359375 292.3973693847656 C 129.1931304931641 293.2388916015625 127.7634887695312 293.3388366699219 126.8383636474609 292.5235595703125 C 126.1172256469727 291.8878784179688 125.4995880126953 291.134765625 124.8649978637695 290.4646301269531" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_qldvta =
    '<svg viewBox="0.0 23.0 5.2 5.3" ><path transform="translate(0.0, -249.58)" d="M 5.249168395996094 277.6021118164062 C 4.141576290130615 278.1103515625 2.405470371246338 277.74853515625 1.324512600898743 276.7493896484375 C 0.138872817158699 275.6536865234375 -0.2995787262916565 273.9754943847656 0.2093352377414703 272.5509948730469 C 1.703880190849304 274.41015625 3.394051074981689 276.0905456542969 5.249168395996094 277.6021118164062" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_x6onw =
    '<svg viewBox="21.2 3.0 4.1 4.1" ><path transform="translate(-230.3, -32.8)" d="M 254.43310546875 35.81700134277344 C 254.9591369628906 35.84886169433594 255.2727661132812 36.03353118896484 255.4482421875 36.41070556640625 C 255.6236419677734 36.78762817382812 255.5938873291016 37.17298126220703 255.3089141845703 37.47076034545898 C 254.6042175292969 38.20716094970703 253.8854217529297 38.93125534057617 253.1455688476562 39.63208770751953 C 252.7674713134766 39.99021530151367 252.1664276123047 39.93011856079102 251.802490234375 39.56128692626953 C 251.4381256103516 39.19211578369141 251.3875427246094 38.59394454956055 251.7467651367188 38.21710586547852 C 252.4499664306641 37.4793586730957 253.1741333007812 36.7607421875 253.9122314453125 36.05788803100586 C 254.0660552978516 35.91139984130859 254.3178100585938 35.86782455444336 254.43310546875 35.81700134277344" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_grpj7z =
    '<svg viewBox="17.2 0.0 2.0 4.0" ><path transform="translate(-186.45, 0.0)" d="M 205.6396789550781 2.020751714706421 C 205.6400146484375 2.357049703598022 205.6474304199219 2.693600416183472 205.6383361816406 3.029730081558228 C 205.6230773925781 3.599329471588135 205.1858062744141 4.033397674560547 204.6365203857422 4.036263465881348 C 204.0884094238281 4.039129257202148 203.6347961425781 3.604301929473877 203.6252746582031 3.040096998214722 C 203.6136474609375 2.357134103775024 203.613037109375 1.673581123352051 203.6256103515625 0.9906182885169983 C 203.6359710693359 0.4241374731063843 204.0886688232422 -0.004536992870271206 204.6409912109375 0.0005201183375902474 C 205.1775512695312 0.005492944736033678 205.6171875 0.4304589033126831 205.6369934082031 0.980335533618927 C 205.6494598388672 1.326663255691528 205.6393432617188 1.6739182472229 205.6396789550781 2.020751714706421" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_re93b8 =
    '<svg viewBox="24.2 9.1 4.0 2.0" ><path transform="translate(-263.29, -98.65)" d="M 289.5150756835938 109.7485656738281 C 289.1997680664062 109.7485656738281 288.8843383789062 109.7531127929688 288.5691223144531 109.7475509643555 C 287.9769287109375 109.7371826171875 287.5325927734375 109.3067398071289 287.5287170410156 108.74658203125 C 287.5248413085938 108.1822891235352 287.963623046875 107.7394561767578 288.5526733398438 107.7320404052734 C 289.2147521972656 107.7237777709961 289.8770751953125 107.7238616943359 290.5391235351562 107.7320404052734 C 291.125732421875 107.7392883300781 291.5683288574219 108.1854095458984 291.564208984375 108.7468338012695 C 291.56005859375 109.3078308105469 291.1168823242188 109.7373504638672 290.5240478515625 109.7475509643555 C 290.1878051757812 109.7532806396484 289.8513488769531 109.7485656738281 289.5150756835938 109.7485656738281" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
