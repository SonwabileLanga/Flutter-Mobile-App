import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import './LVIIWine.dart';
import 'package:adobe_xd/page_link.dart';
import './LXLCBulk.dart';
import './ProductReview.dart';
import './Bittersweetbook.dart';
import './MemberHome.dart';
import './Search.dart';
import './Profile.dart';
import 'package:flutter_svg/flutter_svg.dart';

class wishlist extends StatelessWidget {
  const wishlist({
    Key key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(size: 155.0, end: 17.0),
            Pin(size: 194.0, end: 81.0),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => const LVIIWine(),
                ),
              ],
              child: Stack(
                children: <Widget>[
                  SizedBox.expand(
                      child: SvgPicture.string(
                    _svg_u5d6pv,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  )),
                  Pinned.fromPins(
                    Pin(start: 0.0, end: 0.0),
                    Pin(size: 116.0, start: 0.0),
                    child: Container(
                      decoration: const BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(''),
                          fit: BoxFit.cover,
                        ),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(16.0),
                          topRight: Radius.circular(16.0),
                        ),
                      ),
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 17.5, end: 10.5),
                    Pin(size: 17.5, middle: 0.5411),
                    child: Stack(
                      children: <Widget>[
                        SizedBox.expand(
                            child: SvgPicture.string(
                          _svg_wkpk4v,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        )),
                        Center(
                          child: SizedBox(
                            width: 7.0,
                            height: 7.0,
                            child: SvgPicture.string(
                              _svg_f9bi5,
                              allowDrawingOutsideViewBox: true,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(start: 8.6, end: 17.4),
                    Pin(size: 26.0, middle: 0.7411),
                    child: const Text(
                      'LVII CABERNET SAUVIGNON \n2016 LIMITED EDITION',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xff707070),
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 63.0, start: 20.6),
                    Pin(size: 13.0, end: 10.5),
                    child: const Text(
                      'louis57 Online',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xff707070),
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 37.0, start: 8.6),
                    Pin(size: 13.0, end: 28.5),
                    child: const Text(
                      'R650.00',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xfff60707),
                        fontWeight: FontWeight.w500,
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 10.7, start: 8.6),
                    Pin(size: 13.1, end: 12.4),
                    child: SvgPicture.string(
                      _svg_v0etfk,
                      allowDrawingOutsideViewBox: true,
                      fit: BoxFit.fill,
                    ),
                  ),
                  Container(),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 155.0, start: 18.0),
            Pin(size: 194.0, end: 81.0),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => const LXLCBulk(),
                ),
              ],
              child: Stack(
                children: <Widget>[
                  SizedBox.expand(
                      child: SvgPicture.string(
                    _svg_b8ea97,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  )),
                  Pinned.fromPins(
                    Pin(start: 0.0, end: 0.0),
                    Pin(size: 116.0, start: 0.0),
                    child: Container(
                      decoration: const BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(''),
                          fit: BoxFit.cover,
                        ),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(16.0),
                          topRight: Radius.circular(16.0),
                        ),
                      ),
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 17.5, end: 9.0),
                    Pin(size: 17.5, middle: 0.5411),
                    child: Stack(
                      children: <Widget>[
                        SizedBox.expand(
                            child: SvgPicture.string(
                          _svg_wkpk4v,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        )),
                        Center(
                          child: SizedBox(
                            width: 7.0,
                            height: 7.0,
                            child: SvgPicture.string(
                              _svg_f9bi5,
                              allowDrawingOutsideViewBox: true,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 88.0, start: 9.5),
                    Pin(size: 13.0, middle: 0.6878),
                    child: const Text(
                      'LXLC-Bulk-Meter2-1',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xff707070),
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 99.0, start: 21.5),
                    Pin(size: 13.0, end: 10.5),
                    child: const Text(
                      'SA Metering Solutions',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xff707070),
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 43.0, start: 9.5),
                    Pin(size: 13.0, end: 28.5),
                    child: const Text(
                      'R4450.00',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xfff60707),
                        fontWeight: FontWeight.w500,
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 10.7, start: 9.5),
                    Pin(size: 13.1, end: 12.4),
                    child: SvgPicture.string(
                      _svg_lvyzu,
                      allowDrawingOutsideViewBox: true,
                      fit: BoxFit.fill,
                    ),
                  ),
                  Container(),
                  Pinned.fromPins(
                    Pin(start: 0.0, end: 0.0),
                    Pin(size: 1.0, middle: 0.6114),
                    child: SvgPicture.string(
                      _svg_lvtv,
                      allowDrawingOutsideViewBox: true,
                      fit: BoxFit.fill,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 155.0, start: 18.0),
            Pin(size: 194.0, middle: 0.4968),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => const ProductReview(),
                ),
              ],
              child: Stack(
                children: <Widget>[
                  SizedBox.expand(
                      child: SvgPicture.string(
                    _svg_v6qxih,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  )),
                  Pinned.fromPins(
                    Pin(start: 7.0, end: 18.0),
                    Pin(size: 26.0, middle: 0.7202),
                    child: const Text(
                      '1 Panel Framed Ibr/Corr Port \nPackaged',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xff707070),
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 55.0, start: 19.0),
                    Pin(size: 13.0, end: 14.0),
                    child: const Text(
                      ' Invest Solar',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xff707070),
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 37.0, start: 7.0),
                    Pin(size: 13.0, middle: 0.8232),
                    child: const Text(
                      'R552.00',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xfff60707),
                        fontWeight: FontWeight.w500,
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(start: 21.0, end: 20.0),
                    Pin(size: 114.0, start: 0.0),
                    child: Container(
                      decoration: const BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(''),
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 17.5, end: 9.5),
                    Pin(size: 17.5, middle: 0.5297),
                    child: Stack(
                      children: <Widget>[
                        SizedBox.expand(
                            child: SvgPicture.string(
                          _svg_wkpk4v,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        )),
                        Center(
                          child: SizedBox(
                            width: 7.0,
                            height: 7.0,
                            child: SvgPicture.string(
                              _svg_f9bi5,
                              allowDrawingOutsideViewBox: true,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(start: 0.0, end: 0.0),
                    Pin(size: 1.0, middle: 0.601),
                    child: SvgPicture.string(
                      _svg_pdazp1,
                      allowDrawingOutsideViewBox: true,
                      fit: BoxFit.fill,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 10.7, start: 7.0),
                    Pin(size: 13.1, end: 15.9),
                    child: SvgPicture.string(
                      _svg_k8ou4z,
                      allowDrawingOutsideViewBox: true,
                      fit: BoxFit.fill,
                    ),
                  ),
                  Container(),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 155.0, end: 17.0),
            Pin(size: 194.0, middle: 0.4968),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => const Bittersweetbook(),
                ),
              ],
              child: Stack(
                children: <Widget>[
                  SizedBox.expand(
                      child: SvgPicture.string(
                    _svg_ssvmij,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  )),
                  Pinned.fromPins(
                    Pin(start: 0.0, end: 0.0),
                    Pin(size: 116.0, start: 0.0),
                    child: Container(
                      decoration: const BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(''),
                          fit: BoxFit.cover,
                        ),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(16.0),
                          topRight: Radius.circular(16.0),
                        ),
                      ),
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 17.5, end: 10.5),
                    Pin(size: 17.5, middle: 0.5411),
                    child: Stack(
                      children: <Widget>[
                        SizedBox.expand(
                            child: SvgPicture.string(
                          _svg_wkpk4v,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        )),
                        Center(
                          child: SizedBox(
                            width: 7.0,
                            height: 7.0,
                            child: SvgPicture.string(
                              _svg_f9bi5,
                              allowDrawingOutsideViewBox: true,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 50.0, start: 9.5),
                    Pin(size: 26.0, middle: 0.7089),
                    child: const Text(
                      'Bittersweet\nSusan Cain',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xff707070),
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 72.0, start: 21.5),
                    Pin(size: 13.0, end: 15.9),
                    child: const Text(
                      'Exclusive Books',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xff707070),
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 37.0, start: 9.5),
                    Pin(size: 13.0, middle: 0.8127),
                    child: const Text(
                      'R358.00',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xfff60707),
                        fontWeight: FontWeight.w500,
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 10.7, start: 9.5),
                    Pin(size: 13.1, end: 17.8),
                    child: SvgPicture.string(
                      _svg_gn4xvl,
                      allowDrawingOutsideViewBox: true,
                      fit: BoxFit.fill,
                    ),
                  ),
                  Container(),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 61.0, middle: 0.5),
            Pin(size: 23.0, start: 126.0),
            child: const Text(
              'Wishlist',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 17,
                color: Color(0xff004c98),
                fontWeight: FontWeight.w700,
                height: 0.7058823529411765,
              ),
              textHeightBehavior:
                  TextHeightBehavior(applyHeightToFirstAscent: false),
              softWrap: false,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 10.0, end: 10.0),
            Pin(size: 121.0, middle: 0.2388),
            child: Stack(
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xffffffff),
                    border:
                        Border.all(width: 1.0, color: const Color(0xff707070)),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 64.0, end: 0.0),
            child: Stack(
              children: <Widget>[
                Container(
                  decoration: const BoxDecoration(
                    color: Color(0xffecf9fe),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0xffffffff),
                        offset: Offset(0, -13),
                        blurRadius: 26,
                      ),
                    ],
                  ),
                ),
                Align(
                  alignment: const Alignment(0.259, -0.2),
                  child: SizedBox(
                    width: 25.0,
                    height: 24.0,
                    child: SvgPicture.string(
                      _svg_dbt3z,
                      allowDrawingOutsideViewBox: true,
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 30.9, start: 25.0),
                  Pin(size: 24.0, middle: 0.4),
                  child: PageLink(
                    links: [
                      PageLinkInfo(
                        transition: LinkTransition.Fade,
                        ease: Curves.easeOut,
                        duration: 0.3,
                        pageBuilder: () => const MemberHome(),
                      ),
                    ],
                    child: SvgPicture.string(
                      _svg_czb,
                      allowDrawingOutsideViewBox: true,
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
                Align(
                  alignment: const Alignment(-0.317, -0.2),
                  child: SizedBox(
                    width: 24.0,
                    height: 24.0,
                    child: PageLink(
                      links: [
                        PageLinkInfo(
                          transition: LinkTransition.Fade,
                          ease: Curves.easeOut,
                          duration: 0.3,
                          pageBuilder: () => const Search(),
                        ),
                      ],
                      child: SvgPicture.string(
                        _svg_feo4dn,
                        allowDrawingOutsideViewBox: true,
                      ),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 24.0, end: 29.2),
                  Pin(size: 24.0, middle: 0.4),
                  child: PageLink(
                    links: [
                      PageLinkInfo(
                        transition: LinkTransition.Fade,
                        ease: Curves.easeOut,
                        duration: 0.3,
                        pageBuilder: () => const Profile(),
                      ),
                    ],
                    child: SvgPicture.string(
                      _svg_q1qd0a,
                      allowDrawingOutsideViewBox: true,
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 119.0, start: 0.0),
            child: Stack(
              children: <Widget>[
                SizedBox.expand(
                    child: SvgPicture.string(
                  _svg_jzx0na,
                  allowDrawingOutsideViewBox: true,
                  fit: BoxFit.fill,
                )),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 44.0, start: 0.0),
                  child: Stack(
                    children: <Widget>[
                      SizedBox.expand(
                          child: SvgPicture.string(
                        _svg_mhz2ca,
                        allowDrawingOutsideViewBox: true,
                        fit: BoxFit.fill,
                      )),
                      Pinned.fromPins(
                        Pin(start: 20.0, end: 14.7),
                        Pin(size: 16.0, middle: 0.5357),
                        child: Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(size: 24.3, end: 0.0),
                              Pin(start: 2.3, end: 2.3),
                              child: Stack(
                                children: <Widget>[
                                  Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(0.0, 0.0, 2.3, 0.0),
                                    child: Stack(
                                      children: <Widget>[
                                        SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_i4lwc,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                        SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_hn,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                      ],
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.centerRight,
                                    child: SizedBox(
                                      width: 1.0,
                                      height: 4.0,
                                      child: Stack(
                                        children: <Widget>[
                                          Padding(
                                            padding: const EdgeInsets.all(-5.0),
                                            child: SizedBox.expand(
                                                child: SvgPicture.string(
                                              _svg_tszyk4,
                                              allowDrawingOutsideViewBox: true,
                                              fit: BoxFit.fill,
                                            )),
                                          ),
                                          SizedBox.expand(
                                              child: SvgPicture.string(
                                            _svg_w6qqk0,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          )),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 18.0, start: 2.0),
                                    Pin(size: 7.3, middle: 0.5),
                                    child: Stack(
                                      children: <Widget>[
                                        Padding(
                                          padding: const EdgeInsets.all(-5.0),
                                          child: SizedBox.expand(
                                              child: SvgPicture.string(
                                            _svg_hy2fm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          )),
                                        ),
                                        SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_avi4k,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 15.3, end: 29.4),
                              Pin(size: 11.0, start: 2.3),
                              child: Stack(
                                children: <Widget>[
                                  Stack(
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.all(-5.0),
                                        child: SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_tav08,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                      ),
                                      SizedBox.expand(
                                          child: SvgPicture.string(
                                        _svg_iki5el,
                                        allowDrawingOutsideViewBox: true,
                                        fit: BoxFit.fill,
                                      )),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 17.0, end: 49.7),
                              Pin(size: 10.7, middle: 0.5),
                              child: Stack(
                                children: <Widget>[
                                  Stack(
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.all(-5.0),
                                        child: SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_nqpuq1,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                      ),
                                      SizedBox.expand(
                                          child: SvgPicture.string(
                                        _svg_n4r2,
                                        allowDrawingOutsideViewBox: true,
                                        fit: BoxFit.fill,
                                      )),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 54.0, start: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child: Stack(
                                children: <Widget>[
                                  SizedBox.expand(
                                      child: SvgPicture.string(
                                    _svg_u6yej,
                                    allowDrawingOutsideViewBox: true,
                                    fit: BoxFit.fill,
                                  )),
                                  Pinned.fromPins(
                                    Pin(start: 12.8, end: 13.7),
                                    Pin(size: 10.3, end: 0.8),
                                    child: SvgPicture.string(
                                      _svg_snrsq,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Container(),
                Container(),
                Container(),
                Align(
                  alignment: const Alignment(-0.099, 0.255),
                  child: SizedBox(
                    width: 81.0,
                    height: 57.0,
                    child: Stack(
                      children: <Widget>[
                        Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(size: 10.0, end: 6.7),
                              child: SvgPicture.string(
                                _svg_pyv499,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(start: 12.1, end: 12.1),
                              Pin(size: 3.6, end: 0.0),
                              child: SvgPicture.string(
                                _svg_vlvtax,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(start: 14.5, end: 14.5),
                              Pin(size: 30.6, start: 0.0),
                              child: SvgPicture.string(
                                _svg_iv1,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Container(
                              decoration: const BoxDecoration(),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_u5d6pv =
    '<svg viewBox="203.0 1187.0 155.0 194.0" ><path transform="translate(203.0, 1187.0)" d="M 17 0 L 138 0 C 147.3888397216797 0 155 7.61115837097168 155 17 L 155 177 C 155 186.3888397216797 147.3888397216797 194 138 194 L 17 194 C 7.61115837097168 194 0 186.3888397216797 0 177 L 0 17 C 0 7.61115837097168 7.61115837097168 0 17 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_wkpk4v =
    '<svg viewBox="296.0 464.0 17.5 17.5" ><path transform="translate(296.0, 464.0)" d="M 8.75 0 C 13.58249187469482 0 17.5 3.917508602142334 17.5 8.75 C 17.5 13.58249187469482 13.58249187469482 17.5 8.75 17.5 C 3.917508602142334 17.5 0 13.58249187469482 0 8.75 C 0 3.917508602142334 3.917508602142334 0 8.75 0 Z" fill="#fe4365" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_f9bi5 =
    '<svg viewBox="301.2 469.2 7.3 7.0" ><path transform="translate(253.25, 413.25)" d="M 53.31999969482422 55.99999618530273 L 53.30250549316406 55.99999618530273 C 52.60774993896484 55.99999618530273 51.99349975585938 56.36750030517578 51.64000701904297 56.90999221801758 C 51.28650665283203 56.36750030517578 50.67224884033203 55.99999618530273 49.97750854492188 55.99999618530273 L 49.95999908447266 55.99999618530273 C 48.87675476074219 56.010498046875 48.00000762939453 56.8907470703125 48.00000762939453 57.97749710083008 C 48.00000762939453 58.62499618530273 48.28350067138672 59.54374313354492 48.83650207519531 60.29974365234375 C 49.89000701904297 61.739990234375 51.64000701904297 62.99999237060547 51.64000701904297 62.99999237060547 C 51.64000701904297 62.99999237060547 53.39000701904297 61.739990234375 54.44349670410156 60.29974365234375 C 54.99650573730469 59.54374313354492 55.27999877929688 58.62499618530273 55.27999877929688 57.97749710083008 C 55.27999877929688 56.8907470703125 54.40325164794922 56.010498046875 53.31999969482422 55.99999618530273 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_v0etfk =
    '<svg viewBox="211.6 1355.5 10.7 13.1" ><path transform="translate(207.07, 1354.0)" d="M 9.856934547424316 1.5 L 4.5 3.880859375 L 4.5 7.452147960662842 C 4.5 10.75559139251709 6.785625457763672 13.84475612640381 9.856934547424316 14.59472751617432 C 12.92824268341064 13.84475612640381 15.2138671875 10.75559139251709 15.2138671875 7.452147960662842 L 15.2138671875 3.880859375 L 9.856934547424316 1.5 Z M 8.666504859924316 11.02343845367432 L 6.28564453125 8.642579078674316 L 7.124897956848145 7.803325176239014 L 8.666504859924316 9.338979721069336 L 12.58897018432617 5.416513442993164 L 13.42822360992432 6.261719226837158 L 8.666504859924316 11.02343845367432 Z" fill="#077f33" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_b8ea97 =
    '<svg viewBox="18.0 1187.0 155.0 194.0" ><path transform="translate(18.0, 1187.0)" d="M 17 0 L 138 0 C 147.3888397216797 0 155 7.61115837097168 155 17 L 155 177 C 155 186.3888397216797 147.3888397216797 194 138 194 L 17 194 C 7.61115837097168 194 0 186.3888397216797 0 177 L 0 17 C 0 7.61115837097168 7.61115837097168 0 17 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_lvyzu =
    '<svg viewBox="27.5 1355.5 10.7 13.1" ><path transform="translate(23.03, 1354.0)" d="M 9.856934547424316 1.5 L 4.5 3.880859375 L 4.5 7.452147960662842 C 4.5 10.75559139251709 6.785625457763672 13.84475612640381 9.856934547424316 14.59472751617432 C 12.92824268341064 13.84475612640381 15.2138671875 10.75559139251709 15.2138671875 7.452147960662842 L 15.2138671875 3.880859375 L 9.856934547424316 1.5 Z M 8.666504859924316 11.02343845367432 L 6.28564453125 8.642579078674316 L 7.124897956848145 7.803325176239014 L 8.666504859924316 9.338979721069336 L 12.58897018432617 5.416513442993164 L 13.42822360992432 6.261719226837158 L 8.666504859924316 11.02343845367432 Z" fill="#077f33" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_lvtv =
    '<svg viewBox="18.0 1305.0 155.0 1.0" ><path transform="translate(18.0, 1305.0)" d="M 155 0 L 0 0" fill="none" stroke="#707070" stroke-width="0.20000000298023224" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_v6qxih =
    '<svg viewBox="18.0 957.0 155.0 194.0" ><path transform="translate(18.0, 957.0)" d="M 17 0 L 138 0 C 147.3888397216797 0 155 7.611157894134521 155 17 L 155 177 C 155 186.3888397216797 147.3888397216797 194 138 194 L 17 194 C 7.61115837097168 194 0 186.3888397216797 0 177 L 0 17 C 0 7.611157894134521 7.61115837097168 0 17 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_pdazp1 =
    '<svg viewBox="18.0 1073.0 155.0 1.0" ><path transform="translate(18.0, 1073.0)" d="M 155 0 L 0 0" fill="none" stroke="#707070" stroke-width="0.20000000298023224" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_k8ou4z =
    '<svg viewBox="25.0 1122.0 10.7 13.1" ><path transform="translate(20.5, 1120.5)" d="M 9.856934547424316 1.5 L 4.5 3.880859375 L 4.5 7.452147960662842 C 4.5 10.75559139251709 6.785625457763672 13.84475612640381 9.856934547424316 14.59472751617432 C 12.92824268341064 13.84475612640381 15.2138671875 10.75559139251709 15.2138671875 7.452147960662842 L 15.2138671875 3.880859375 L 9.856934547424316 1.5 Z M 8.666504859924316 11.02343845367432 L 6.28564453125 8.642579078674316 L 7.124897956848145 7.803325176239014 L 8.666504859924316 9.338979721069336 L 12.58897018432617 5.416513442993164 L 13.42822360992432 6.261719226837158 L 8.666504859924316 11.02343845367432 Z" fill="#077f33" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_ssvmij =
    '<svg viewBox="203.0 957.0 155.0 194.0" ><path transform="translate(203.0, 957.0)" d="M 17 0 L 138 0 C 147.3888397216797 0 155 7.61115837097168 155 17 L 155 177 C 155 186.3888397216797 147.3888397216797 194 138 194 L 17 194 C 7.61115837097168 194 0 186.3888397216797 0 177 L 0 17 C 0 7.61115837097168 7.61115837097168 0 17 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_gn4xvl =
    '<svg viewBox="212.5 1120.1 10.7 13.1" ><path transform="translate(208.03, 1118.59)" d="M 9.856934547424316 1.5 L 4.5 3.880859375 L 4.5 7.452147960662842 C 4.5 10.75559139251709 6.785625457763672 13.84475612640381 9.856934547424316 14.59472751617432 C 12.92824268341064 13.84475612640381 15.2138671875 10.75559139251709 15.2138671875 7.452147960662842 L 15.2138671875 3.880859375 L 9.856934547424316 1.5 Z M 8.666504859924316 11.02343845367432 L 6.28564453125 8.642579078674316 L 7.124897956848145 7.803325176239014 L 8.666504859924316 9.338979721069336 L 12.58897018432617 5.416513442993164 L 13.42822360992432 6.261719226837158 L 8.666504859924316 11.02343845367432 Z" fill="#077f33" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_dbt3z =
    '<svg viewBox="220.4 764.0 25.0 24.0" ><path transform="translate(172.42, 708.0)" d="M 66.23999786376953 55.99999237060547 L 66.18001556396484 55.99999237060547 C 63.79799270629883 55.99999237060547 61.69198608398438 57.26000213623047 60.47999954223633 59.11999130249023 C 59.26801300048828 57.26000213623047 57.16199111938477 55.99999237060547 54.78000259399414 55.99999237060547 L 54.71998977661133 55.99999237060547 C 51.00600051879883 56.0359992980957 48.00000381469727 59.05399703979492 48.00000381469727 62.78000640869141 C 48.00000381469727 64.99998474121094 48.97200775146484 68.14997100830078 50.86800384521484 70.74198913574219 C 54.48000335693359 75.67999267578125 60.47999954223633 79.99998474121094 60.47999954223633 79.99998474121094 C 60.47999954223633 79.99998474121094 66.48001098632812 75.67999267578125 70.09197998046875 70.74198913574219 C 71.98799133300781 68.14997100830078 72.95999908447266 64.99998474121094 72.95999908447266 62.78000640869141 C 72.95999908447266 59.05399703979492 69.95400238037109 56.0359992980957 66.23999786376953 55.99999237060547 Z" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_czb =
    '<svg viewBox="25.0 764.0 30.9 24.0" ><path transform="translate(25.0, 761.75)" d="M 15.0212574005127 8.479752540588379 L 5.143179893493652 16.61549186706543 L 5.143179893493652 25.39630126953125 C 5.143179893493652 25.8697395324707 5.526978969573975 26.2535400390625 6.000419139862061 26.2535400390625 L 12.00430965423584 26.23800277709961 C 12.47607612609863 26.23564720153809 12.85726928710938 25.85253524780273 12.85726261138916 25.38076400756836 L 12.85726261138916 20.25286483764648 C 12.85726261138916 19.7794246673584 13.24106216430664 19.3956241607666 13.71450233459473 19.3956241607666 L 17.14345932006836 19.3956241607666 C 17.61690139770508 19.3956241607666 18.00069808959961 19.7794246673584 18.00069808959961 20.25286483764648 L 18.00069808959961 25.37701225280762 C 17.9999885559082 25.60482978820801 18.08998680114746 25.82356071472168 18.25082778930664 25.98490715026855 C 18.41166877746582 26.14624977111816 18.63011932373047 26.2369327545166 18.85793876647949 26.2369327545166 L 24.85968399047852 26.2535400390625 C 25.3331241607666 26.2535400390625 25.7169246673584 25.8697395324707 25.7169246673584 25.39630126953125 L 25.7169246673584 16.60959815979004 L 15.84099102020264 8.479752540588379 C 15.60176563262939 8.286923408508301 15.26048374176025 8.286923408508301 15.0212574005127 8.479752540588379 Z M 30.62462043762207 14.00948143005371 L 26.14554595947266 10.31746006011963 L 26.14554595947266 2.896445512771606 C 26.14554595947266 2.541365146636963 25.85769653320312 2.253515958786011 25.50261497497559 2.253515958786011 L 22.50227546691895 2.253515958786011 C 22.14719772338867 2.253515958786011 21.85934829711914 2.541365146636963 21.85934829711914 2.896445512771606 L 21.85934829711914 6.786704540252686 L 17.06255722045898 2.840189218521118 C 16.11320686340332 2.058967351913452 14.74368667602539 2.058967351913452 13.79433250427246 2.840189218521118 L 0.232269823551178 14.00948143005371 C -0.04153881967067719 14.2357931137085 -0.07992671430110931 14.64126777648926 0.1465460658073425 14.91494274139404 L 1.512771248817444 16.57584381103516 C 1.62122917175293 16.70772361755371 1.777693033218384 16.79104423522949 1.947655081748962 16.80742645263672 C 2.117616891860962 16.82380867004395 2.287114858627319 16.77190971374512 2.418766260147095 16.66317558288574 L 15.0212574005127 6.283076286315918 C 15.26048374176025 6.090249538421631 15.60176563262939 6.090249538421631 15.84099292755127 6.283077239990234 L 28.44401931762695 16.66317558288574 C 28.71769332885742 16.88964653015137 29.12317085266113 16.85125923156738 29.34947967529297 16.57745170593262 L 30.7157039642334 14.91654872894287 C 30.82434844970703 14.78436374664307 30.87581825256348 14.61432647705078 30.85872268676758 14.44408130645752 C 30.84162712097168 14.27383613586426 30.75737762451172 14.1174259185791 30.6246280670166 14.00948143005371 Z" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_feo4dn =
    '<svg viewBox="119.9 764.0 24.0 24.0" ><path transform="translate(118.51, 762.56)" d="M 19.00174140930176 15.8081750869751 C 19.89999771118164 14.33287715911865 20.37506866455078 12.63889312744141 20.37495803833008 10.91165256500244 C 20.37495803833008 5.679129600524902 16.14104461669922 1.442086458206177 10.90747833251953 1.439999461174011 C 5.678608417510986 1.441565036773682 1.440000057220459 5.679130077362061 1.440000057220459 10.91061019897461 C 1.440000057220459 16.13739204406738 5.679130077362061 20.37443542480469 10.91060924530029 20.37443542480469 C 12.70539283752441 20.37443542480469 14.37756538391113 19.8673038482666 15.80660915374756 19.00069618225098 L 22.24643707275391 25.44000244140625 L 25.44000244140625 22.244873046875 L 19.00174140930176 15.8081750869751 Z M 10.90956592559814 16.76869583129883 C 7.673740386962891 16.7608699798584 5.0577392578125 14.14591312408447 5.052000045776367 10.91687107086182 C 5.056597709655762 7.6835618019104 7.676260471343994 5.063432216644287 10.90956687927246 5.058260440826416 C 14.14382743835449 5.06660795211792 16.7608699798584 7.681565761566162 16.76765251159668 10.91687107086182 C 16.7608699798584 14.14226150512695 14.14278316497803 16.7608699798584 10.90956592559814 16.76869583129883 Z" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_q1qd0a =
    '<svg viewBox="321.8 764.0 24.0 24.0" ><path transform="translate(273.84, 716.0)" d="M 60 48 C 53.79808044433594 48 48.69807434082031 52.70192718505859 48.06922912597656 58.73654174804688 C 48.02307891845703 59.15192413330078 48 59.57308197021484 48 60 C 48 60.42692565917969 48.02307891845703 60.84808349609375 48.06922912597656 61.26345825195312 C 48.69807434082031 67.29808044433594 53.79808044433594 72 60 72 C 66.62884521484375 72 72 66.62884521484375 72 60 C 72 53.37115478515625 66.62884521484375 48 60 48 Z M 67.83461761474609 66.81346130371094 C 66.52500152587891 66.31730651855469 64.40192413330078 65.59038543701172 63.08077239990234 65.19808197021484 C 62.94230651855469 65.15769958496094 62.92500305175781 65.14615631103516 62.92500305175781 64.58077239990234 C 62.92500305175781 64.11346435546875 63.11538696289062 63.64038848876953 63.30577087402344 63.23654174804688 C 63.51345825195312 62.80384826660156 63.75 62.07115173339844 63.83654022216797 61.41346740722656 C 64.07884979248047 61.13076782226562 64.41346740722656 60.57692718505859 64.62115478515625 59.51538848876953 C 64.80577087402344 58.58077239990234 64.71923828125 58.24038696289062 64.59808349609375 57.92308044433594 C 64.58654022216797 57.88845825195312 64.56923675537109 57.85385131835938 64.56346130371094 57.82500457763672 C 64.51731109619141 57.60577392578125 64.58077239990234 56.46923065185547 64.7423095703125 55.58654022216797 C 64.8519287109375 54.98077392578125 64.71346282958984 53.69422912597656 63.8826904296875 52.62692260742188 C 63.35769653320312 51.95192718505859 62.34808349609375 51.12692260742188 60.5076904296875 51.01153564453125 L 59.49807739257812 51.01153564453125 C 57.68653869628906 51.12692260742188 56.68269348144531 51.95192718505859 56.15193176269531 52.62692260742188 C 55.31538391113281 53.69422912597656 55.17692565917969 54.98077392578125 55.28654479980469 55.58654022216797 C 55.44808197021484 56.46923065185547 55.51154327392578 57.60577392578125 55.46539306640625 57.82500457763672 C 55.45384979248047 57.86538696289062 55.44231414794922 57.89423370361328 55.43077087402344 57.92884826660156 C 55.30961608886719 58.24615478515625 55.21731567382812 58.58654022216797 55.40769958496094 59.52115631103516 C 55.62115478515625 60.58269500732422 55.95000457763672 61.13654327392578 56.19231414794922 61.41923522949219 C 56.27885437011719 62.07692718505859 56.52115631103516 62.80384826660156 56.72308349609375 63.2423095703125 C 56.87307739257812 63.55961608886719 56.94231414794922 63.9923095703125 56.94231414794922 64.60385131835938 C 56.94231414794922 65.17500305175781 56.91923522949219 65.18077087402344 56.79231262207031 65.22116088867188 C 55.42500305175781 65.625 53.39423370361328 66.34039306640625 52.17692565917969 66.82500457763672 C 50.51538848876953 64.92692565917969 49.61538696289062 62.53269958496094 49.61538696289062 60 C 49.61538696289062 57.22500610351562 50.69422912597656 54.6173095703125 52.65576934814453 52.65576934814453 C 54.6173095703125 50.69422912597656 57.22500610351562 49.61538696289062 60 49.61538696289062 C 62.77500152587891 49.61538696289062 65.3826904296875 50.69422912597656 67.34423065185547 52.65576934814453 C 69.30577087402344 54.6173095703125 70.38461303710938 57.22500610351562 70.38461303710938 60 C 70.38461303710938 62.53269958496094 69.484619140625 64.92692565917969 67.83461761474609 66.81346130371094 Z" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_i4lwc =
    '<svg viewBox="336.0 17.3 22.0 11.3" ><path transform="translate(336.0, 17.33)" d="M 2.666666984558105 0 L 19.33333015441895 0 L 19.33333015441895 0 C 20.80608940124512 0 22 1.193907022476196 22 2.666666984558105 L 22 8.666666984558105 L 22 8.666666984558105 C 22 10.13943004608154 20.80608940124512 11.33333015441895 19.33333015441895 11.33333015441895 L 2.666666984558105 11.33333015441895 L 2.666666984558105 11.33333015441895 C 1.193907022476196 11.33333015441895 0 10.13943004608154 0 8.666666984558105 L 0 2.666666984558105 L 0 2.666666984558105 C 0 1.193907022476196 1.193907022476196 0 2.666666984558105 0 Z" fill="none" stroke="#000000" stroke-width="2" stroke-opacity="0.35" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_hn =
    '<svg viewBox="336.0 17.3 22.0 11.3" ><path transform="translate(0.0, 44.0)" d="M 338.6666870117188 -26.66666984558105 L 355.3333129882812 -26.66666984558105 L 355.3333129882812 -26.66666984558105 C 356.8060913085938 -26.66666984558105 358 -25.47275924682617 358 -24 L 358 -18 L 358 -18 C 358 -16.52724075317383 356.8060913085938 -15.33333015441895 355.3333129882812 -15.33333015441895 L 338.6666870117188 -15.33333015441895 L 338.6666870117188 -15.33333015441895 C 337.1939086914062 -15.33333015441895 336 -16.52724075317383 336 -18 L 336 -24 L 336 -24 C 336 -25.47275924682617 337.1939086914062 -26.66666984558105 338.6666870117188 -26.66666984558105 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tszyk4 =
    '<svg viewBox="354.0 16.0 11.3 14.0" ><path transform="translate(0.0, 44.0)" d="M 354 -28 L 365.3280029296875 -28 L 365.3280029296875 -14 L 354 -14 L 354 -28 Z" fill="#000000" fill-opacity="0.4" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_w6qqk0 =
    '<svg viewBox="359.0 21.0 1.3 4.0" ><path transform="translate(0.0, 44.0)" d="M 359 -23 L 359 -19 C 359.8046875 -19.33877944946289 360.3280029296875 -20.12686920166016 360.3280029296875 -21 C 360.3280029296875 -21.87313079833984 359.8046875 -22.66122055053711 359 -23" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_hy2fm =
    '<svg viewBox="333.0 14.3 28.0 17.3" ><path transform="translate(0.0, 44.0)" d="M 333 -29.66666984558105 L 361 -29.66666984558105 L 361 -12.33333015441895 L 333 -12.33333015441895 L 333 -29.66666984558105 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_avi4k =
    '<svg viewBox="338.0 19.3 18.0 7.3" ><path transform="translate(0.0, 44.0)" d="M 339.3333129882812 -24.66666984558105 L 354.6666870117188 -24.66666984558105 L 354.6666870117188 -24.66666984558105 C 355.4030151367188 -24.66666984558105 356 -24.06970977783203 356 -23.33333015441895 L 356 -18.66666984558105 L 356 -18.66666984558105 C 356 -17.93029022216797 355.4030151367188 -17.33333015441895 354.6666870117188 -17.33333015441895 L 339.3333129882812 -17.33333015441895 L 339.3333129882812 -17.33333015441895 C 338.5969848632812 -17.33333015441895 338 -17.93029022216797 338 -18.66666984558105 L 338 -23.33333015441895 L 338 -23.33333015441895 C 338 -24.06970977783203 338.5969848632812 -24.66666984558105 339.3333129882812 -24.66666984558105 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tav08 =
    '<svg viewBox="310.7 12.3 25.3 21.0" ><path transform="translate(0.0, 44.0)" d="M 310.6936950683594 -31.66933059692383 L 335.9660949707031 -31.66933059692383 L 335.9660949707031 -10.70376014709473 L 310.6936950683594 -10.70376014709473 L 310.6936950683594 -31.66933059692383 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_iki5el =
    '<svg viewBox="315.7 17.3 15.3 11.0" ><path transform="translate(0.0, 44.0)" d="M 323.3302917480469 -24.39200019836426 C 325.5462036132812 -24.39189910888672 327.6773986816406 -23.54047012329102 329.2832946777344 -22.01366996765137 C 329.404296875 -21.89579010009766 329.5975952148438 -21.89727973937988 329.7167053222656 -22.01700019836426 L 330.8727111816406 -23.18367004394531 C 330.9330139160156 -23.2443904876709 330.9666137695312 -23.32663917541504 330.9660949707031 -23.4122200012207 C 330.9656066894531 -23.49780082702637 330.9309997558594 -23.57965087890625 330.8699951171875 -23.63966941833496 C 326.6549072265625 -27.6792106628418 320.0050964355469 -27.6792106628418 315.7900085449219 -23.63966941833496 C 315.7289123535156 -23.5797004699707 315.6943054199219 -23.49786949157715 315.6936950683594 -23.41229057312012 C 315.6932067871094 -23.32670974731445 315.7267150878906 -23.24443054199219 315.7869873046875 -23.18367004394531 L 316.9432983398438 -22.01700019836426 C 317.0624084472656 -21.8971004486084 317.2557983398438 -21.89561080932617 317.376708984375 -22.01366996765137 C 318.9827880859375 -23.54056930541992 321.1141967773438 -24.39200973510742 323.3302917480469 -24.39200019836426 L 323.3302917480469 -24.39200019836426 Z M 323.3302917480469 -20.5963306427002 C 324.5477905273438 -20.59641075134277 325.7218933105469 -20.14388084411621 326.6242980957031 -19.32666969299316 C 326.7463989257812 -19.21068954467773 326.9386901855469 -19.21319961547852 327.0577087402344 -19.33233070373535 L 328.2123107910156 -20.49900054931641 C 328.2731018066406 -20.56019020080566 328.306884765625 -20.64320945739746 328.3059997558594 -20.7294807434082 C 328.3051147460938 -20.81574058532715 328.2697143554688 -20.89805030822754 328.2077026367188 -20.95800018310547 C 325.4595031738281 -23.51437950134277 321.2034912109375 -23.51437950134277 318.4552917480469 -20.95800018310547 C 318.393310546875 -20.89805030822754 318.3577880859375 -20.81570053100586 318.3569946289062 -20.72941017150879 C 318.356201171875 -20.64311981201172 318.3901062011719 -20.56011009216309 318.4509887695312 -20.49900054931641 L 319.6052856445312 -19.33233070373535 C 319.7243041992188 -19.21319961547852 319.9165954589844 -19.21068954467773 320.0386962890625 -19.32666969299316 C 320.9404907226562 -20.14333915710449 322.1135864257812 -20.5958309173584 323.3302917480469 -20.5963306427002 L 323.3302917480469 -20.5963306427002 Z M 325.5492858886719 -17.8120002746582 C 325.6111145019531 -17.87261009216309 325.6451110839844 -17.95601081848145 325.643310546875 -18.04250907897949 C 325.6416015625 -18.12902069091797 325.6041870117188 -18.21096992492676 325.5400085449219 -18.26899909973145 C 324.264404296875 -19.34787940979004 322.3962097167969 -19.34787940979004 321.1206970214844 -18.26899909973145 C 321.056396484375 -18.21100997924805 321.0190124511719 -18.12908935546875 321.0172119140625 -18.04258918762207 C 321.0152893066406 -17.95607948303223 321.0492858886719 -17.87265014648438 321.1109924316406 -17.8120002746582 L 323.1087036132812 -15.79633045196533 C 323.1672058105469 -15.73709011077881 323.2470092773438 -15.70376014709473 323.3302917480469 -15.70376014709473 C 323.4136047363281 -15.70376014709473 323.493408203125 -15.73709011077881 323.552001953125 -15.79633045196533 L 325.5492858886719 -17.8120002746582 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_nqpuq1 =
    '<svg viewBox="288.7 12.7 27.0 20.7" ><path transform="translate(0.0, 44.0)" d="M 288.6666870117188 -31.33333015441895 L 315.6666870117188 -31.33333015441895 L 315.6666870117188 -10.66666984558105 L 288.6666870117188 -10.66666984558105 L 288.6666870117188 -31.33333015441895 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_n4r2 =
    '<svg viewBox="293.7 17.7 17.0 10.7" ><path transform="translate(0.0, 44.0)" d="M 294.6666870117188 -19.66666984558105 L 295.6666870117188 -19.66666984558105 C 296.218994140625 -19.66666984558105 296.6666870117188 -19.21895027160645 296.6666870117188 -18.66666984558105 L 296.6666870117188 -16.66666984558105 C 296.6666870117188 -16.1143798828125 296.218994140625 -15.66666984558105 295.6666870117188 -15.66666984558105 L 294.6666870117188 -15.66666984558105 C 294.1144104003906 -15.66666984558105 293.6666870117188 -16.1143798828125 293.6666870117188 -16.66666984558105 L 293.6666870117188 -18.66666984558105 C 293.6666870117188 -19.21895027160645 294.1144104003906 -19.66666984558105 294.6666870117188 -19.66666984558105 L 294.6666870117188 -19.66666984558105 Z M 299.3333129882812 -21.66666984558105 L 300.3333129882812 -21.66666984558105 C 300.8855895996094 -21.66666984558105 301.3333129882812 -21.21895027160645 301.3333129882812 -20.66666984558105 L 301.3333129882812 -16.66666984558105 C 301.3333129882812 -16.1143798828125 300.8855895996094 -15.66666984558105 300.3333129882812 -15.66666984558105 L 299.3333129882812 -15.66666984558105 C 298.781005859375 -15.66666984558105 298.3333129882812 -16.1143798828125 298.3333129882812 -16.66666984558105 L 298.3333129882812 -20.66666984558105 C 298.3333129882812 -21.21895027160645 298.781005859375 -21.66666984558105 299.3333129882812 -21.66666984558105 Z M 304 -24 L 305 -24 C 305.5523071289062 -24 306 -23.55228042602539 306 -23 L 306 -16.66666984558105 C 306 -16.1143798828125 305.5523071289062 -15.66666984558105 305 -15.66666984558105 L 304 -15.66666984558105 C 303.4476928710938 -15.66666984558105 303 -16.1143798828125 303 -16.66666984558105 L 303 -23 C 303 -23.55228042602539 303.4476928710938 -24 304 -24 Z M 308.6666870117188 -26.33333015441895 L 309.6666870117188 -26.33333015441895 C 310.218994140625 -26.33333015441895 310.6666870117188 -25.8856201171875 310.6666870117188 -25.33333015441895 L 310.6666870117188 -16.66666984558105 C 310.6666870117188 -16.1143798828125 310.218994140625 -15.66666984558105 309.6666870117188 -15.66666984558105 L 308.6666870117188 -15.66666984558105 C 308.1144104003906 -15.66666984558105 307.6666870117188 -16.1143798828125 307.6666870117188 -16.66666984558105 L 307.6666870117188 -25.33333015441895 C 307.6666870117188 -25.8856201171875 308.1144104003906 -26.33333015441895 308.6666870117188 -26.33333015441895 L 308.6666870117188 -26.33333015441895 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_u6yej =
    '<svg viewBox="29.0 15.0 54.0 16.0" ><path transform="translate(8.0, 50.0)" d="M 21 -19 L 75 -19 L 75 -35 L 21 -35 L 21 -19 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_snrsq =
    '<svg viewBox="41.8 19.9 27.5 10.3" ><path transform="translate(29.0, 17.0)" d="M 16.43259620666504 13.2392578125 C 18.94138526916504 13.2392578125 20.43161964416504 11.27734375 20.43161964416504 7.955078125 C 20.43161964416504 6.7041015625 20.19236183166504 5.6513671875 19.73435401916504 4.837890625 C 19.07126808166504 3.5732421875 17.92966651916504 2.8896484375 16.48728370666504 2.8896484375 C 14.34079933166504 2.8896484375 12.82322120666504 4.33203125 12.82322120666504 6.35546875 C 12.82322120666504 8.255859375 14.19040870666504 9.63671875 16.07029151916504 9.63671875 C 17.22556495666504 9.63671875 18.16208839416504 9.0966796875 18.62693214416504 8.16015625 L 18.64743995666504 8.16015625 C 18.64743995666504 8.16015625 18.67478370666504 8.16015625 18.68161964416504 8.16015625 C 18.69529151916504 8.16015625 18.74314308166504 8.16015625 18.74314308166504 8.16015625 C 18.74314308166504 10.416015625 17.88865089416504 11.7626953125 16.44626808166504 11.7626953125 C 15.59861183166504 11.7626953125 14.94236183166504 11.2978515625 14.71677589416504 10.552734375 L 12.95993995666504 10.552734375 C 13.25388526916504 12.1728515625 14.62790870666504 13.2392578125 16.43259620666504 13.2392578125 Z M 16.49411964416504 8.2353515625 C 15.35935401916504 8.2353515625 14.55271339416504 7.4287109375 14.55271339416504 6.30078125 C 14.55271339416504 5.2001953125 15.40036964416504 4.359375 16.50095558166504 4.359375 C 17.60154151916504 4.359375 18.44919776916504 5.2138671875 18.44919776916504 6.328125 C 18.44919776916504 7.4287109375 17.62204933166504 8.2353515625 16.49411964416504 8.2353515625 Z M 23.53221893310547 11.9541015625 C 24.18163299560547 11.9541015625 24.62596893310547 11.4892578125 24.62596893310547 10.8740234375 C 24.62596893310547 10.251953125 24.18163299560547 9.7939453125 23.53221893310547 9.7939453125 C 22.88964080810547 9.7939453125 22.43846893310547 10.251953125 22.43846893310547 10.8740234375 C 22.43846893310547 11.4892578125 22.88964080810547 11.9541015625 23.53221893310547 11.9541015625 Z M 23.53221893310547 6.8271484375 C 24.18163299560547 6.8271484375 24.62596893310547 6.369140625 24.62596893310547 5.75390625 C 24.62596893310547 5.1318359375 24.18163299560547 4.673828125 23.53221893310547 4.673828125 C 22.88964080810547 4.673828125 22.43846893310547 5.1318359375 22.43846893310547 5.75390625 C 22.43846893310547 6.369140625 22.88964080810547 6.8271484375 23.53221893310547 6.8271484375 Z M 31.44532012939453 13 L 33.13379669189453 13 L 33.13379669189453 11.1611328125 L 34.46680450439453 11.1611328125 L 34.46680450439453 9.6708984375 L 33.13379669189453 9.6708984375 L 33.13379669189453 3.1357421875 L 30.64551544189453 3.1357421875 C 28.90235137939453 5.7607421875 27.51465606689453 7.955078125 26.62598419189453 9.5888671875 L 26.62598419189453 11.1611328125 L 31.44532012939453 11.1611328125 L 31.44532012939453 13 Z M 28.25977325439453 9.609375 C 29.40821075439453 7.5859375 30.43360137939453 5.9658203125 31.37696075439453 4.5712890625 L 31.47266387939453 4.5712890625 C 31.47266387939453 4.5712890625 31.47266387939453 6.256190299987793 31.47266387939453 7.541346549987793 C 31.47266387939453 8.826502799987793 31.47266387939453 9.7119140625 31.47266387939453 9.7119140625 L 28.25977325439453 9.7119140625 L 28.25977325439453 9.609375 Z M 38.51076507568359 13 L 40.27443695068359 13 L 40.27443695068359 3.1357421875 L 38.51760101318359 3.1357421875 L 35.94045257568359 4.9404296875 L 35.94045257568359 6.6357421875 L 38.39455413818359 4.9130859375 L 38.51076507568359 4.9130859375 L 38.51076507568359 13 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_mhz2ca =
    '<svg viewBox="0.0 70.0 375.0 44.0" ><path transform="translate(0.0, 114.0)" d="M 0 -44 L 375 -44 L 375 0 L 0 0 L 0 -44 Z" fill="#ffffff" fill-opacity="0.0" stroke="none" stroke-width="1" stroke-opacity="0.0" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_jzx0na =
    '<svg viewBox="0.0 0.0 375.0 119.0" ><path  d="M 0 0 L 375 0 L 375 119 L 0 119 L 0 0 Z" fill="#ecf9fe" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_pyv499 =
    '<svg viewBox="0.0 40.6 81.1 10.0" ><path transform="translate(0.0, -252.8)" d="M 75.88474273681641 295.4244079589844 L 81.07770538330078 295.4244079589844 L 81.07770538330078 293.5283203125 L 73.76620483398438 293.5283203125 L 73.76620483398438 295.4244079589844 L 75.88474273681641 295.4244079589844 Z M 81.14710998535156 303.2200622558594 L 81.14710998535156 301.3232727050781 L 75.88474273681641 301.3232727050781 L 75.88474273681641 299.2883911132812 L 80.45461273193359 299.2883911132812 L 80.45461273193359 297.3911743164062 L 75.88474273681641 297.3911743164062 L 73.76620483398438 297.3911743164062 L 73.76620483398438 303.2200622558594 L 81.14710998535156 303.2200622558594 Z M 70.82423400878906 293.5283203125 L 68.52595520019531 293.5283203125 L 65.99197387695312 300.3544311523438 L 63.45757293701172 293.5283203125 L 61.10372161865234 293.5283203125 L 65.02284240722656 303.2900390625 L 66.90553283691406 303.2900390625 L 70.82423400878906 293.5283203125 Z M 58.06470489501953 293.5283203125 L 55.93246841430664 293.5283203125 L 55.93246841430664 303.22021484375 L 58.06470489501953 303.22021484375 L 58.06470489501953 293.5283203125 Z M 52.75561904907227 295.494384765625 L 52.75561904907227 293.5283203125 L 44.72355270385742 293.5283203125 L 44.72355270385742 295.494384765625 L 47.67339706420898 295.494384765625 L 47.67339706420898 303.2200622558594 L 49.80577087402344 303.2200622558594 L 49.80577087402344 295.494384765625 L 52.75561904907227 295.494384765625 Z M 43.72040557861328 303.2200622558594 L 39.56654357910156 293.4583740234375 L 37.60006713867188 293.4583740234375 L 33.44564437866211 303.2200622558594 L 35.61977005004883 303.2200622558594 C 37.03945922851562 299.7372741699219 37.08674240112305 299.6053771972656 38.55593109130859 296.0198669433594 C 40.05179595947266 299.6732788085938 40.02774429321289 299.6300048828125 41.49111938476562 303.2200622558594 L 43.72040557861328 303.2200622558594 Z M 25.6710033416748 295.4244079589844 L 30.86396026611328 295.4244079589844 L 30.86396026611328 293.5283203125 L 23.55301094055176 293.5283203125 L 23.55301094055176 295.4244079589844 L 25.6710033416748 295.4244079589844 Z M 30.93280792236328 303.2200622558594 L 30.93280792236328 301.3232727050781 L 25.6710033416748 301.3232727050781 L 25.6710033416748 299.2883911132812 L 30.24031257629395 299.2883911132812 L 30.24031257629395 297.3911743164062 L 25.6710033416748 297.3911743164062 L 23.55301094055176 297.3911743164062 L 23.55301094055176 303.2200622558594 L 30.93280792236328 303.2200622558594 Z M 18.02133750915527 296.8646850585938 C 18.02133750915527 297.6817626953125 17.42575645446777 298.2360229492188 16.38722038269043 298.2360229492188 L 14.22733688354492 298.2360229492188 L 14.22733688354492 295.452880859375 L 16.34574508666992 295.452880859375 C 17.38442039489746 295.452880859375 18.02133750915527 295.9234924316406 18.02133750915527 296.8369140625 L 18.02133750915527 296.8646850585938 Z M 20.47265434265137 303.2200622558594 L 18.10456466674805 299.7588500976562 C 19.33651351928711 299.3021850585938 20.18122100830078 298.3185424804688 20.18122100830078 296.75439453125 L 20.18122100830078 296.7268676757812 C 20.18122100830078 294.7323608398438 18.81088447570801 293.5283203125 16.52547073364258 293.5283203125 L 12.09441089630127 293.5283203125 L 12.09441089630127 303.2200622558594 L 14.22733688354492 303.2200622558594 L 14.22733688354492 300.1192626953125 L 15.90279102325439 300.1192626953125 L 17.97958755493164 303.2200622558594 L 20.47265434265137 303.2200622558594 Z M 8.945208549499512 301.6559143066406 L 7.588143348693848 300.2855834960938 C 6.826661109924316 300.9776611328125 6.147990226745605 301.4205932617188 5.040467262268066 301.4205932617188 C 3.378698587417603 301.4205932617188 2.229285717010498 300.0364379882812 2.229285717010498 298.3748168945312 L 2.229285717010498 298.34619140625 C 2.229285717010498 296.6844482421875 3.406210422515869 295.3277587890625 5.040467262268066 295.3277587890625 C 6.009601593017578 295.3277587890625 6.771083831787109 295.7432250976562 7.519294261932373 296.421630859375 L 8.875805854797363 294.8572998046875 C 7.976073265075684 293.9702758789062 6.881822109222412 293.3619995117188 5.054153442382812 293.3619995117188 C 2.077210426330566 293.3619995117188 0 295.6182250976562 0 298.3748168945312 L 0 298.40234375 C 0 301.1854248046875 2.118547439575195 303.3875122070312 4.971065521240234 303.3875122070312 C 6.839932441711426 303.3875122070312 7.948423385620117 302.7221069335938 8.945208549499512 301.6559143066406" fill="#00070f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_vlvtax =
    '<svg viewBox="12.1 53.7 57.0 3.6" ><path transform="translate(-75.39, -334.5)" d="M 144.4387664794922 391.6971435546875 L 144.4387664794922 388.2200317382812 L 143.6830749511719 388.2200317382812 L 143.6830749511719 390.3612670898438 L 142.053955078125 388.2200317382812 L 141.3486022949219 388.2200317382812 L 141.3486022949219 391.6971435546875 L 142.1037292480469 391.6971435546875 L 142.1037292480469 389.4861450195312 L 143.7874603271484 391.6971435546875 L 144.4387664794922 391.6971435546875 Z M 137.4654235839844 390.2422180175781 L 136.5409545898438 390.2422180175781 L 137.0032653808594 389.1139526367188 L 137.4654235839844 390.2422180175781 Z M 138.85595703125 391.6971435546875 L 137.3660278320312 388.1944580078125 L 136.6606750488281 388.1944580078125 L 135.1701965332031 391.6971435546875 L 135.9497985839844 391.6971435546875 L 136.2679138183594 390.9175720214844 L 137.7386169433594 390.9175720214844 L 138.0565795898438 391.6971435546875 L 138.85595703125 391.6971435546875 Z M 132.7774963378906 391.2049865722656 L 132.7774963378906 389.6947631835938 L 131.266845703125 389.6947631835938 L 131.266845703125 390.3562622070312 L 132.0371704101562 390.3562622070312 L 132.0371704101562 390.8524780273438 C 131.8432006835938 390.9923706054688 131.5951843261719 391.0612182617188 131.3164672851562 391.0612182617188 C 130.7006988525391 391.0612182617188 130.2637023925781 390.5946044921875 130.2637023925781 389.9586791992188 L 130.2637023925781 389.9488525390625 C 130.2637023925781 389.3571472167969 130.7056884765625 388.8659362792969 131.2624206542969 388.8659362792969 C 131.6645812988281 388.8659362792969 131.9027862548828 388.9949340820312 132.1709899902344 389.2183227539062 L 132.6533508300781 388.6365661621094 C 132.2901611328125 388.3294067382812 131.91259765625 388.1600341796875 131.2870178222656 388.1600341796875 C 130.2335510253906 388.1600341796875 129.4637756347656 388.9703063964844 129.4637756347656 389.9586791992188 L 129.4637756347656 389.9683532714844 C 129.4637756347656 390.9971923828125 130.2089385986328 391.7572937011719 131.2919921875 391.7572937011719 C 131.9278106689453 391.7572937011719 132.4195556640625 391.5081787109375 132.7774963378906 391.2049865722656 M 126.1817169189453 389.9683532714844 C 126.1817169189453 390.5650329589844 125.7543792724609 391.0513916015625 125.1386108398438 391.0513916015625 C 124.5224304199219 391.0513916015625 124.0852813720703 390.5542602539062 124.0852813720703 389.9586791992188 L 124.0852813720703 389.9488525390625 C 124.0852813720703 389.3521728515625 124.5124740600586 388.8659362792969 125.1282424926758 388.8659362792969 C 125.7441558837891 388.8659362792969 126.1817169189453 389.3630981445312 126.1817169189453 389.9586791992188 L 126.1817169189453 389.9683532714844 Z M 126.9814910888672 389.9586791992188 L 126.9814910888672 389.9488525390625 C 126.9814910888672 388.9603576660156 126.2115783691406 388.1600341796875 125.1386108398438 388.1600341796875 C 124.0650939941406 388.1600341796875 123.285514831543 388.9703063964844 123.285514831543 389.9586791992188 L 123.285514831543 389.9683532714844 C 123.285514831543 390.9568481445312 124.0556945800781 391.7572937011719 125.1282424926758 391.7572937011719 C 126.2013473510742 391.7572937011719 126.9814910888672 390.947021484375 126.9814910888672 389.9586791992188 M 121.1058502197266 391.6971435546875 L 121.1058502197266 391.002197265625 L 119.3721923828125 391.002197265625 L 119.3721923828125 388.2200317382812 L 118.6073913574219 388.2200317382812 L 118.6073913574219 391.6971435546875 L 121.1058502197266 391.6971435546875 Z M 115.9857559204102 390.66943359375 L 115.9857559204102 390.6586303710938 C 115.9857559204102 390.05322265625 115.5885620117188 389.8002319335938 114.8832092285156 389.6160888671875 C 114.282096862793 389.4615173339844 114.132926940918 389.3875427246094 114.132926940918 389.1583251953125 L 114.132926940918 389.1483764648438 C 114.132926940918 388.9801330566406 114.2870788574219 388.84619140625 114.5798873901367 388.84619140625 C 114.8732528686523 388.84619140625 115.1760177612305 388.9751586914062 115.4841842651367 389.1889038085938 L 115.8813781738281 388.6119689941406 C 115.5289764404297 388.3294067382812 115.0962524414062 388.1699829101562 114.5896987915039 388.1699829101562 C 113.879508972168 388.1699829101562 113.3729629516602 388.5872192382812 113.3729629516602 389.2183227539062 L 113.3729629516602 389.2281494140625 C 113.3729629516602 389.9192504882812 113.8249053955078 390.1122436523438 114.525276184082 390.2913208007812 C 115.1066284179688 390.4400634765625 115.226203918457 390.5394592285156 115.226203918457 390.7333984375 L 115.226203918457 390.7432250976562 C 115.226203918457 390.947021484375 115.0372161865234 391.071044921875 114.7242202758789 391.071044921875 C 114.3268814086914 391.071044921875 113.9986801147461 390.9075927734375 113.685546875 390.648681640625 L 113.2336044311523 391.190185546875 C 113.6511154174805 391.5633544921875 114.1826934814453 391.7463684082031 114.7088775634766 391.7463684082031 C 115.4590148925781 391.7463684082031 115.9857559204102 391.3595581054688 115.9857559204102 390.66943359375 M 107.0705490112305 389.4171447753906 C 107.0705490112305 389.7095336914062 106.8569488525391 389.9084777832031 106.4843597412109 389.9084777832031 L 105.7090606689453 389.9084777832031 L 105.7090606689453 388.91015625 L 106.4695739746094 388.91015625 C 106.842155456543 388.91015625 107.0705490112305 389.0795288085938 107.0705490112305 389.4073486328125 L 107.0705490112305 389.4171447753906 Z M 107.9496841430664 391.6971435546875 L 107.1005477905273 390.454833984375 C 107.5425338745117 390.2913208007812 107.8452987670898 389.9390258789062 107.8452987670898 389.3778686523438 L 107.8452987670898 389.366943359375 C 107.8452987670898 388.65234375 107.3535461425781 388.2200317382812 106.5339965820312 388.2200317382812 L 104.9441223144531 388.2200317382812 L 104.9441223144531 391.6971435546875 L 105.7090606689453 391.6971435546875 L 105.7090606689453 390.5847778320312 L 106.3105926513672 390.5847778320312 L 107.0557556152344 391.6971435546875 L 107.9496841430664 391.6971435546875 Z M 102.2088394165039 390.1820678710938 L 102.2088394165039 388.2200317382812 L 101.4434814453125 388.2200317382812 L 101.4434814453125 390.211669921875 C 101.4434814453125 390.7630004882812 101.1609039306641 391.0464172363281 100.6931991577148 391.0464172363281 C 100.2266082763672 391.0464172363281 99.94319152832031 390.7530517578125 99.94319152832031 390.1870727539062 L 99.94319152832031 388.2200317382812 L 99.17825317382812 388.2200317382812 L 99.17825317382812 390.2066955566406 C 99.17825317382812 391.2304077148438 99.74964141845703 391.7523193359375 100.6839370727539 391.7523193359375 C 101.61767578125 391.7523193359375 102.2088394165039 391.2355346679688 102.2088394165039 390.1820678710938 M 95.79664611816406 389.9683532714844 C 95.79664611816406 390.5650329589844 95.36946105957031 391.0513916015625 94.75369262695312 391.0513916015625 C 94.13778686523438 391.0513916015625 93.70022583007812 390.5542602539062 93.70022583007812 389.9586791992188 L 93.70022583007812 389.9488525390625 C 93.70022583007812 389.3521728515625 94.1275634765625 388.8659362792969 94.74373626708984 388.8659362792969 C 95.35950469970703 388.8659362792969 95.79664611816406 389.3630981445312 95.79664611816406 389.9586791992188 L 95.79664611816406 389.9683532714844 Z M 96.59656524658203 389.9586791992188 L 96.59656524658203 389.9488525390625 C 96.59656524658203 388.9603576660156 95.82665252685547 388.1600341796875 94.75369262695312 388.1600341796875 C 93.68059539794922 388.1600341796875 92.90045166015625 388.9703063964844 92.90045166015625 389.9586791992188 L 92.90045166015625 389.9683532714844 C 92.90045166015625 390.9568481445312 93.67063903808594 391.7572937011719 94.74373626708984 391.7572937011719 C 95.81683349609375 391.7572937011719 96.59656524658203 390.947021484375 96.59656524658203 389.9586791992188 M 90.92015075683594 388.2200317382812 L 90.0504150390625 388.2200317382812 L 89.20626068115234 389.6160888671875 L 88.37648010253906 388.2200317382812 L 87.48200225830078 388.2200317382812 L 88.81832885742188 390.3257141113281 L 88.81832885742188 391.6971435546875 L 89.58382415771484 391.6971435546875 L 89.58382415771484 390.3110656738281 L 90.92015075683594 388.2200317382812 Z" fill="#00070f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_iv1 =
    '<svg viewBox="14.5 0.0 52.1 30.6" ><path transform="translate(-90.51, 0.0)" d="M 128.1074523925781 0 L 142.9529113769531 19.14102745056152 C 143.0213623046875 19.24499130249023 143.09765625 19.34328651428223 143.1808776855469 19.43536186218262 C 143.6115417480469 19.90845680236816 144.2321472167969 20.2047233581543 144.9217376708984 20.2047233581543 C 146.8089904785156 20.2047233581543 147.8972930908203 18.10940361022949 146.8966369628906 16.56971168518066 C 146.8252868652344 16.45993995666504 146.7449798583984 16.35652923583984 146.6563720703125 16.26058197021484 L 139.7579345703125 7.365560531616211 L 151.1445159912109 7.365560531616211 C 154.4538269042969 7.365560531616211 157.1364135742188 10.04830646514893 157.1364135742188 13.35788059234619 C 157.1364135742188 14.60227203369141 156.7573394775391 15.75749015808105 156.1081237792969 16.71542549133301 L 146.7095947265625 28.83444595336914 C 145.779296875 29.90547180175781 144.4074401855469 30.58178901672363 142.8775634765625 30.58178901672363 C 141.3398132324219 30.58178901672363 139.9625549316406 29.89772987365723 139.0324096679688 28.81771850585938 L 134.1953125 22.58124732971191 L 129.3457641601562 28.83444595336914 C 128.4156188964844 29.90547180175781 127.0437698364258 30.58178901672363 125.5138778686523 30.58178901672363 C 123.9766845703125 30.58178901672363 122.5990219116211 29.89772987365723 121.668586730957 28.81771850585938 L 105.0309982299805 7.365560531616211 L 110.7437744140625 0 L 116.456413269043 7.365560531616211 L 125.589225769043 19.14102745056152 C 125.6576690673828 19.24499130249023 125.7338333129883 19.34328651428223 125.8176193237305 19.43536186218262 C 126.2478561401367 19.90845680236816 126.8684616088867 20.2047233581543 127.5586090087891 20.2047233581543 C 129.4447479248047 20.2047233581543 130.5335998535156 18.10940361022949 129.532958984375 16.56971168518066 C 129.4614868164062 16.45993995666504 129.3812866210938 16.35652923583984 129.2926940917969 16.26058197021484 L 122.3946838378906 7.365560531616211 L 128.1074523925781 0 Z" fill="#004c98" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
