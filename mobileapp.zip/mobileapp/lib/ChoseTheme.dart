import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';

class ChoseTheme extends StatelessWidget {
  const ChoseTheme({
    Key key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(size: 114.0, end: 35.0),
            Pin(size: 103.0, middle: 0.1876),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xffe7e7e7),
                borderRadius: BorderRadius.circular(8.0),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 98.0, end: 43.0),
            Pin(size: 67.0, middle: 0.2081),
            child: const Text(
              'Light\nColor \nDark',
              style: TextStyle(
                fontFamily: 'Montserrat-Regular',
                fontSize: 9,
                color: Color(0xff2f302f),
                height: 3.111111111111111,
              ),
              textHeightBehavior:
                  TextHeightBehavior(applyHeightToFirstAscent: false),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 64.0, middle: 0.8071),
            Pin(size: 11.0, start: 136.0),
            child: const Text(
              'Chose Theme ',
              style: TextStyle(
                fontFamily: 'Montserrat-Regular',
                fontSize: 9,
                color: Color(0xff2f302f),
                height: 3.111111111111111,
              ),
              textHeightBehavior:
                  TextHeightBehavior(applyHeightToFirstAscent: false),
              softWrap: false,
            ),
          ),
          Container(),
          Container(),
          Container(),
        ],
      ),
    );
  }
}
