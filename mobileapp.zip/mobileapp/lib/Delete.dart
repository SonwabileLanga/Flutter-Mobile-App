import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';

class Delete extends StatelessWidget {
  const Delete({
    Key key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 30.0, end: 30.0),
            Pin(size: 128.0, middle: 0.5),
            child: Stack(
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xed2f302f),
                    borderRadius: BorderRadius.circular(27.0),
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 26.0, end: 26.0),
                  Pin(size: 21.0, start: 18.0),
                  child: const Text(
                    'Are you sure you want to Delete Item',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 16,
                      color: Color(0xffffffff),
                      fontWeight: FontWeight.w500,
                      height: 3.375,
                    ),
                    textHeightBehavior:
                        TextHeightBehavior(applyHeightToFirstAscent: false),
                    softWrap: false,
                  ),
                ),
                const Align(
                  alignment: Alignment(0.008, -0.154),
                  child: SizedBox(
                    width: 186.0,
                    height: 24.0,
                    child: Text(
                      'Please Note deleted items are compelety \nremoved from database',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xffffd700),
                        fontWeight: FontWeight.w500,
                        height: 1.1,
                      ),
                      textHeightBehavior:
                          TextHeightBehavior(applyHeightToFirstAscent: false),
                      textAlign: TextAlign.center,
                      softWrap: false,
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 42.0, end: 42.0),
                  Pin(size: 26.0, end: 17.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(size: 36.0, start: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child: const Text(
                          'YES',
                          style: TextStyle(
                            fontFamily: 'Roboto',
                            fontSize: 20,
                            color: Color(0xffffffff),
                            fontWeight: FontWeight.w500,
                            height: 2.7,
                          ),
                          textHeightBehavior: TextHeightBehavior(
                              applyHeightToFirstAscent: false),
                          softWrap: false,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 28.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child: const Text(
                          'NO',
                          style: TextStyle(
                            fontFamily: 'Roboto',
                            fontSize: 20,
                            color: Color(0xffffffff),
                            fontWeight: FontWeight.w500,
                            height: 2.7,
                          ),
                          textHeightBehavior: TextHeightBehavior(
                              applyHeightToFirstAscent: false),
                          softWrap: false,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
