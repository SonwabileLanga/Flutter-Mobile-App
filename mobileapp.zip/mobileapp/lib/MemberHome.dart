import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import './SAMeteringSolutions.dart';
import 'package:adobe_xd/page_link.dart';
import './InvestSolar.dart';
import './iPhoneXXS11Pro1.dart';
import './Ebook.dart';
import './ProductReview.dart';
import 'package:flutter_svg/flutter_svg.dart';
import './wishlist.dart';
import './Search.dart';
import './Profile.dart';
import './Louis57.dart';
import './Krelumlighting.dart';
import './ExclusiveMembership.dart';
import './Shopping.dart';
import './Selling.dart';
import './ValueAddedServices.dart';

class MemberHome extends StatelessWidget {
  const MemberHome({
    Key key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 130.0, end: 96.0),
            child: Stack(
              children: <Widget>[
                Stack(
                  children: <Widget>[
                    Pinned.fromPins(
                      Pin(size: 187.5, start: 0.0),
                      Pin(start: 0.0, end: 0.0),
                      child: Container(
                        color: const Color(0xffe7f6fe),
                      ),
                    ),
                    Pinned.fromPins(
                      Pin(size: 187.5, end: 0.0),
                      Pin(start: 0.0, end: 0.0),
                      child: Container(
                        color: const Color(0xffe7f6fe),
                      ),
                    ),
                    Stack(
                      children: <Widget>[
                        Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(size: 8.3, end: 60.2),
                              Pin(size: 10.4, start: 13.2),
                              child: SvgPicture.string(
                                _svg_az3zv8,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 8.9, end: 40.2),
                              Pin(size: 10.4, start: 13.2),
                              child: SvgPicture.string(
                                _svg_pp66fb,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 8.6, end: 31.3),
                              Pin(size: 10.4, start: 13.2),
                              child: SvgPicture.string(
                                _svg_id6nld,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 8.8, end: 9.9),
                              Pin(size: 10.4, start: 13.2),
                              child: SvgPicture.string(
                                _svg_z3w4sa,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 10.4, end: 20.4),
                              Pin(size: 10.4, start: 13.2),
                              child: SvgPicture.string(
                                _svg_z3vh7p,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 10.4, end: 48.9),
                              Pin(size: 10.4, start: 13.2),
                              child: SvgPicture.string(
                                _svg_c29owo,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 58.6, end: 9.9),
                              Pin(size: 17.0, middle: 0.2234),
                              child: SvgPicture.string(
                                _svg_vfabnz,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.1, end: 11.7),
                              Pin(size: 1.3, start: 10.9),
                              child: SvgPicture.string(
                                _svg_bm84g,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.3, end: 10.2),
                              Pin(size: 1.3, start: 10.9),
                              child: SvgPicture.string(
                                _svg_p7f1fk,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.9, end: 65.6),
                              Pin(size: 4.5, middle: 0.353),
                              child: SvgPicture.string(
                                _svg_u3y459,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.0, end: 64.1),
                              Pin(size: 2.1, middle: 0.3637),
                              child: SvgPicture.string(
                                _svg_a1ht58,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.1, end: 61.6),
                              Pin(size: 3.5, middle: 0.3571),
                              child: SvgPicture.string(
                                _svg_d591t,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.0, end: 59.3),
                              Pin(size: 1.5, middle: 0.3427),
                              child: SvgPicture.string(
                                _svg_ky4qhp,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.1, end: 58.3),
                              Pin(size: 2.5, middle: 0.3632),
                              child: SvgPicture.string(
                                _svg_j7ood5,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.1, end: 54.0),
                              Pin(size: 3.5, middle: 0.3571),
                              child: SvgPicture.string(
                                _svg_d71ha,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.7, end: 52.7),
                              Pin(size: 2.4, middle: 0.3636),
                              child: SvgPicture.string(
                                _svg_rrykk,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.8, end: 49.6),
                              Pin(size: 4.4, middle: 0.3521),
                              child: SvgPicture.string(
                                _svg_oyk0xb,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 3.1, end: 47.6),
                              Pin(size: 4.5, middle: 0.3526),
                              child: SvgPicture.string(
                                _svg_gzu01y,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.7, end: 44.2),
                              Pin(size: 2.4, middle: 0.3636),
                              child: SvgPicture.string(
                                _svg_nau9ab,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.4, end: 41.7),
                              Pin(size: 4.3, middle: 0.3538),
                              child: SvgPicture.string(
                                _svg_sjw2mv,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.7, end: 40.1),
                              Pin(size: 2.3, middle: 0.3632),
                              child: SvgPicture.string(
                                _svg_ii76at,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.7, end: 38.3),
                              Pin(size: 2.1, middle: 0.365),
                              child: SvgPicture.string(
                                _svg_adzdd,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.1, end: 35.6),
                              Pin(size: 3.5, middle: 0.3571),
                              child: SvgPicture.string(
                                _svg_z5qhkq,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.7, end: 32.3),
                              Pin(size: 2.4, middle: 0.3636),
                              child: SvgPicture.string(
                                _svg_g2fnl8,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.9, end: 29.1),
                              Pin(size: 4.2, middle: 0.354),
                              child: SvgPicture.string(
                                _svg_p4ylhq,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.1, end: 27.8),
                              Pin(size: 2.1, middle: 0.3642),
                              child: SvgPicture.string(
                                _svg_gtxguy,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.0, end: 25.9),
                              Pin(size: 2.1, middle: 0.3637),
                              child: SvgPicture.string(
                                _svg_e4x2dz,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.5, end: 23.3),
                              Pin(size: 2.3, middle: 0.3641),
                              child: SvgPicture.string(
                                _svg_ms6xy2,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.1, end: 21.0),
                              Pin(size: 3.5, middle: 0.3571),
                              child: SvgPicture.string(
                                _svg_c97a1i,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.9, end: 19.6),
                              Pin(size: 3.5, middle: 0.3577),
                              child: SvgPicture.string(
                                _svg_q92qaj,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.1, end: 18.2),
                              Pin(size: 2.5, middle: 0.3632),
                              child: SvgPicture.string(
                                _svg_fh7s40,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.9, end: 16.5),
                              Pin(size: 3.5, middle: 0.3577),
                              child: SvgPicture.string(
                                _svg_sunjq,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.0, end: 15.3),
                              Pin(size: 2.4, middle: 0.3655),
                              child: SvgPicture.string(
                                _svg_jraled,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 3.2, end: 12.9),
                              Pin(size: 4.3, middle: 0.3687),
                              child: SvgPicture.string(
                                _svg_itxren,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.8, end: 9.9),
                              Pin(size: 4.9, middle: 0.3535),
                              child: SvgPicture.string(
                                _svg_yc7sa,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Container(
                              decoration: const BoxDecoration(),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const Align(
                      alignment: Alignment(0.452, -0.592),
                      child: SizedBox(
                        width: 106.0,
                        height: 11.0,
                        child: Text.rich(
                          TextSpan(
                            style: TextStyle(
                              fontFamily: 'Montserrat-Medium',
                              fontSize: 9,
                              color: Color(0xff2f302f),
                              height: 1.2000000211927626,
                            ),
                            children: [
                              TextSpan(
                                text: 'IN ',
                              ),
                              TextSpan(
                                text: 'P',
                                style: TextStyle(
                                  letterSpacing: -0.40499999999999997,
                                ),
                              ),
                              TextSpan(
                                text: 'ARTNERSHIP WITH',
                              ),
                            ],
                          ),
                          textHeightBehavior: TextHeightBehavior(
                              applyHeightToFirstAscent: false),
                          softWrap: false,
                        ),
                      ),
                    ),
                    Stack(
                      children: <Widget>[
                        Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(size: 1.0, middle: 0.5013),
                              Pin(start: 4.5, end: 7.5),
                              child: SvgPicture.string(
                                _svg_jexd0,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.9, start: 13.0),
                              Pin(size: 4.2, middle: 0.3624),
                              child: SvgPicture.string(
                                _svg_alfhce,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Container(
                              decoration: const BoxDecoration(),
                            ),
                          ],
                        ),
                      ],
                    ),
                    Stack(
                      children: <Widget>[
                        Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(size: 13.8, start: 10.9),
                              Pin(size: 13.8, end: 10.3),
                              child: SvgPicture.string(
                                _svg_xnrc3,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 6.5, start: 17.5),
                              Pin(size: 6.5, middle: 0.5627),
                              child: SvgPicture.string(
                                _svg_amb6d2,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 4.3, start: 17.3),
                              Pin(size: 4.3, middle: 0.5719),
                              child: SvgPicture.string(
                                _svg_nhpqyj,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 12.9, start: 10.9),
                              Pin(size: 12.9, middle: 0.5956),
                              child: SvgPicture.string(
                                _svg_yv3xg2,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 13.8, start: 10.4),
                              Pin(size: 9.9, middle: 0.7438),
                              child: SvgPicture.string(
                                _svg_ijsfex,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 10.3, start: 12.1),
                              Pin(size: 4.7, middle: 0.7303),
                              child: SvgPicture.string(
                                _svg_kkwtxs,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.6, start: 19.9),
                              Pin(size: 2.6, middle: 0.745),
                              child: SvgPicture.string(
                                _svg_ib55m5,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 2.6, start: 12.1),
                              Pin(size: 2.6, middle: 0.745),
                              child: SvgPicture.string(
                                _svg_o31au,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Container(
                              decoration: const BoxDecoration(),
                            ),
                          ],
                        ),
                      ],
                    ),
                    Pinned.fromPins(
                      Pin(size: 64.0, start: 28.9),
                      Pin(size: 11.0, middle: 0.5928),
                      child: const Text(
                        '+27 31 311 1000',
                        style: TextStyle(
                          fontFamily: 'Montserrat-Regular',
                          fontSize: 9,
                          color: Color(0xff1a1818),
                          height: 1.2000000211927626,
                        ),
                        textHeightBehavior:
                            TextHeightBehavior(applyHeightToFirstAscent: false),
                        softWrap: false,
                      ),
                    ),
                    Pinned.fromPins(
                      Pin(size: 86.0, start: 28.9),
                      Pin(size: 11.0, middle: 0.7441),
                      child: const Text.rich(
                        TextSpan(
                          style: TextStyle(
                            fontFamily: 'Montserrat-Regular',
                            fontSize: 9,
                            color: Color(0xff1a1818),
                            height: 1.2000000211927626,
                          ),
                          children: [
                            TextSpan(
                              text: 'in',
                            ),
                            TextSpan(
                              text: 'f',
                              style: TextStyle(
                                letterSpacing: -0.08099999999999999,
                              ),
                            ),
                            TextSpan(
                              text: 'o@creative.',
                            ),
                            TextSpan(
                              text: 'c',
                              style: TextStyle(
                                letterSpacing: -0.18,
                              ),
                            ),
                            TextSpan(
                              text: 'o.',
                            ),
                            TextSpan(
                              text: 'z',
                              style: TextStyle(
                                letterSpacing: -0.08099999999999999,
                              ),
                            ),
                            TextSpan(
                              text: 'a',
                            ),
                          ],
                        ),
                        textHeightBehavior:
                            TextHeightBehavior(applyHeightToFirstAscent: false),
                        softWrap: false,
                      ),
                    ),
                    Pinned.fromPins(
                      Pin(size: 84.0, start: 28.9),
                      Pin(size: 11.0, end: 12.5),
                      child: const Text.rich(
                        TextSpan(
                          style: TextStyle(
                            fontFamily: 'Montserrat-Regular',
                            fontSize: 9,
                            color: Color(0xff1a1818),
                            height: 1.2000000211927626,
                          ),
                          children: [
                            TextSpan(
                              text: 'ww',
                            ),
                            TextSpan(
                              text: 'w',
                              style: TextStyle(
                                letterSpacing: -0.18,
                              ),
                            ),
                            TextSpan(
                              text: '.creative.',
                            ),
                            TextSpan(
                              text: 'c',
                              style: TextStyle(
                                letterSpacing: -0.189,
                              ),
                            ),
                            TextSpan(
                              text: 'o.',
                            ),
                            TextSpan(
                              text: 'z',
                              style: TextStyle(
                                letterSpacing: -0.08099999999999999,
                              ),
                            ),
                            TextSpan(
                              text: 'a',
                            ),
                          ],
                        ),
                        textHeightBehavior:
                            TextHeightBehavior(applyHeightToFirstAscent: false),
                        softWrap: false,
                      ),
                    ),
                    Stack(
                      children: <Widget>[
                        Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(size: 13.8, middle: 0.5467),
                              Pin(size: 13.8, end: 10.0),
                              child: SvgPicture.string(
                                _svg_ns5j,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Align(
                              alignment: const Alignment(0.108, 0.13),
                              child: SizedBox(
                                width: 6.0,
                                height: 6.0,
                                child: SvgPicture.string(
                                  _svg_roaowd,
                                  allowDrawingOutsideViewBox: true,
                                ),
                              ),
                            ),
                            Align(
                              alignment: const Alignment(0.1, 0.149),
                              child: SizedBox(
                                width: 4.0,
                                height: 4.0,
                                child: SvgPicture.string(
                                  _svg_ifuyyc,
                                  allowDrawingOutsideViewBox: true,
                                ),
                              ),
                            ),
                            Align(
                              alignment: const Alignment(0.091, 0.196),
                              child: SizedBox(
                                width: 13.0,
                                height: 13.0,
                                child: SvgPicture.string(
                                  _svg_u8tg,
                                  allowDrawingOutsideViewBox: true,
                                ),
                              ),
                            ),
                            Align(
                              alignment: const Alignment(0.091, 0.493),
                              child: SizedBox(
                                width: 14.0,
                                height: 10.0,
                                child: SvgPicture.string(
                                  _svg_or052,
                                  allowDrawingOutsideViewBox: true,
                                ),
                              ),
                            ),
                            Align(
                              alignment: const Alignment(0.09, 0.466),
                              child: SizedBox(
                                width: 10.0,
                                height: 5.0,
                                child: SvgPicture.string(
                                  _svg_lnrs5t,
                                  allowDrawingOutsideViewBox: true,
                                ),
                              ),
                            ),
                            Align(
                              alignment: const Alignment(0.109, 0.495),
                              child: SizedBox(
                                width: 3.0,
                                height: 3.0,
                                child: SvgPicture.string(
                                  _svg_gv1kzr,
                                  allowDrawingOutsideViewBox: true,
                                ),
                              ),
                            ),
                            Align(
                              alignment: const Alignment(0.067, 0.495),
                              child: SizedBox(
                                width: 3.0,
                                height: 3.0,
                                child: SvgPicture.string(
                                  _svg_pustts,
                                  allowDrawingOutsideViewBox: true,
                                ),
                              ),
                            ),
                            Container(
                              decoration: const BoxDecoration(),
                            ),
                          ],
                        ),
                      ],
                    ),
                    Pinned.fromPins(
                      Pin(size: 105.0, end: 54.5),
                      Pin(size: 11.0, middle: 0.5954),
                      child: const Text.rich(
                        TextSpan(
                          style: TextStyle(
                            fontFamily: 'Montserrat-Regular',
                            fontSize: 9,
                            color: Color(0xff2f302f),
                            height: 1.2000000211927626,
                          ),
                          children: [
                            TextSpan(
                              text: '0861 ',
                            ),
                            TextSpan(
                              text: 'D',
                              style: TextStyle(
                                letterSpacing: -0.252,
                              ),
                            ),
                            TextSpan(
                              text: 'O',
                              style: TextStyle(
                                letterSpacing: -0.126,
                              ),
                            ),
                            TextSpan(
                              text: 'T',
                              style: TextStyle(
                                letterSpacing: -0.378,
                              ),
                            ),
                            TextSpan(
                              text: 'C',
                              style: TextStyle(
                                letterSpacing: -0.126,
                              ),
                            ),
                            TextSpan(
                              text: 'OM (368266)',
                            ),
                          ],
                        ),
                        textHeightBehavior:
                            TextHeightBehavior(applyHeightToFirstAscent: false),
                        softWrap: false,
                      ),
                    ),
                    const Align(
                      alignment: Alignment(0.507, 0.493),
                      child: SizedBox(
                        width: 89.0,
                        height: 11.0,
                        child: Text.rich(
                          TextSpan(
                            style: TextStyle(
                              fontFamily: 'Montserrat-Regular',
                              fontSize: 9,
                              color: Color(0xff2f302f),
                              height: 1.2000000211927626,
                            ),
                            children: [
                              TextSpan(
                                text: 'in',
                              ),
                              TextSpan(
                                text: 'f',
                                style: TextStyle(
                                  letterSpacing: -0.08099999999999999,
                                ),
                              ),
                              TextSpan(
                                text: 'o@do',
                              ),
                              TextSpan(
                                text: 't',
                                style: TextStyle(
                                  letterSpacing: -0.054,
                                ),
                              ),
                              TextSpan(
                                text: 'c',
                                style: TextStyle(
                                  letterSpacing: -0.18,
                                ),
                              ),
                              TextSpan(
                                text: 'om.afri',
                              ),
                              TextSpan(
                                text: 'c',
                                style: TextStyle(
                                  letterSpacing: -0.189,
                                ),
                              ),
                              TextSpan(
                                text: 'a',
                              ),
                            ],
                          ),
                          textHeightBehavior: TextHeightBehavior(
                              applyHeightToFirstAscent: false),
                          softWrap: false,
                        ),
                      ),
                    ),
                    Pinned.fromPins(
                      Pin(size: 107.0, end: 52.5),
                      Pin(size: 11.0, end: 12.1),
                      child: const Text.rich(
                        TextSpan(
                          style: TextStyle(
                            fontFamily: 'Montserrat-Regular',
                            fontSize: 9,
                            color: Color(0xff2f302f),
                            height: 1.2000000211927626,
                          ),
                          children: [
                            TextSpan(
                              text: 'ww',
                            ),
                            TextSpan(
                              text: 'w',
                              style: TextStyle(
                                letterSpacing: -0.18,
                              ),
                            ),
                            TextSpan(
                              text: '.do',
                            ),
                            TextSpan(
                              text: 't',
                              style: TextStyle(
                                letterSpacing: -0.054,
                              ),
                            ),
                            TextSpan(
                              text: 'c',
                              style: TextStyle(
                                letterSpacing: -0.18,
                              ),
                            ),
                            TextSpan(
                              text: 'omafri',
                            ),
                            TextSpan(
                              text: 'c',
                              style: TextStyle(
                                letterSpacing: -0.189,
                              ),
                            ),
                            TextSpan(
                              text: 'a.',
                            ),
                            TextSpan(
                              text: 'c',
                              style: TextStyle(
                                letterSpacing: -0.18,
                              ),
                            ),
                            TextSpan(
                              text: 'om',
                            ),
                          ],
                        ),
                        textHeightBehavior:
                            TextHeightBehavior(applyHeightToFirstAscent: false),
                        softWrap: false,
                      ),
                    ),
                  ],
                ),
                Pinned.fromPins(
                  Pin(size: 81.1, start: 10.0),
                  Pin(size: 57.3, start: 4.0),
                  child: Stack(
                    children: <Widget>[
                      Stack(
                        children: <Widget>[
                          Pinned.fromPins(
                            Pin(start: 0.0, end: 0.0),
                            Pin(size: 10.0, end: 6.7),
                            child: SvgPicture.string(
                              _svg_pyv499,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            ),
                          ),
                          Pinned.fromPins(
                            Pin(start: 12.1, end: 12.1),
                            Pin(size: 3.6, end: 0.0),
                            child: SvgPicture.string(
                              _svg_vlvtax,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            ),
                          ),
                          Pinned.fromPins(
                            Pin(start: 14.5, end: 14.5),
                            Pin(size: 30.6, start: 0.0),
                            child: SvgPicture.string(
                              _svg_iv1,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            ),
                          ),
                          Container(
                            decoration: const BoxDecoration(),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 210.5, middle: 0.2551),
            child: SingleChildScrollView(
              primary: false,
              scrollDirection: Axis.horizontal,
              child: SizedBox(
                width: 501.0,
                height: 211.0,
                child: Stack(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.fromLTRB(3.0, 0.0, -129.0, 0.0),
                      child: Stack(
                        children: <Widget>[
                          Pinned.fromPins(
                            Pin(size: 155.0, end: 0.0),
                            Pin(start: 1.0, end: 0.0),
                            child: PageLink(
                              links: [
                                PageLinkInfo(
                                  transition: LinkTransition.Fade,
                                  ease: Curves.easeOut,
                                  duration: 0.3,
                                  pageBuilder: () => const SAMeteringSolutions(),
                                ),
                              ],
                              child: Stack(
                                children: <Widget>[
                                  SizedBox.expand(
                                      child: SvgPicture.string(
                                    _svg_w3637r,
                                    allowDrawingOutsideViewBox: true,
                                    fit: BoxFit.fill,
                                  )),
                                  Pinned.fromPins(
                                    Pin(start: 5.0, end: 11.0),
                                    Pin(size: 13.0, middle: 0.6819),
                                    child: const Text(
                                      'SA Metering Solutions (Pty) Ltd',
                                      style: TextStyle(
                                        fontFamily: 'Roboto',
                                        fontSize: 10,
                                        color: Color(0xff024d98),
                                      ),
                                      softWrap: false,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 56.0, start: 16.0),
                                    Pin(size: 13.0, end: 11.5),
                                    child: const Text(
                                      'Mngeni road',
                                      style: TextStyle(
                                        fontFamily: 'Roboto',
                                        fontSize: 10,
                                        color: Color(0xff707070),
                                      ),
                                      softWrap: false,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(size: 132.0, start: 0.0),
                                    child: Container(
                                      decoration: const BoxDecoration(
                                        image: DecorationImage(
                                          image: AssetImage(''),
                                          fit: BoxFit.cover,
                                        ),
                                        borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(16.0),
                                          topRight: Radius.circular(16.0),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 5.0, end: 9.0),
                                    Pin(size: 20.0, middle: 0.7915),
                                    child: const Text(
                                      'SA Metering Solutions focuses on the \nSales, Marketing, Assembly and Testing',
                                      style: TextStyle(
                                        fontFamily: 'Roboto',
                                        fontSize: 8,
                                        color: Color(0xff2f302f),
                                      ),
                                      softWrap: false,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 11.0, end: 9.1),
                                    Pin(size: 13.4, end: 13.6),
                                    child: Stack(
                                      children: <Widget>[
                                        Stack(
                                          children: <Widget>[
                                            SizedBox.expand(
                                                child: SvgPicture.string(
                                              _svg_llabxp,
                                              allowDrawingOutsideViewBox: true,
                                              fit: BoxFit.fill,
                                            )),
                                            Container(
                                              color: const Color(0xff727272),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 17.5, end: 3.5),
                                    Pin(size: 17.5, middle: 0.6067),
                                    child: Stack(
                                      children: <Widget>[
                                        SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_wkpk4v,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                        Center(
                                          child: SizedBox(
                                            width: 7.0,
                                            height: 7.0,
                                            child: SvgPicture.string(
                                              _svg_f9bi5,
                                              allowDrawingOutsideViewBox: true,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Pinned.fromPins(
                            Pin(size: 155.0, middle: 0.5),
                            Pin(start: 0.0, end: 1.0),
                            child: PageLink(
                              links: [
                                PageLinkInfo(
                                  transition: LinkTransition.Fade,
                                  ease: Curves.easeOut,
                                  duration: 0.3,
                                  pageBuilder: () => const InvestSolar(),
                                ),
                              ],
                              child: Stack(
                                children: <Widget>[
                                  SizedBox.expand(
                                      child: SvgPicture.string(
                                    _svg_yxsvr,
                                    allowDrawingOutsideViewBox: true,
                                    fit: BoxFit.fill,
                                  )),
                                  Pinned.fromPins(
                                    Pin(size: 52.0, start: 5.0),
                                    Pin(size: 13.0, middle: 0.6819),
                                    child: const Text(
                                      'Invest Solar',
                                      style: TextStyle(
                                        fontFamily: 'Roboto',
                                        fontSize: 10,
                                        color: Color(0xff024d98),
                                      ),
                                      softWrap: false,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 84.0, start: 16.0),
                                    Pin(size: 13.0, end: 11.5),
                                    child: const Text(
                                      'Mount Edgecombe',
                                      style: TextStyle(
                                        fontFamily: 'Roboto',
                                        fontSize: 10,
                                        color: Color(0xff707070),
                                      ),
                                      softWrap: false,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(size: 132.0, start: 0.0),
                                    child: Container(
                                      decoration: const BoxDecoration(
                                        image: DecorationImage(
                                          image: AssetImage(''),
                                          fit: BoxFit.cover,
                                        ),
                                        borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(16.0),
                                          topRight: Radius.circular(16.0),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 7.3, start: 5.0),
                                    Pin(size: 10.4, end: 13.1),
                                    child: SvgPicture.string(
                                      _svg_p6n,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 17.5, end: 3.5),
                                    Pin(size: 17.5, middle: 0.6067),
                                    child: Stack(
                                      children: <Widget>[
                                        SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_wkpk4v,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                        Center(
                                          child: SizedBox(
                                            width: 7.0,
                                            height: 7.0,
                                            child: SvgPicture.string(
                                              _svg_f9bi5,
                                              allowDrawingOutsideViewBox: true,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 5.0, end: 4.0),
                                    Pin(size: 30.0, end: 29.5),
                                    child: const Text(
                                      ' Invest solar are specialists in alternative \nenergy solutions products, products and \ninstallations.',
                                      style: TextStyle(
                                        fontFamily: 'Roboto',
                                        fontSize: 8,
                                        color: Color(0xff2f302f),
                                      ),
                                      softWrap: false,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 11.0, end: 8.1),
                                    Pin(size: 13.4, end: 12.6),
                                    child: Stack(
                                      children: <Widget>[
                                        Stack(
                                          children: <Widget>[
                                            SizedBox.expand(
                                                child: SvgPicture.string(
                                              _svg_llabxp,
                                              allowDrawingOutsideViewBox: true,
                                              fit: BoxFit.fill,
                                            )),
                                            Container(
                                              color: const Color(0xff727272),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Pinned.fromPins(
                            Pin(size: 155.0, start: 0.0),
                            Pin(start: 0.0, end: 1.0),
                            child: PageLink(
                              links: [
                                PageLinkInfo(
                                  transition: LinkTransition.Fade,
                                  ease: Curves.easeOut,
                                  duration: 0.3,
                                  pageBuilder: () => const iPhoneXXS11Pro1(),
                                ),
                              ],
                              child: Stack(
                                children: <Widget>[
                                  SizedBox.expand(
                                      child: SvgPicture.string(
                                    _svg_vj5mf,
                                    allowDrawingOutsideViewBox: true,
                                    fit: BoxFit.fill,
                                  )),
                                  Pinned.fromPins(
                                    Pin(size: 72.0, start: 5.0),
                                    Pin(size: 13.0, middle: 0.6819),
                                    child: const Text(
                                      'Exclusive Books',
                                      style: TextStyle(
                                        fontFamily: 'Roboto',
                                        fontSize: 10,
                                        color: Color(0xff024d98),
                                      ),
                                      softWrap: false,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 84.0, start: 16.0),
                                    Pin(size: 13.0, end: 11.5),
                                    child: const Text(
                                      'Springfield, Durban',
                                      style: TextStyle(
                                        fontFamily: 'Roboto',
                                        fontSize: 10,
                                        color: Color(0xff707070),
                                      ),
                                      softWrap: false,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(size: 132.0, start: 0.0),
                                    child: Container(
                                      decoration: const BoxDecoration(
                                        image: DecorationImage(
                                          image: AssetImage(''),
                                          fit: BoxFit.cover,
                                        ),
                                        borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(16.0),
                                          topRight: Radius.circular(16.0),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 17.5, end: 3.5),
                                    Pin(size: 17.5, middle: 0.6067),
                                    child: Stack(
                                      children: <Widget>[
                                        SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_wkpk4v,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                        Center(
                                          child: SizedBox(
                                            width: 7.0,
                                            height: 7.0,
                                            child: SvgPicture.string(
                                              _svg_f9bi5,
                                              allowDrawingOutsideViewBox: true,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 5.0, end: 4.0),
                                    Pin(size: 30.0, end: 29.5),
                                    child: const Text(
                                      'FREE delivery to your door on all orders \nover R450. The Story of Exclusive\n Books Exclusive Books has a rich history',
                                      style: TextStyle(
                                        fontFamily: 'Roboto',
                                        fontSize: 8,
                                        color: Color(0xff2f302f),
                                      ),
                                      softWrap: false,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 11.0, end: 7.1),
                                    Pin(size: 13.4, end: 12.6),
                                    child: Stack(
                                      children: <Widget>[
                                        Stack(
                                          children: <Widget>[
                                            SizedBox.expand(
                                                child: SvgPicture.string(
                                              _svg_llabxp,
                                              allowDrawingOutsideViewBox: true,
                                              fit: BoxFit.fill,
                                            )),
                                            Container(
                                              color: const Color(0xff727272),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 7.3, start: 5.0),
                                    Pin(size: 10.4, end: 13.1),
                                    child: SvgPicture.string(
                                      _svg_oka1xd,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 155.0, end: 17.0),
            Pin(size: 194.0, middle: 0.4964),
            child: Stack(
              children: <Widget>[
                SizedBox.expand(
                    child: SvgPicture.string(
                  _svg_u5d6pv,
                  allowDrawingOutsideViewBox: true,
                  fit: BoxFit.fill,
                )),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 116.0, start: 0.0),
                  child: Container(
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage(''),
                        fit: BoxFit.cover,
                      ),
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(16.0),
                        topRight: Radius.circular(16.0),
                      ),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 17.5, end: 10.5),
                  Pin(size: 17.5, middle: 0.5411),
                  child: Stack(
                    children: <Widget>[
                      SizedBox.expand(
                          child: SvgPicture.string(
                        _svg_wkpk4v,
                        allowDrawingOutsideViewBox: true,
                        fit: BoxFit.fill,
                      )),
                      Center(
                        child: SizedBox(
                          width: 7.0,
                          height: 7.0,
                          child: SvgPicture.string(
                            _svg_f9bi5,
                            allowDrawingOutsideViewBox: true,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 8.6, end: 17.4),
                  Pin(size: 26.0, middle: 0.7411),
                  child: const Text(
                    'LVII CABERNET SAUVIGNON \n2016 LIMITED EDITION',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 10,
                      color: Color(0xff707070),
                    ),
                    softWrap: false,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 63.0, start: 20.6),
                  Pin(size: 13.0, end: 10.5),
                  child: const Text(
                    'louis57 Online',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 10,
                      color: Color(0xff707070),
                    ),
                    softWrap: false,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 37.0, start: 8.6),
                  Pin(size: 13.0, end: 28.5),
                  child: const Text(
                    'R650.00',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 10,
                      color: Color(0xfff60707),
                      fontWeight: FontWeight.w500,
                    ),
                    softWrap: false,
                  ),
                ),
                const Align(
                  alignment: Alignment(0.331, 0.679),
                  child: SizedBox(
                    width: 76.0,
                    height: 10.0,
                    child: Text(
                      '5% Member Discount',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 8,
                        color: Color(0xff2e302e),
                        fontWeight: FontWeight.w500,
                      ),
                      softWrap: false,
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 10.7, start: 8.6),
                  Pin(size: 13.1, end: 12.4),
                  child: SvgPicture.string(
                    _svg_v0etfk,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Container(),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 155.0, start: 18.0),
            Pin(size: 194.0, middle: 0.4964),
            child: Stack(
              children: <Widget>[
                SizedBox.expand(
                    child: SvgPicture.string(
                  _svg_b8ea97,
                  allowDrawingOutsideViewBox: true,
                  fit: BoxFit.fill,
                )),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 116.0, start: 0.0),
                  child: Container(
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage(''),
                        fit: BoxFit.cover,
                      ),
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(16.0),
                        topRight: Radius.circular(16.0),
                      ),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 17.5, end: 9.0),
                  Pin(size: 17.5, middle: 0.5411),
                  child: Stack(
                    children: <Widget>[
                      SizedBox.expand(
                          child: SvgPicture.string(
                        _svg_wkpk4v,
                        allowDrawingOutsideViewBox: true,
                        fit: BoxFit.fill,
                      )),
                      Center(
                        child: SizedBox(
                          width: 7.0,
                          height: 7.0,
                          child: SvgPicture.string(
                            _svg_f9bi5,
                            allowDrawingOutsideViewBox: true,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 88.0, start: 9.5),
                  Pin(size: 13.0, middle: 0.6878),
                  child: const Text(
                    'LXLC-Bulk-Meter2-1',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 10,
                      color: Color(0xff707070),
                    ),
                    softWrap: false,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 99.0, start: 21.5),
                  Pin(size: 13.0, end: 10.5),
                  child: const Text(
                    'SA Metering Solutions',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 10,
                      color: Color(0xff707070),
                    ),
                    softWrap: false,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 43.0, start: 9.5),
                  Pin(size: 13.0, end: 28.5),
                  child: const Text(
                    'R4450.00',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 10,
                      color: Color(0xfff60707),
                      fontWeight: FontWeight.w500,
                    ),
                    softWrap: false,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 76.0, end: 19.5),
                  Pin(size: 10.0, middle: 0.8397),
                  child: const Text(
                    '5% Member Discount',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 8,
                      color: Color(0xff3b3d3b),
                      fontWeight: FontWeight.w500,
                    ),
                    softWrap: false,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 10.7, start: 9.5),
                  Pin(size: 13.1, end: 12.4),
                  child: SvgPicture.string(
                    _svg_lvyzu,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Container(),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 1.0, middle: 0.6114),
                  child: SvgPicture.string(
                    _svg_lvtv,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 165.0, middle: 0.7174),
            child: SingleChildScrollView(
              primary: false,
              scrollDirection: Axis.horizontal,
              child: SizedBox(
                width: 565.0,
                height: 165.0,
                child: Stack(
                  children: <Widget>[
                    Pinned.fromPins(
                      Pin(size: 165.0, start: 43.0),
                      Pin(start: 0.0, end: 0.0),
                      child: Container(
                        decoration: BoxDecoration(
                          image: const DecorationImage(
                            image: AssetImage(''),
                            fit: BoxFit.cover,
                          ),
                          borderRadius: BorderRadius.circular(19.0),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0x0f000000),
                              offset: Offset(0, 0),
                              blurRadius: 30,
                            ),
                          ],
                        ),
                      ),
                    ),
                    Pinned.fromPins(
                      Pin(size: 165.0, end: -233.0),
                      Pin(start: 0.0, end: 0.0),
                      child: Container(
                        decoration: BoxDecoration(
                          image: const DecorationImage(
                            image: AssetImage(''),
                            fit: BoxFit.cover,
                          ),
                          borderRadius: BorderRadius.circular(19.0),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0x0f000000),
                              offset: Offset(0, 0),
                              blurRadius: 30,
                            ),
                          ],
                        ),
                      ),
                    ),
                    Pinned.fromPins(
                      Pin(size: 165.0, start: 243.0),
                      Pin(start: 0.0, end: 0.0),
                      child: PageLink(
                        links: [
                          PageLinkInfo(
                            transition: LinkTransition.Fade,
                            ease: Curves.easeOut,
                            duration: 0.3,
                            pageBuilder: () => const Ebook(),
                          ),
                        ],
                        child: Container(
                          decoration: BoxDecoration(
                            image: const DecorationImage(
                              image: AssetImage(''),
                              fit: BoxFit.cover,
                            ),
                            borderRadius: BorderRadius.circular(19.0),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0x0f000000),
                                offset: Offset(0, 0),
                                blurRadius: 30,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 107.0, start: 22.0),
            Pin(size: 19.0, middle: 0.3372),
            child: const Text(
              'Items for sale',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 14,
                color: Color(0xff2f302f),
                fontWeight: FontWeight.w500,
              ),
              softWrap: false,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 155.0, start: 18.0),
            Pin(size: 194.0, middle: 0.3844),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => const ProductReview(),
                ),
              ],
              child: Stack(
                children: <Widget>[
                  SizedBox.expand(
                      child: SvgPicture.string(
                    _svg_v6qxih,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  )),
                  Pinned.fromPins(
                    Pin(start: 7.0, end: 18.0),
                    Pin(size: 26.0, middle: 0.7202),
                    child: const Text(
                      '1 Panel Framed Ibr/Corr Port \nPackaged',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xff707070),
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 55.0, start: 19.0),
                    Pin(size: 13.0, end: 14.0),
                    child: const Text(
                      ' Invest Solar',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xff707070),
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 37.0, start: 7.0),
                    Pin(size: 13.0, middle: 0.8232),
                    child: const Text(
                      'R552.00',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xfff60707),
                        fontWeight: FontWeight.w500,
                      ),
                      softWrap: false,
                    ),
                  ),
                  const Align(
                    alignment: Alignment(0.241, 0.641),
                    child: SizedBox(
                      width: 76.0,
                      height: 10.0,
                      child: Text(
                        '5% Member Discount',
                        style: TextStyle(
                          fontFamily: 'Roboto',
                          fontSize: 8,
                          color: Color(0xff2e302e),
                          fontWeight: FontWeight.w500,
                        ),
                        softWrap: false,
                      ),
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(start: 21.0, end: 20.0),
                    Pin(size: 114.0, start: 0.0),
                    child: Container(
                      decoration: const BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(''),
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 17.5, end: 9.5),
                    Pin(size: 17.5, middle: 0.5297),
                    child: Stack(
                      children: <Widget>[
                        SizedBox.expand(
                            child: SvgPicture.string(
                          _svg_wkpk4v,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        )),
                        Center(
                          child: SizedBox(
                            width: 7.0,
                            height: 7.0,
                            child: SvgPicture.string(
                              _svg_f9bi5,
                              allowDrawingOutsideViewBox: true,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(start: 0.0, end: 0.0),
                    Pin(size: 1.0, middle: 0.601),
                    child: SvgPicture.string(
                      _svg_pdazp1,
                      allowDrawingOutsideViewBox: true,
                      fit: BoxFit.fill,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 10.7, start: 7.0),
                    Pin(size: 13.1, end: 15.9),
                    child: SvgPicture.string(
                      _svg_k8ou4z,
                      allowDrawingOutsideViewBox: true,
                      fit: BoxFit.fill,
                    ),
                  ),
                  Container(),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 155.0, end: 17.0),
            Pin(size: 194.0, middle: 0.3844),
            child: Stack(
              children: <Widget>[
                SizedBox.expand(
                    child: SvgPicture.string(
                  _svg_ssvmij,
                  allowDrawingOutsideViewBox: true,
                  fit: BoxFit.fill,
                )),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 116.0, start: 0.0),
                  child: Container(
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage(''),
                        fit: BoxFit.cover,
                      ),
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(16.0),
                        topRight: Radius.circular(16.0),
                      ),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 17.5, end: 10.5),
                  Pin(size: 17.5, middle: 0.5411),
                  child: Stack(
                    children: <Widget>[
                      SizedBox.expand(
                          child: SvgPicture.string(
                        _svg_wkpk4v,
                        allowDrawingOutsideViewBox: true,
                        fit: BoxFit.fill,
                      )),
                      Center(
                        child: SizedBox(
                          width: 7.0,
                          height: 7.0,
                          child: SvgPicture.string(
                            _svg_f9bi5,
                            allowDrawingOutsideViewBox: true,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 50.0, start: 9.5),
                  Pin(size: 26.0, middle: 0.7089),
                  child: const Text(
                    'Bittersweet\nSusan Cain',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 10,
                      color: Color(0xff707070),
                    ),
                    softWrap: false,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 72.0, start: 21.5),
                  Pin(size: 13.0, end: 15.9),
                  child: const Text(
                    'Exclusive Books',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 10,
                      color: Color(0xff707070),
                    ),
                    softWrap: false,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 37.0, start: 9.5),
                  Pin(size: 13.0, middle: 0.8127),
                  child: const Text(
                    'R358.00',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 10,
                      color: Color(0xfff60707),
                      fontWeight: FontWeight.w500,
                    ),
                    softWrap: false,
                  ),
                ),
                const Align(
                  alignment: Alignment(0.355, 0.621),
                  child: SizedBox(
                    width: 76.0,
                    height: 10.0,
                    child: Text(
                      '5% Member Discount',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 8,
                        color: Color(0xff2f302f),
                        fontWeight: FontWeight.w500,
                      ),
                      softWrap: false,
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 10.7, start: 9.5),
                  Pin(size: 13.1, end: 17.8),
                  child: SvgPicture.string(
                    _svg_gn4xvl,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Container(),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 201.0, start: 25.0),
            Pin(size: 19.0, middle: 0.2211),
            child: const Text(
              'Welcome Our New Members',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 14,
                color: Color(0xff2f302f),
                fontWeight: FontWeight.w500,
              ),
              softWrap: false,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 35.0, end: 25.0),
            Pin(size: 13.0, middle: 0.2232),
            child: const Text(
              'View all',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 10,
                color: Color(0xffa5a5a5),
                fontWeight: FontWeight.w500,
              ),
              softWrap: false,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 7.3, end: 42.7),
            Pin(size: 10.4, middle: 0.3158),
            child: SvgPicture.string(
              _svg_yi66gh,
              allowDrawingOutsideViewBox: true,
              fit: BoxFit.fill,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 10.0, end: 10.0),
            Pin(size: 121.0, middle: 0.1645),
            child: Stack(
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xffffffff),
                    border:
                        Border.all(width: 1.0, color: const Color(0xff707070)),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 200.0, start: 22.0),
            Pin(size: 19.0, middle: 0.7587),
            child: const Text(
              'EXCLUSIVE MEMBER BENEFITS',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 14,
                color: Color(0xff2f302f),
                fontWeight: FontWeight.w500,
              ),
              softWrap: false,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 1.0, end: 1.0),
            Pin(size: 294.0, end: 256.0),
            child: SingleChildScrollView(
              primary: false,
              child: Wrap(
                alignment: WrapAlignment.center,
                spacing: 20,
                runSpacing: 0,
                children: [
                  {
                    'text': 'SUMITOMO RUBBER \nSOUTH AFRICA',
                    'text_0':
                        'Entitled to an exclusive once-off member discount per annum up to a maximum of 15% on four or less tyre products purchased from a selected tyre dealer via the Sumitomo Rubber SA online retail system.',
                  },
                  {
                    'text': 'ONOMO HOTEL',
                    'text_0':
                        'Receive an exclusive discount rate at their 3 start Hotel. A rate of R945 Single and R1,260 sharing (Bed and Breakfast included).',
                  },
                  {
                    'text': 'ONOMO HOTEL',
                    'text_0':
                        'Receive an exclusive discount rate at their 3 start Hotel. A rate of R945 Single and R1,260 sharing (Bed and Breakfast included).',
                  }
                ].map((itemData) {
                  final text = itemData['text'];
                  final text_0 = itemData['text_0'];
                  return SizedBox(
                    width: 325.0,
                    height: 124.0,
                    child: Stack(
                      children: <Widget>[
                        Container(
                          decoration: BoxDecoration(
                            color: const Color(0xff004c98),
                            borderRadius: BorderRadius.circular(8.0),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0x29000000),
                                offset: Offset(0, 0),
                                blurRadius: 16,
                              ),
                            ],
                          ),
                          margin: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 4.0),
                        ),
                        Pinned.fromPins(
                          Pin(size: 100.0, start: 10.0),
                          Pin(start: 10.0, end: 14.0),
                          child: SvgPicture.string(
                            _svg_cjcuw,
                            allowDrawingOutsideViewBox: true,
                            fit: BoxFit.fill,
                          ),
                        ),
                        Pinned.fromPins(
                          Pin(size: 130.0, middle: 0.6462),
                          Pin(size: 33.0, start: 8.0),
                          child: Text(
                            text,
                            style: const TextStyle(
                              fontFamily: 'SF Pro Display',
                              fontSize: 13,
                              color: Color(0xffffffff),
                              fontWeight: FontWeight.w700,
                              height: 1.2307692307692308,
                            ),
                            textHeightBehavior: const TextHeightBehavior(
                                applyHeightToFirstAscent: false),
                            softWrap: false,
                          ),
                        ),
                        Pinned.fromPins(
                          Pin(size: 190.0, end: 9.0),
                          Pin(size: 76.0, end: 0.0),
                          child: Text(
                            text_0,
                            style: const TextStyle(
                              fontFamily: 'SF Pro Display',
                              fontSize: 9,
                              color: Color(0xffffffff),
                              fontWeight: FontWeight.w300,
                              height: 1.7777777777777777,
                            ),
                            textHeightBehavior: const TextHeightBehavior(
                                applyHeightToFirstAscent: false),
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 41.0, end: 34.0),
            Pin(size: 13.0, middle: 0.7303),
            child: Container(
              color: const Color(0x00ffffff),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 64.0, middle: 0.3423),
            child: Stack(
              children: <Widget>[
                Container(
                  decoration: const BoxDecoration(
                    color: Color(0xffecf9fe),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0xffffffff),
                        offset: Offset(0, -13),
                        blurRadius: 26,
                      ),
                    ],
                  ),
                ),
                Align(
                  alignment: const Alignment(0.259, -0.2),
                  child: SizedBox(
                    width: 25.0,
                    height: 24.0,
                    child: PageLink(
                      links: [
                        PageLinkInfo(
                          transition: LinkTransition.Fade,
                          ease: Curves.easeOut,
                          duration: 0.3,
                          pageBuilder: () => const wishlist(),
                        ),
                      ],
                      child: SvgPicture.string(
                        _svg_dbt3z,
                        allowDrawingOutsideViewBox: true,
                      ),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 30.9, start: 25.0),
                  Pin(size: 24.0, middle: 0.4),
                  child: SvgPicture.string(
                    _svg_czb,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Align(
                  alignment: const Alignment(-0.317, -0.2),
                  child: SizedBox(
                    width: 24.0,
                    height: 24.0,
                    child: PageLink(
                      links: [
                        PageLinkInfo(
                          transition: LinkTransition.Fade,
                          ease: Curves.easeOut,
                          duration: 0.3,
                          pageBuilder: () => const Search(),
                        ),
                      ],
                      child: SvgPicture.string(
                        _svg_feo4dn,
                        allowDrawingOutsideViewBox: true,
                      ),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 24.0, end: 29.2),
                  Pin(size: 24.0, middle: 0.4),
                  child: PageLink(
                    links: [
                      PageLinkInfo(
                        transition: LinkTransition.Fade,
                        ease: Curves.easeOut,
                        duration: 0.3,
                        pageBuilder: () => const Profile(),
                      ),
                    ],
                    child: SvgPicture.string(
                      _svg_q1qd0a,
                      allowDrawingOutsideViewBox: true,
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 150.0, start: 22.0),
            Pin(size: 19.0, middle: 0.5583),
            child: const Text(
              'Latest ads near you',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 14,
                color: Color(0xff2f302f),
                fontWeight: FontWeight.w500,
              ),
              softWrap: false,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 155.0, start: 18.0),
            Pin(size: 194.0, middle: 0.6209),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => const Louis57(),
                ),
              ],
              child: Stack(
                children: <Widget>[
                  SizedBox.expand(
                      child: SvgPicture.string(
                    _svg_u6s623,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  )),
                  Pinned.fromPins(
                    Pin(size: 106.0, start: 4.0),
                    Pin(size: 13.0, middle: 0.6685),
                    child: const Text(
                      'Louis57 Retail (Pty) Ltd ',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xff004c98),
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 45.0, start: 15.0),
                    Pin(size: 13.0, end: 18.0),
                    child: const Text(
                      'Glenwood',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xff707070),
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(start: 0.0, end: 0.0),
                    Pin(size: 116.0, start: 0.0),
                    child: Container(
                      decoration: const BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(''),
                          fit: BoxFit.cover,
                        ),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(16.0),
                          topRight: Radius.circular(16.0),
                        ),
                      ),
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(start: 4.0, end: 4.0),
                    Pin(size: 20.0, middle: 0.7759),
                    child: const Text(
                      'Here we have got something for everyone\nwith the wine sommelier, gin & brandy...',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 8,
                        color: Color(0xff2f302f),
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 7.3, start: 4.0),
                    Pin(size: 10.4, end: 19.6),
                    child: SvgPicture.string(
                      _svg_w5xwkp,
                      allowDrawingOutsideViewBox: true,
                      fit: BoxFit.fill,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 17.5, end: 9.0),
                    Pin(size: 17.5, middle: 0.5411),
                    child: Stack(
                      children: <Widget>[
                        SizedBox.expand(
                            child: SvgPicture.string(
                          _svg_wkpk4v,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        )),
                        Center(
                          child: SizedBox(
                            width: 7.0,
                            height: 7.0,
                            child: SvgPicture.string(
                              _svg_f9bi5,
                              allowDrawingOutsideViewBox: true,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 155.0, end: 17.0),
            Pin(size: 194.0, middle: 0.6209),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => const Krelumlighting(),
                ),
              ],
              child: Stack(
                children: <Widget>[
                  SizedBox.expand(
                      child: SvgPicture.string(
                    _svg_ta2jpn,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  )),
                  Pinned.fromPins(
                    Pin(size: 110.0, start: 7.0),
                    Pin(size: 13.0, middle: 0.6519),
                    child: const Text(
                      'Krelum Lighting (Pty) Ltd',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xff004c98),
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(start: 7.0, end: 6.0),
                    Pin(size: 20.0, middle: 0.7586),
                    child: const Text(
                      'Our goal has always been to provide our\n customers with a wide product range...',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 8,
                        color: Color(0xff2f302f),
                      ),
                      softWrap: false,
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(start: 0.0, end: 0.0),
                    Pin(size: 116.0, start: 0.0),
                    child: Container(
                      decoration: const BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(''),
                          fit: BoxFit.cover,
                        ),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(16.0),
                          topRight: Radius.circular(16.0),
                        ),
                      ),
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 69.0, start: 7.0),
                    Pin(size: 13.0, end: 18.0),
                    child: Stack(
                      children: <Widget>[
                        Pinned.fromPins(
                          Pin(size: 58.0, end: 0.0),
                          Pin(start: 0.0, end: 0.0),
                          child: const Text(
                            'Morning side',
                            style: TextStyle(
                              fontFamily: 'Roboto',
                              fontSize: 10,
                              color: Color(0xff707070),
                            ),
                            softWrap: false,
                          ),
                        ),
                        Pinned.fromPins(
                          Pin(size: 7.3, start: 0.0),
                          Pin(start: 1.0, end: 1.6),
                          child: SvgPicture.string(
                            _svg_mlkl0t,
                            allowDrawingOutsideViewBox: true,
                            fit: BoxFit.fill,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 17.5, end: 10.5),
                    Pin(size: 17.5, middle: 0.5411),
                    child: Stack(
                      children: <Widget>[
                        SizedBox.expand(
                            child: SvgPicture.string(
                          _svg_wkpk4v,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        )),
                        Center(
                          child: SizedBox(
                            width: 7.0,
                            height: 7.0,
                            child: SvgPicture.string(
                              _svg_f9bi5,
                              allowDrawingOutsideViewBox: true,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 41.0, end: 34.0),
            Pin(size: 13.0, middle: 0.7581),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => const ExclusiveMembership(),
                ),
              ],
              child: Stack(
                children: <Widget>[
                  const Padding(
                    padding:
                        EdgeInsets.symmetric(horizontal: 3.0, vertical: 0.0),
                    child: SizedBox.expand(
                        child: Text(
                      'View all',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 10,
                        color: Color(0xffa5a5a5),
                        fontWeight: FontWeight.w500,
                      ),
                      softWrap: false,
                    )),
                  ),
                  Container(
                    color: const Color(0x00ffffff),
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 335.0, start: 0.0),
            child: Stack(
              children: <Widget>[
                Container(
                  color: const Color(0xffecf9fe),
                ),
                Pinned.fromPins(
                  Pin(size: 128.0, start: 42.0),
                  Pin(size: 19.0, middle: 0.7504),
                  child: const Text(
                    'Windermere, Durban',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 14,
                      color: Color(0xffababab),
                      fontWeight: FontWeight.w500,
                    ),
                    softWrap: false,
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 20.0, end: 25.0),
                  Pin(size: 50.0, middle: 0.4982),
                  child: Stack(
                    children: <Widget>[
                      SizedBox.expand(
                          child: SvgPicture.string(
                        _svg_owdjhr,
                        allowDrawingOutsideViewBox: true,
                        fit: BoxFit.fill,
                      )),
                      Pinned.fromPins(
                        Pin(size: 47.0, start: 21.0),
                        Pin(size: 20.0, middle: 0.4667),
                        child: const Text(
                          'Search',
                          style: TextStyle(
                            fontFamily: 'SF Pro Display',
                            fontSize: 15,
                            color: Color(0xff111111),
                            fontWeight: FontWeight.w700,
                            height: 1.4666666666666666,
                          ),
                          textHeightBehavior: TextHeightBehavior(
                              applyHeightToFirstAscent: false),
                          softWrap: false,
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 140.0, start: 19.0),
                  Pin(size: 19.0, middle: 0.3734),
                  child: const Text(
                    'Membership Directory',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 14,
                      color: Color(0xff004c98),
                      fontWeight: FontWeight.w700,
                    ),
                    softWrap: false,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 64.0, start: 19.0),
                  Pin(size: 19.0, middle: 0.6234),
                  child: const Text(
                    'Search by:',
                    style: TextStyle(
                      fontFamily: 'Roboto',
                      fontSize: 14,
                      color: Color(0xff004c98),
                    ),
                    softWrap: false,
                  ),
                ),
                const Align(
                  alignment: Alignment(-0.444, 0.247),
                  child: SizedBox(
                    width: 37.0,
                    height: 19.0,
                    child: Text(
                      'Name',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 14,
                        color: Color(0xff004c98),
                      ),
                      softWrap: false,
                    ),
                  ),
                ),
                const Align(
                  alignment: Alignment(-0.03, 0.247),
                  child: SizedBox(
                    width: 40.0,
                    height: 19.0,
                    child: Text(
                      'Sector',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 14,
                        color: Color(0xff004c98),
                      ),
                      softWrap: false,
                    ),
                  ),
                ),
                const Align(
                  alignment: Alignment(0.309, 0.247),
                  child: SizedBox(
                    width: 16.0,
                    height: 19.0,
                    child: Text(
                      'All',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 14,
                        color: Color(0xff004c98),
                      ),
                      softWrap: false,
                    ),
                  ),
                ),
                Container(),
                Pinned.fromPins(
                  Pin(size: 86.0, start: 20.0),
                  Pin(size: 32.0, end: 20.0),
                  child: PageLink(
                    links: [
                      PageLinkInfo(
                        transition: LinkTransition.Fade,
                        ease: Curves.easeOut,
                        duration: 0.3,
                        pageBuilder: () => const Shopping(),
                      ),
                    ],
                    child: Stack(
                      children: <Widget>[
                        Container(
                          decoration: BoxDecoration(
                            color: const Color(0xffffffff),
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                        ),
                        Pinned.fromPins(
                          Pin(start: 5.1, end: 10.2),
                          Pin(size: 17.0, middle: 0.4003),
                          child: Stack(
                            children: <Widget>[
                              Pinned.fromPins(
                                Pin(size: 51.0, end: 0.0),
                                Pin(start: 0.5, end: 0.5),
                                child: const Text(
                                  'Shopping',
                                  style: TextStyle(
                                    fontFamily: 'Roboto',
                                    fontSize: 12,
                                    color: Color(0xff707070),
                                    fontWeight: FontWeight.w700,
                                  ),
                                  softWrap: false,
                                ),
                              ),
                              Pinned.fromPins(
                                Pin(size: 13.1, start: 0.0),
                                Pin(start: 0.0, end: 0.0),
                                child: Stack(
                                  children: <Widget>[
                                    Stack(
                                      children: <Widget>[
                                        SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_px8a,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                        Container(
                                          color: const Color(0xff004c98),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 83.0, middle: 0.3801),
                  Pin(size: 32.0, end: 20.0),
                  child: PageLink(
                    links: [
                      PageLinkInfo(
                        transition: LinkTransition.Fade,
                        ease: Curves.easeOut,
                        duration: 0.3,
                        pageBuilder: () => const Selling(),
                      ),
                    ],
                    child: Stack(
                      children: <Widget>[
                        Container(
                          decoration: BoxDecoration(
                            color: const Color(0xffffffff),
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                        ),
                        Pinned.fromPins(
                          Pin(size: 56.5, start: 4.5),
                          Pin(size: 17.4, middle: 0.5481),
                          child: Stack(
                            children: <Widget>[
                              Pinned.fromPins(
                                Pin(size: 37.0, end: 0.0),
                                Pin(start: 0.0, end: 1.4),
                                child: const Text(
                                  'Selling',
                                  style: TextStyle(
                                    fontFamily: 'Roboto',
                                    fontSize: 12,
                                    color: Color(0xff707070),
                                    fontWeight: FontWeight.w700,
                                  ),
                                  softWrap: false,
                                ),
                              ),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: SizedBox(
                                  width: 14.0,
                                  height: 14.0,
                                  child: Stack(
                                    children: <Widget>[
                                      Stack(
                                        children: <Widget>[
                                          SizedBox.expand(
                                              child: SvgPicture.string(
                                            _svg_yoibv8,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          )),
                                          Align(
                                            alignment: const Alignment(-0.6, -0.6),
                                            child: SizedBox(
                                              width: 3.0,
                                              height: 3.0,
                                              child: SvgPicture.string(
                                                _svg_s90m1x,
                                                allowDrawingOutsideViewBox:
                                                    true,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            color: const Color(0xff004c98),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(),
                Container(),
                Pinned.fromPins(
                  Pin(size: 14.8, start: 20.0),
                  Pin(size: 21.1, middle: 0.7487),
                  child: SvgPicture.string(
                    _svg_yqlrr2,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 44.0, start: 0.0),
                  child: Stack(
                    children: <Widget>[
                      SizedBox.expand(
                          child: SvgPicture.string(
                        _svg_mhz2ca,
                        allowDrawingOutsideViewBox: true,
                        fit: BoxFit.fill,
                      )),
                      Pinned.fromPins(
                        Pin(start: 20.0, end: 14.7),
                        Pin(size: 16.0, middle: 0.5357),
                        child: Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(size: 24.3, end: 0.0),
                              Pin(start: 2.3, end: 2.3),
                              child: Stack(
                                children: <Widget>[
                                  Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(0.0, 0.0, 2.3, 0.0),
                                    child: Stack(
                                      children: <Widget>[
                                        SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_i4lwc,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                        SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_hn,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                      ],
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.centerRight,
                                    child: SizedBox(
                                      width: 1.0,
                                      height: 4.0,
                                      child: Stack(
                                        children: <Widget>[
                                          Padding(
                                            padding: const EdgeInsets.all(-5.0),
                                            child: SizedBox.expand(
                                                child: SvgPicture.string(
                                              _svg_tszyk4,
                                              allowDrawingOutsideViewBox: true,
                                              fit: BoxFit.fill,
                                            )),
                                          ),
                                          SizedBox.expand(
                                              child: SvgPicture.string(
                                            _svg_w6qqk0,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          )),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 18.0, start: 2.0),
                                    Pin(size: 7.3, middle: 0.5),
                                    child: Stack(
                                      children: <Widget>[
                                        Padding(
                                          padding: const EdgeInsets.all(-5.0),
                                          child: SizedBox.expand(
                                              child: SvgPicture.string(
                                            _svg_hy2fm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          )),
                                        ),
                                        SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_avi4k,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 15.3, end: 29.4),
                              Pin(size: 11.0, start: 2.3),
                              child: Stack(
                                children: <Widget>[
                                  Stack(
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.all(-5.0),
                                        child: SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_tav08,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                      ),
                                      SizedBox.expand(
                                          child: SvgPicture.string(
                                        _svg_iki5el,
                                        allowDrawingOutsideViewBox: true,
                                        fit: BoxFit.fill,
                                      )),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 17.0, end: 49.7),
                              Pin(size: 10.7, middle: 0.5),
                              child: Stack(
                                children: <Widget>[
                                  Stack(
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.all(-5.0),
                                        child: SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_nqpuq1,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                      ),
                                      SizedBox.expand(
                                          child: SvgPicture.string(
                                        _svg_n4r2,
                                        allowDrawingOutsideViewBox: true,
                                        fit: BoxFit.fill,
                                      )),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 54.0, start: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child: Stack(
                                children: <Widget>[
                                  SizedBox.expand(
                                      child: SvgPicture.string(
                                    _svg_u6yej,
                                    allowDrawingOutsideViewBox: true,
                                    fit: BoxFit.fill,
                                  )),
                                  Pinned.fromPins(
                                    Pin(start: 12.8, end: 13.7),
                                    Pin(size: 10.3, end: 0.8),
                                    child: SvgPicture.string(
                                      _svg_snrsq,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 29.0, end: 24.6),
                  Pin(size: 23.5, middle: 0.3445),
                  child: Stack(
                    children: <Widget>[
                      Stack(
                        children: <Widget>[
                          SizedBox.expand(
                              child: SvgPicture.string(
                            _svg_cnz1c7,
                            allowDrawingOutsideViewBox: true,
                            fit: BoxFit.fill,
                          )),
                          Container(
                            color: const Color(0xff004c98),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Align(
                  alignment: const Alignment(-0.224, 0.252),
                  child: SizedBox(
                    width: 12.0,
                    height: 12.0,
                    child: SvgPicture.string(
                      _svg_gmfcyn,
                      allowDrawingOutsideViewBox: true,
                    ),
                  ),
                ),
                Align(
                  alignment: const Alignment(0.175, 0.252),
                  child: SizedBox(
                    width: 12.0,
                    height: 12.0,
                    child: SvgPicture.string(
                      _svg_rmuu0,
                      allowDrawingOutsideViewBox: true,
                    ),
                  ),
                ),
                Align(
                  alignment: const Alignment(0.436, 0.252),
                  child: SizedBox(
                    width: 12.0,
                    height: 12.0,
                    child: SvgPicture.string(
                      _svg_lxpd,
                      allowDrawingOutsideViewBox: true,
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 150.0, end: 25.0),
                  Pin(size: 32.0, end: 20.0),
                  child: PageLink(
                    links: [
                      PageLinkInfo(
                        transition: LinkTransition.Fade,
                        ease: Curves.easeOut,
                        duration: 0.3,
                        pageBuilder: () => const ValueAddedServices(),
                      ),
                    ],
                    child: Stack(
                      children: <Widget>[
                        Container(
                          decoration: BoxDecoration(
                            color: const Color(0xff004c98),
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                        ),
                        Pinned.fromPins(
                          Pin(size: 118.0, end: 3.0),
                          Pin(size: 16.0, middle: 0.5),
                          child: const Text(
                            'Value Added Services',
                            style: TextStyle(
                              fontFamily: 'Roboto',
                              fontSize: 12,
                              color: Color(0xffffffff),
                              fontWeight: FontWeight.w700,
                            ),
                            softWrap: false,
                          ),
                        ),
                        Pinned.fromPins(
                          Pin(size: 20.5, start: 5.5),
                          Pin(size: 20.5, middle: 0.4356),
                          child: Stack(
                            children: <Widget>[
                              Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(size: 16.9, end: 0.0),
                                    Pin(size: 8.6, end: 2.4),
                                    child: SvgPicture.string(
                                      _svg_iufec1,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.bottomLeft,
                                    child: SizedBox(
                                      width: 6.0,
                                      height: 9.0,
                                      child: SvgPicture.string(
                                        _svg_tb7ssu,
                                        allowDrawingOutsideViewBox: true,
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: const Alignment(0.087, -0.423),
                                    child: SizedBox(
                                      width: 7.0,
                                      height: 4.0,
                                      child: SvgPicture.string(
                                        _svg_zg7ex,
                                        allowDrawingOutsideViewBox: true,
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: const Alignment(0.074, -1.0),
                                    child: SizedBox(
                                      width: 5.0,
                                      height: 5.0,
                                      child: SvgPicture.string(
                                        _svg_k1k1bd,
                                        allowDrawingOutsideViewBox: true,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    color: const Color(0xffffffff),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 81.1, middle: 0.4504),
                  Pin(size: 57.3, start: 38.7),
                  child: Stack(
                    children: <Widget>[
                      Stack(
                        children: <Widget>[
                          Pinned.fromPins(
                            Pin(start: 0.0, end: 0.0),
                            Pin(size: 10.0, end: 6.7),
                            child: SvgPicture.string(
                              _svg_pyv499,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            ),
                          ),
                          Pinned.fromPins(
                            Pin(start: 12.1, end: 12.1),
                            Pin(size: 3.6, end: 0.0),
                            child: SvgPicture.string(
                              _svg_vlvtax,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            ),
                          ),
                          Pinned.fromPins(
                            Pin(start: 14.5, end: 14.5),
                            Pin(size: 30.6, start: 0.0),
                            child: SvgPicture.string(
                              _svg_iv1,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            ),
                          ),
                          Container(
                            decoration: const BoxDecoration(),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_cjcuw =
    '<svg viewBox="35.0 329.0 100.0 100.0" ><path transform="translate(35.0, 329.0)" d="M 10 0 L 90 0 C 95.52285003662109 0 100 4.477152347564697 100 10 L 100 90 C 100 95.52285003662109 95.52285003662109 100 90 100 L 10 100 C 4.477152347564697 100 0 95.52285003662109 0 90 L 0 10 C 0 4.477152347564697 4.477152347564697 0 10 0 Z" fill="none" stroke="none" stroke-width="0.5" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_az3zv8 =
    '<svg viewBox="306.4 13.2 8.3 10.4" ><path  d="M 309.5899963378906 13.22399997711182 C 310.3030090332031 13.22399997711182 310.9750061035156 13.36100006103516 311.6069946289062 13.63300037384033 C 312.2369995117188 13.9060001373291 312.7850036621094 14.27799987792969 313.2529907226562 14.75 C 313.7200012207031 15.22200012207031 314.0899963378906 15.77200031280518 314.3630065917969 16.40200042724609 C 314.6380004882812 17.0310001373291 314.7730102539062 17.70199966430664 314.7730102539062 18.41500091552734 C 314.7730102539062 19.12800025939941 314.6380004882812 19.79899978637695 314.3630065917969 20.42799949645996 C 314.0899963378906 21.05699920654297 313.7200012207031 21.60499954223633 313.2529907226562 22.07200050354004 C 312.7850036621094 22.53899955749512 312.2369995117188 22.90800094604492 311.6069946289062 23.18099975585938 C 310.9750061035156 23.45400047302246 310.3030090332031 23.59000015258789 309.5899963378906 23.59000015258789 L 306.43798828125 23.59000015258789 L 306.43798828125 13.22399997711182 L 309.5899963378906 13.22399997711182 Z M 314.0820007324219 18.41500091552734 C 314.0820007324219 17.79599952697754 313.9639892578125 17.2140007019043 313.7279968261719 16.66900062561035 C 313.4909973144531 16.12400054931641 313.1690063476562 15.64700031280518 312.760009765625 15.23799991607666 C 312.3519897460938 14.82900047302246 311.875 14.50599956512451 311.3280029296875 14.27000045776367 C 310.7839965820312 14.03499984741211 310.2019958496094 13.91600036621094 309.5830078125 13.91600036621094 L 307.1289978027344 13.91600036621094 L 307.1289978027344 22.89800071716309 L 309.5830078125 22.89800071716309 C 310.2019958496094 22.89800071716309 310.7839965820312 22.78000068664551 311.3280029296875 22.54400062561035 C 311.875 22.3080005645752 312.3519897460938 21.98800086975098 312.760009765625 21.58399963378906 C 313.1690063476562 21.18099975585938 313.4909973144531 20.70599937438965 313.7279968261719 20.1609992980957 C 313.9639892578125 19.61599922180176 314.0820007324219 19.03400039672852 314.0820007324219 18.41500091552734" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_pp66fb =
    '<svg viewBox="325.8 13.2 8.9 10.4" ><path  d="M 334.7724914550781 13.22429656982422 L 334.7724914550781 14.09130096435547 L 330.7524719238281 14.09130096435547 L 330.7524719238281 23.58930206298828 L 329.8854675292969 23.58930206298828 L 329.8854675292969 14.09130096435547 L 325.8454895019531 14.09130096435547 L 325.8454895019531 13.22429656982422 L 334.7724914550781 13.22429656982422 Z" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_id6nld =
    '<svg viewBox="335.1 13.2 8.6 10.4" ><path  d="M 343.7210083007812 22.26499938964844 C 343.2179870605469 22.68600082397461 342.6740112304688 23.01199913024902 342.0880126953125 23.24300003051758 C 341.5029907226562 23.47400093078613 340.8869934082031 23.59000015258789 340.239990234375 23.59000015258789 C 339.5220031738281 23.59000015258789 338.8489990234375 23.45100021362305 338.2229919433594 23.17399978637695 C 337.5960083007812 22.89699935913086 337.0499877929688 22.52400016784668 336.5820007324219 22.05699920654297 C 336.114990234375 21.59000015258789 335.7479858398438 21.04100036621094 335.4809875488281 20.40900039672852 C 335.2139892578125 19.77799987792969 335.0809936523438 19.10799980163574 335.0809936523438 18.39900016784668 C 335.0809936523438 17.68099975585938 335.2139892578125 17.00799942016602 335.4809875488281 16.38199996948242 C 335.7479858398438 15.75500011444092 336.114990234375 15.20899963378906 336.5820007324219 14.74100017547607 C 337.0499877929688 14.27400016784668 337.5960083007812 13.90499973297119 338.2229919433594 13.63199996948242 C 338.8489990234375 13.36100006103516 339.5220031738281 13.22399997711182 340.239990234375 13.22399997711182 C 340.7950134277344 13.22399997711182 341.3420104980469 13.31900024414062 341.8810119628906 13.50899982452393 C 342.4200134277344 13.69900035858154 342.9410095214844 13.97399997711182 343.4440002441406 14.33300018310547 L 342.9049987792969 14.74899959564209 C 342.5150146484375 14.47200012207031 342.093994140625 14.26099967956543 341.6419982910156 14.11800003051758 C 341.1900024414062 13.97399997711182 340.7229919433594 13.90200042724609 340.239990234375 13.90200042724609 C 339.614013671875 13.90200042724609 339.0289916992188 14.02000045776367 338.4849853515625 14.25599956512451 C 337.9400024414062 14.49199962615967 337.4649963378906 14.8120002746582 337.0599975585938 15.21700000762939 C 336.6539916992188 15.62100028991699 336.3359985351562 16.09799957275391 336.1050109863281 16.64699935913086 C 335.8739929199219 17.19499969482422 335.7579956054688 17.7819995880127 335.7579956054688 18.4069995880127 C 335.7579956054688 19.02199935913086 335.8739929199219 19.60400009155273 336.1050109863281 20.15200042724609 C 336.3359985351562 20.70100021362305 336.6539916992188 21.17700004577637 337.0599975585938 21.58200073242188 C 337.4649963378906 21.98699951171875 337.9400024414062 22.30999946594238 338.4849853515625 22.55100059509277 C 339.0289916992188 22.79199981689453 339.614013671875 22.91200065612793 340.239990234375 22.91200065612793 C 340.7950134277344 22.91200065612793 341.3290100097656 22.80699920654297 341.8420104980469 22.59600067138672 C 342.3559875488281 22.38599967956543 342.8380126953125 22.09099960327148 343.2900085449219 21.71100044250488 L 343.7210083007812 22.26499938964844 Z" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_z3w4sa =
    '<svg viewBox="356.2 13.2 8.8 10.4" ><path  d="M 365.0658874511719 13.26290130615234 L 365.0658874511719 23.58990478515625 L 364.2128601074219 23.58990478515625 L 364.2128601074219 15.56890869140625 L 362.7988586425781 17.36990356445312 L 360.6488647460938 20.04390716552734 L 357.0448608398438 15.54890441894531 L 357.0448608398438 23.58990478515625 L 356.2308654785156 23.58990478515625 L 356.2308654785156 13.22390747070312 L 360.6488647460938 18.72690582275391 L 365.0658874511719 13.26290130615234 Z" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_z3vh7p =
    '<svg viewBox="344.3 13.2 10.4 10.4" ><path  d="M 354.3399963378906 20.11199951171875 C 354.5270080566406 19.57699966430664 354.6289978027344 19.00300025939941 354.6289978027344 18.4060001373291 C 354.6289978027344 17.80900001525879 354.5270080566406 17.23600006103516 354.3399963378906 16.70100021362305 C 354.3359985351562 16.68499946594238 354.3299865722656 16.67000007629395 354.3240051269531 16.65500068664551 C 353.60400390625 14.6569995880127 351.6889953613281 13.22399997711182 349.4460144042969 13.22399997711182 C 347.2030029296875 13.22399997711182 345.2879943847656 14.6569995880127 344.5690002441406 16.65500068664551 C 344.56201171875 16.67000007629395 344.5559997558594 16.68499946594238 344.552001953125 16.70100021362305 C 344.364990234375 17.23600006103516 344.2640075683594 17.80900001525879 344.2640075683594 18.4060001373291 C 344.2640075683594 19.00300025939941 344.364990234375 19.57699966430664 344.552001953125 20.11199951171875 C 344.5570068359375 20.12800025939941 344.56201171875 20.14299964904785 344.5690002441406 20.15800094604492 C 345.2890014648438 22.1569995880127 347.2030029296875 23.5890007019043 349.4460144042969 23.5890007019043 C 351.6889953613281 23.5890007019043 353.60400390625 22.1569995880127 354.3240051269531 20.15800094604492 C 354.3299865722656 20.14299964904785 354.3359985351562 20.12800025939941 354.3399963378906 20.11199951171875 M 349.4460144042969 22.84600067138672 C 349.2489929199219 22.84600067138672 348.9309997558594 22.48900032043457 348.6650085449219 21.69099998474121 C 348.5360107421875 21.30599975585938 348.4339904785156 20.86300086975098 348.3590087890625 20.38199996948242 L 350.5339965820312 20.38199996948242 C 350.4590148925781 20.86300086975098 350.3559875488281 21.30599975585938 350.2279968261719 21.69099998474121 C 349.9620056152344 22.48900032043457 349.6430053710938 22.84600067138672 349.4460144042969 22.84600067138672 M 348.2680053710938 19.63899993896484 C 348.2330017089844 19.24300003051758 348.2139892578125 18.82900047302246 348.2139892578125 18.4060001373291 C 348.2139892578125 17.98299980163574 348.2330017089844 17.56999969482422 348.2680053710938 17.17399978637695 L 350.6239929199219 17.17399978637695 C 350.6589965820312 17.56999969482422 350.6780090332031 17.98299980163574 350.6780090332031 18.4060001373291 C 350.6780090332031 18.82900047302246 350.6589965820312 19.24300003051758 350.6239929199219 19.63899993896484 L 348.2680053710938 19.63899993896484 Z M 345.0069885253906 18.4060001373291 C 345.0069885253906 17.97900009155273 345.0669860839844 17.56599998474121 345.1809997558594 17.17399978637695 L 347.5230102539062 17.17399978637695 C 347.489013671875 17.57900047302246 347.4710083007812 17.99300003051758 347.4710083007812 18.4060001373291 C 347.4710083007812 18.81999969482422 347.489013671875 19.23399925231934 347.5230102539062 19.63899993896484 L 345.1809997558594 19.63899993896484 C 345.0669860839844 19.24699974060059 345.0069885253906 18.83399963378906 345.0069885253906 18.4060001373291 M 349.4460144042969 13.96700000762939 C 349.6430053710938 13.96700000762939 349.9620056152344 14.32400035858154 350.2279968261719 15.12199974060059 C 350.3559875488281 15.50699996948242 350.4590148925781 15.94999980926514 350.5339965820312 16.43099975585938 L 348.3590087890625 16.43099975585938 C 348.4330139160156 15.94999980926514 348.5360107421875 15.50699996948242 348.6650085449219 15.12199974060059 C 348.9309997558594 14.32400035858154 349.2489929199219 13.96700000762939 349.4460144042969 13.96700000762939 M 351.3689880371094 17.17399978637695 L 353.7120056152344 17.17399978637695 C 353.8250122070312 17.56599998474121 353.885986328125 17.97900009155273 353.885986328125 18.4060001373291 C 353.885986328125 18.83399963378906 353.8250122070312 19.24799919128418 353.7120056152344 19.63899993896484 L 351.3689880371094 19.63899993896484 C 351.4039916992188 19.23399925231934 351.4209899902344 18.81999969482422 351.4209899902344 18.4060001373291 C 351.4209899902344 17.99300003051758 351.4039916992188 17.57900047302246 351.3689880371094 17.17399978637695 M 353.4209899902344 16.43099975585938 L 351.2839965820312 16.43099975585938 C 351.1520080566406 15.52000045776367 350.9249877929688 14.70300006866455 350.6069946289062 14.12100028991699 C 351.8399963378906 14.45499992370605 352.8609924316406 15.30900001525879 353.4209899902344 16.43099975585938 M 348.2850036621094 14.12100028991699 C 347.9670104980469 14.70300006866455 347.7409973144531 15.52000045776367 347.6080017089844 16.43099975585938 L 345.4710083007812 16.43099975585938 C 346.031005859375 15.30900001525879 347.052001953125 14.45499992370605 348.2850036621094 14.12100028991699 M 345.4710083007812 20.38199996948242 L 347.6080017089844 20.38199996948242 C 347.7409973144531 21.29299926757812 347.9670104980469 22.11000061035156 348.2850036621094 22.6919994354248 C 347.052001953125 22.35700035095215 346.031005859375 21.50399971008301 345.4710083007812 20.38199996948242 M 350.6069946289062 22.6919994354248 C 350.9249877929688 22.11000061035156 351.1520080566406 21.29299926757812 351.2839965820312 20.38199996948242 L 353.4209899902344 20.38199996948242 C 352.8609924316406 21.50399971008301 351.8399963378906 22.35700035095215 350.6069946289062 22.6919994354248" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_c29owo =
    '<svg viewBox="315.7 13.2 10.4 10.4" ><path  d="M 325.8070068359375 20.11199951171875 C 325.9939880371094 19.57699966430664 326.0960083007812 19.00300025939941 326.0960083007812 18.4060001373291 C 326.0960083007812 17.80900001525879 325.9939880371094 17.23600006103516 325.8070068359375 16.70100021362305 C 325.8030090332031 16.68499946594238 325.7969970703125 16.67000007629395 325.7909851074219 16.65500068664551 C 325.0710144042969 14.6569995880127 323.156005859375 13.22399997711182 320.9129943847656 13.22399997711182 C 318.6700134277344 13.22399997711182 316.7550048828125 14.6569995880127 316.0360107421875 16.65500068664551 C 316.0289916992188 16.67000007629395 316.0230102539062 16.68499946594238 316.0190124511719 16.70100021362305 C 315.8320007324219 17.23600006103516 315.7309875488281 17.80900001525879 315.7309875488281 18.4060001373291 C 315.7309875488281 19.00300025939941 315.8320007324219 19.57699966430664 316.0190124511719 20.11199951171875 C 316.0239868164062 20.12800025939941 316.0289916992188 20.14299964904785 316.0360107421875 20.15800094604492 C 316.7560119628906 22.1569995880127 318.6700134277344 23.5890007019043 320.9129943847656 23.5890007019043 C 323.156005859375 23.5890007019043 325.0710144042969 22.1569995880127 325.7909851074219 20.15800094604492 C 325.7969970703125 20.14299964904785 325.8030090332031 20.12800025939941 325.8070068359375 20.11199951171875 M 320.9129943847656 22.84600067138672 C 320.7160034179688 22.84600067138672 320.3980102539062 22.48900032043457 320.1319885253906 21.69099998474121 C 320.0029907226562 21.30599975585938 319.9010009765625 20.86300086975098 319.8259887695312 20.38199996948242 L 322.0010070800781 20.38199996948242 C 321.9259948730469 20.86300086975098 321.822998046875 21.30599975585938 321.6950073242188 21.69099998474121 C 321.4289855957031 22.48900032043457 321.1099853515625 22.84600067138672 320.9129943847656 22.84600067138672 M 319.7349853515625 19.63899993896484 C 319.7000122070312 19.24300003051758 319.6809997558594 18.82900047302246 319.6809997558594 18.4060001373291 C 319.6809997558594 17.98299980163574 319.7000122070312 17.56999969482422 319.7349853515625 17.17399978637695 L 322.0910034179688 17.17399978637695 C 322.1260070800781 17.56999969482422 322.1449890136719 17.98299980163574 322.1449890136719 18.4060001373291 C 322.1449890136719 18.82900047302246 322.1260070800781 19.24300003051758 322.0910034179688 19.63899993896484 L 319.7349853515625 19.63899993896484 Z M 316.4739990234375 18.4060001373291 C 316.4739990234375 17.97900009155273 316.5339965820312 17.56599998474121 316.6480102539062 17.17399978637695 L 318.989990234375 17.17399978637695 C 318.9559936523438 17.57900047302246 318.93798828125 17.99300003051758 318.93798828125 18.4060001373291 C 318.93798828125 18.81999969482422 318.9559936523438 19.23399925231934 318.989990234375 19.63899993896484 L 316.6480102539062 19.63899993896484 C 316.5339965820312 19.24699974060059 316.4739990234375 18.83399963378906 316.4739990234375 18.4060001373291 M 320.9129943847656 13.96700000762939 C 321.1099853515625 13.96700000762939 321.4289855957031 14.32400035858154 321.6950073242188 15.12199974060059 C 321.822998046875 15.50699996948242 321.9259948730469 15.94999980926514 322.0010070800781 16.43099975585938 L 319.8259887695312 16.43099975585938 C 319.8999938964844 15.94999980926514 320.0029907226562 15.50699996948242 320.1319885253906 15.12199974060059 C 320.3980102539062 14.32400035858154 320.7160034179688 13.96700000762939 320.9129943847656 13.96700000762939 M 322.8359985351562 17.17399978637695 L 325.1789855957031 17.17399978637695 C 325.2919921875 17.56599998474121 325.3529968261719 17.97900009155273 325.3529968261719 18.4060001373291 C 325.3529968261719 18.83399963378906 325.2919921875 19.24799919128418 325.1789855957031 19.63899993896484 L 322.8359985351562 19.63899993896484 C 322.8710021972656 19.23399925231934 322.8880004882812 18.81999969482422 322.8880004882812 18.4060001373291 C 322.8880004882812 17.99300003051758 322.8710021972656 17.57900047302246 322.8359985351562 17.17399978637695 M 324.8880004882812 16.43099975585938 L 322.7510070800781 16.43099975585938 C 322.6189880371094 15.52000045776367 322.3919982910156 14.70300006866455 322.0740051269531 14.12100028991699 C 323.3070068359375 14.45499992370605 324.3280029296875 15.30900001525879 324.8880004882812 16.43099975585938 M 319.7520141601562 14.12100028991699 C 319.4339904785156 14.70300006866455 319.2080078125 15.52000045776367 319.0750122070312 16.43099975585938 L 316.93798828125 16.43099975585938 C 317.4979858398438 15.30900001525879 318.5190124511719 14.45499992370605 319.7520141601562 14.12100028991699 M 316.93798828125 20.38199996948242 L 319.0750122070312 20.38199996948242 C 319.2080078125 21.29299926757812 319.4339904785156 22.11000061035156 319.7520141601562 22.6919994354248 C 318.5190124511719 22.35700035095215 317.4979858398438 21.50399971008301 316.93798828125 20.38199996948242 M 322.0740051269531 22.6919994354248 C 322.3919982910156 22.11000061035156 322.6189880371094 21.29299926757812 322.7510070800781 20.38199996948242 L 324.8880004882812 20.38199996948242 C 324.3280029296875 21.50399971008301 323.3070068359375 22.35700035095215 322.0740051269531 22.6919994354248" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_vfabnz =
    '<svg viewBox="306.4 25.2 58.6 17.0" ><path  d="M 306.43701171875 42.24800109863281 L 365.0660095214844 42.24800109863281 L 365.0660095214844 25.24900054931641 L 306.43701171875 25.24900054931641 L 306.43701171875 42.24800109863281 Z M 318.4599914550781 40.3120002746582 L 314.4679870605469 30.77099990844727 L 310.43701171875 40.3120002746582 L 309.0710144042969 40.3120002746582 L 314.4679870605469 27.74300003051758 L 319.8250122070312 40.3120002746582 L 318.4599914550781 40.3120002746582 Z M 327.3099975585938 34.70600128173828 L 320.635986328125 34.70600128173828 L 320.635986328125 33.63800048828125 L 327.3099975585938 33.63800048828125 L 327.3099975585938 34.70600128173828 Z M 328.0169982910156 29.37299919128418 L 320.6199951171875 29.37299919128418 L 320.6279907226562 28.30500030517578 L 328.0169982910156 28.30500030517578 L 328.0169982910156 29.37299919128418 Z M 335.9119873046875 40.3120002746582 C 335.4299926757812 39.55699920654297 334.9490051269531 38.80099868774414 334.4700012207031 38.04299926757812 C 333.9909973144531 37.2859992980957 333.510986328125 36.52399826049805 333.0289916992188 35.75799942016602 L 333.0289916992188 34.68999862670898 C 333.3930053710938 34.68999862670898 333.6820068359375 34.68299865722656 333.89599609375 34.66999816894531 C 334.1099853515625 34.65700149536133 334.3429870605469 34.61199951171875 334.5950012207031 34.5369987487793 C 334.8039855957031 34.47299957275391 334.9949951171875 34.36100006103516 335.1690063476562 34.20000076293945 C 335.3429870605469 34.03900146484375 335.4930114746094 33.84799957275391 335.6189880371094 33.62599945068359 C 335.7449951171875 33.40399932861328 335.843994140625 33.15200042724609 335.9159851074219 32.87099838256836 C 335.9880065917969 32.59000015258789 336.0239868164062 32.30199813842773 336.0239868164062 32.00799942016602 C 336.0239868164062 31.44499969482422 335.9169921875 30.97299957275391 335.7030029296875 30.59000015258789 C 335.489013671875 30.20700073242188 335.1969909667969 29.9109992980957 334.8280029296875 29.70299911499023 C 334.6080017089844 29.58499908447266 334.3630065917969 29.50099945068359 334.0929870605469 29.45000076293945 C 333.8219909667969 29.39900016784668 333.5350036621094 29.37299919128418 333.22900390625 29.37299919128418 L 330.2019958496094 29.37299919128418 L 330.2019958496094 40.3120002746582 L 328.9490051269531 40.3120002746582 L 328.9490051269531 28.30500030517578 L 333.22900390625 28.30500030517578 C 333.614990234375 28.30500030517578 333.9880065917969 28.33499908447266 334.3500061035156 28.39399909973145 C 334.7109985351562 28.45199966430664 335.0450134277344 28.55999946594238 335.3500061035156 28.71500015258789 C 335.9230041503906 28.99900054931641 336.3869934082031 29.42300033569336 336.7430114746094 29.98800086975098 C 337.0989990234375 30.55299949645996 337.2770080566406 31.21500015258789 337.2770080566406 31.97500038146973 C 337.2770080566406 32.52199935913086 337.1919860839844 33.01699829101562 337.0199890136719 33.46099853515625 C 336.8489990234375 33.90599822998047 336.6289978027344 34.2869987487793 336.3619995117188 34.60599899291992 C 336.093994140625 34.92399978637695 335.7900085449219 35.17300033569336 335.4500122070312 35.35300064086914 C 335.1099853515625 35.53200149536133 334.7690124511719 35.63800048828125 334.4259948730469 35.66999816894531 C 334.9349975585938 36.45199966430664 335.4349975585938 37.22700119018555 335.9280090332031 37.99499893188477 C 336.4209899902344 38.76300048828125 336.9129943847656 39.5359992980957 337.406005859375 40.3120002746582 L 335.9119873046875 40.3120002746582 Z M 339.6059875488281 40.3120002746582 L 338.3529968261719 40.3120002746582 L 338.3529968261719 28.30500030517578 L 339.6059875488281 28.30500030517578 L 339.6059875488281 40.3120002746582 Z M 342.4249877929688 36.28400039672852 C 342.6709899902344 36.89699935913086 343.0140075683594 37.4370002746582 343.4530029296875 37.90299987792969 C 343.8919982910156 38.36800003051758 344.4159851074219 38.73799896240234 345.0230102539062 39.01100158691406 C 345.6310119628906 39.28400039672852 346.2959899902344 39.41999816894531 347.0190124511719 39.41999816894531 C 347.7690124511719 39.41999816894531 348.4339904785156 39.28400039672852 349.0150146484375 39.01100158691406 C 349.5960083007812 38.73799896240234 350.1170043945312 38.40299987792969 350.5769958496094 38.00699996948242 L 351.2839965820312 38.84999847412109 C 350.7109985351562 39.375 350.0679931640625 39.78099822998047 349.3559875488281 40.06700134277344 C 348.6440124511719 40.35300064086914 347.864990234375 40.49700164794922 347.0190124511719 40.49700164794922 C 346.1199951171875 40.49700164794922 345.2900085449219 40.33499908447266 344.5289916992188 40.01100158691406 C 343.7690124511719 39.6870002746582 343.114990234375 39.24499893188477 342.5660095214844 38.68600082397461 C 342.0169982910156 38.12599945068359 341.5859985351562 37.47000122070312 341.2730102539062 36.71799850463867 C 340.9599914550781 35.96599960327148 340.8030090332031 35.16899871826172 340.8030090332031 34.32899856567383 C 340.8030090332031 33.48300170898438 340.9620056152344 32.68399810791016 341.281005859375 31.93099975585938 C 341.5989990234375 31.17900085449219 342.0390014648438 30.52300071716309 342.5979919433594 29.9640007019043 C 343.1570129394531 29.40399932861328 343.8150024414062 28.95999908447266 344.5700073242188 28.6299991607666 C 345.3250122070312 28.30100059509277 346.1409912109375 28.13599967956543 347.0190124511719 28.13599967956543 C 347.8869934082031 28.13599967956543 348.6820068359375 28.29000091552734 349.4049987792969 28.59799957275391 C 350.1279907226562 28.9060001373291 350.7699890136719 29.32200050354004 351.3320007324219 29.84700012207031 L 350.5769958496094 30.70700073242188 C 350.1170043945312 30.28899955749512 349.5920104980469 29.93600082397461 349.0029907226562 29.64599990844727 C 348.4140014648438 29.35700035095215 347.7470092773438 29.21299934387207 347.0029907226562 29.21299934387207 C 346.2699890136719 29.21299934387207 345.5989990234375 29.35199928283691 344.9909973144531 29.6299991607666 C 344.3840026855469 29.90900039672852 343.8630065917969 30.2810001373291 343.4289855957031 30.74699974060059 C 342.9949951171875 31.21199989318848 342.6579895019531 31.75600051879883 342.4169921875 32.37699890136719 C 342.1759948730469 32.99800109863281 342.0559997558594 33.64899826049805 342.0559997558594 34.32899856567383 C 342.0559997558594 35.01900100708008 342.1789855957031 35.67100143432617 342.4249877929688 36.28400039672852 M 361.0660095214844 40.3120002746582 L 357.0740051269531 30.77099990844727 L 353.0429992675781 40.3120002746582 L 351.677001953125 40.3120002746582 L 357.0740051269531 27.74300003051758 L 362.4309997558594 40.3120002746582 L 361.0660095214844 40.3120002746582 Z" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_bm84g =
    '<svg viewBox="362.3 10.9 1.1 1.3" ><path  d="M 362.6864929199219 12.26509857177734 L 362.6864929199219 11.15810394287109 L 362.2914733886719 11.15810394287109 L 362.2914733886719 10.93310546875 L 363.3494873046875 10.93310546875 L 363.3494873046875 11.15810394287109 L 362.9554748535156 11.15810394287109 L 362.9554748535156 12.26509857177734 L 362.6864929199219 12.26509857177734 Z" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_p7f1fk =
    '<svg viewBox="363.5 10.9 1.3 1.3" ><path  d="M 363.5198059082031 12.26509857177734 L 363.5198059082031 10.93310546875 L 363.9227905273438 10.93310546875 L 364.1637878417969 11.84110260009766 L 364.4028015136719 10.93310546875 L 364.8067932128906 10.93310546875 L 364.8067932128906 12.26509857177734 L 364.5567932128906 12.26509857177734 L 364.5567932128906 11.21610260009766 L 364.2917785644531 12.26509857177734 L 364.0327758789062 12.26509857177734 L 363.7698059082031 11.21610260009766 L 363.7698059082031 12.26509857177734 L 363.5198059082031 12.26509857177734 Z" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_u3y459 =
    '<svg viewBox="306.5 44.3 2.9 4.5" ><path  d="M 307.0069885253906 48.34700012207031 C 307.0700073242188 48.32799911499023 307.1159973144531 48.31399917602539 307.1470031738281 48.30500030517578 C 307.6839904785156 48.13999938964844 308.0690002441406 48.05699920654297 308.302001953125 48.05699920654297 C 308.4769897460938 48.05699920654297 308.5639953613281 48.12200164794922 308.5639953613281 48.25299835205078 C 308.5639953613281 48.30400085449219 308.5440063476562 48.3489990234375 308.5050048828125 48.38899993896484 C 308.4649963378906 48.42800140380859 308.4209899902344 48.44800186157227 308.3720092773438 48.44800186157227 C 308.3489990234375 48.44800186157227 308.3150024414062 48.44499969482422 308.27099609375 48.4379997253418 C 308.2340087890625 48.43099975585938 308.2030029296875 48.42699813842773 308.1799926757812 48.42699813842773 C 308.0429992675781 48.42699813842773 307.8619995117188 48.45899963378906 307.6390075683594 48.52199935913086 C 307.5570068359375 48.54700088500977 307.3999938964844 48.61199951171875 307.1679992675781 48.71699905395508 C 307.0119934082031 48.7869987487793 306.8840026855469 48.82199859619141 306.7839965820312 48.82199859619141 C 306.7109985351562 48.82199859619141 306.6520080566406 48.78799819946289 306.6059875488281 48.72000122070312 C 306.5610046386719 48.65800094604492 306.5390014648438 48.59099960327148 306.5390014648438 48.52199935913086 C 306.5390014648438 48.43500137329102 306.5870056152344 48.29000091552734 306.6820068359375 48.08499908447266 C 306.9729919433594 47.45199966430664 307.2850036621094 46.88399887084961 307.6180114746094 46.38100051879883 C 308.0950012207031 45.65999984741211 308.4649963378906 45.13000106811523 308.7279968261719 44.79299926757812 C 308.7999877929688 44.70199966430664 308.8720092773438 44.61000061035156 308.9450073242188 44.51699829101562 C 309.0589904785156 44.36399841308594 309.1570129394531 44.2869987487793 309.2409973144531 44.2869987487793 C 309.2829895019531 44.2869987487793 309.3200073242188 44.30300140380859 309.3529968261719 44.33599853515625 C 309.3829956054688 44.36800003051758 309.3980102539062 44.40200042724609 309.3980102539062 44.4370002746582 C 309.3980102539062 44.48799896240234 309.3590087890625 44.56700134277344 309.2799987792969 44.67399978637695 C 309.2630004882812 44.69499969482422 309.1669921875 44.82199859619141 308.989990234375 45.05500030517578 C 308.6589965820312 45.4900016784668 308.4129943847656 45.82300186157227 308.2510070800781 46.05300140380859 C 308.0899963378906 46.28400039672852 307.9169921875 46.54999923706055 307.7330017089844 46.85300064086914 C 307.3720092773438 47.44599914550781 307.1300048828125 47.94400024414062 307.0069885253906 48.34700012207031" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_a1ht58 =
    '<svg viewBox="308.9 46.5 2.0 2.1" ><path  d="M 309.2659912109375 47.97000122070312 L 309.2659912109375 48.03300094604492 C 309.2659912109375 48.08399963378906 309.2789916992188 48.12900161743164 309.3049926757812 48.16600036621094 C 309.3630065917969 48.25199890136719 309.4580078125 48.29499816894531 309.5910034179688 48.29499816894531 C 309.8819885253906 48.29499816894531 310.2179870605469 48.07099914550781 310.6000061035156 47.625 C 310.6669921875 47.54800033569336 310.7239990234375 47.50899887084961 310.77099609375 47.50899887084961 C 310.7959899902344 47.50899887084961 310.8200073242188 47.52199935913086 310.8410034179688 47.54800033569336 C 310.8550109863281 47.56600189208984 310.8619995117188 47.58399963378906 310.8619995117188 47.59999847412109 C 310.8619995117188 47.69100189208984 310.75 47.84500122070312 310.5260009765625 48.06100082397461 C 310.3519897460938 48.23099899291992 310.1659851074219 48.36899948120117 309.9679870605469 48.47600173950195 C 309.7699890136719 48.58300018310547 309.5859985351562 48.63700103759766 309.4159851074219 48.63700103759766 C 309.2420043945312 48.63700103759766 309.10400390625 48.57600021362305 309.0039978027344 48.45500183105469 C 308.93701171875 48.37200164794922 308.9030151367188 48.25799942016602 308.9030151367188 48.11299896240234 C 308.9030151367188 47.72000122070312 309.0880126953125 47.33499908447266 309.4580078125 46.95800018310547 C 309.7579956054688 46.6510009765625 310.0199890136719 46.49700164794922 310.2439880371094 46.49700164794922 C 310.3039855957031 46.49700164794922 310.3590087890625 46.51599884033203 310.4079895019531 46.55300140380859 C 310.4679870605469 46.60200119018555 310.4989929199219 46.66600036621094 310.4989929199219 46.74499893188477 C 310.4989929199219 46.86800003051758 310.4419860839844 47.01900100708008 310.3269958496094 47.19900131225586 C 310.0920104980469 47.57099914550781 309.739013671875 47.82799911499023 309.2659912109375 47.97000122070312 M 309.3429870605469 47.69800186157227 C 309.5060119628906 47.64199829101562 309.6340026855469 47.57899856567383 309.7269897460938 47.50899887084961 C 309.8900146484375 47.38399887084961 310.0190124511719 47.24200057983398 310.114990234375 47.08300018310547 C 310.1489868164062 47.02799987792969 310.1669921875 46.97800064086914 310.1669921875 46.93299865722656 C 310.1669921875 46.88700103759766 310.1449890136719 46.86299896240234 310.1010131835938 46.86299896240234 C 310.0400085449219 46.86299896240234 309.9540100097656 46.90900039672852 309.8420104980469 47 C 309.6419982910156 47.15999984741211 309.4760131835938 47.39300155639648 309.3429870605469 47.69800186157227" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_d591t =
    '<svg viewBox="311.4 45.2 2.1 3.5" ><path  d="M 312.4129943847656 46.39199829101562 C 312.2619934082031 46.62699890136719 312.1220092773438 46.88999938964844 311.9939880371094 47.18099975585938 C 311.8099975585938 47.59500122070312 311.7179870605469 47.90499877929688 311.7179870605469 48.11000061035156 C 311.7179870605469 48.16799926757812 311.7300109863281 48.21200180053711 311.7550048828125 48.24200057983398 C 311.7789916992188 48.27299880981445 311.8160095214844 48.28799819946289 311.864990234375 48.28799819946289 C 311.9809875488281 48.28799819946289 312.1220092773438 48.17800140380859 312.2869873046875 47.95899963378906 C 312.3919982910156 47.82500076293945 312.4849853515625 47.68999862670898 312.5669860839844 47.55500030517578 C 312.6109924316406 47.47800064086914 312.6589965820312 47.43899917602539 312.7099914550781 47.43899917602539 C 312.739990234375 47.43899917602539 312.7659912109375 47.45000076293945 312.7869873046875 47.47100067138672 C 312.8049926757812 47.49200057983398 312.8139953613281 47.51300048828125 312.8139953613281 47.53400039672852 C 312.8139953613281 47.61999893188477 312.7019958496094 47.8120002746582 312.4760131835938 48.11000061035156 C 312.2059936523438 48.46799850463867 311.9590148925781 48.64699935913086 311.7359924316406 48.64699935913086 C 311.6170043945312 48.64699935913086 311.5180053710938 48.59299850463867 311.4389953613281 48.48300170898438 C 311.3900146484375 48.41299819946289 311.3659973144531 48.31499862670898 311.3659973144531 48.1870002746582 C 311.3659973144531 47.90499877929688 311.4469909667969 47.57699966430664 311.6099853515625 47.20199966430664 C 311.6499938964844 47.10900115966797 311.7590026855469 46.88399887084961 311.93798828125 46.52799987792969 C 311.875 46.54399871826172 311.8280029296875 46.55300140380859 311.7950134277344 46.55300140380859 C 311.7460021972656 46.55300140380859 311.7030029296875 46.54100036621094 311.6659851074219 46.51800155639648 C 311.614990234375 46.48500061035156 311.5889892578125 46.44400024414062 311.5889892578125 46.39500045776367 C 311.5889892578125 46.33700180053711 311.6229858398438 46.29100036621094 311.6900024414062 46.25600051879883 C 311.7090148925781 46.24700164794922 311.7950134277344 46.23099899291992 311.9490051269531 46.20999908447266 C 312.0050048828125 46.20100021362305 312.0859985351562 46.17900085449219 312.1929931640625 46.14400100708008 C 312.2749938964844 45.99800109863281 312.4070129394531 45.79899978637695 312.5910034179688 45.54700088500977 C 312.6929931640625 45.40800094604492 312.7640075683594 45.31700134277344 312.8039855957031 45.27500152587891 C 312.8599853515625 45.21699905395508 312.9089965820312 45.1879997253418 312.9509887695312 45.1879997253418 C 312.9809875488281 45.1879997253418 313.010986328125 45.20399856567383 313.0409851074219 45.23600006103516 C 313.0690002441406 45.26699829101562 313.0830078125 45.29700088500977 313.0830078125 45.32699966430664 C 313.0830078125 45.38800048828125 313.0180053710938 45.50799942016602 312.8880004882812 45.6870002746582 C 312.802001953125 45.80300140380859 312.7380065917969 45.89699935913086 312.6960144042969 45.97000122070312 C 312.9540100097656 45.90000152587891 313.1390075683594 45.8650016784668 313.2510070800781 45.8650016784668 C 313.3789978027344 45.8650016784668 313.4429931640625 45.91799926757812 313.4429931640625 46.02500152587891 C 313.4429931640625 46.07899856567383 313.4209899902344 46.11899948120117 313.3770141601562 46.14400100708008 C 313.3529968261719 46.15800094604492 313.2929992675781 46.16999816894531 313.1950073242188 46.17900085449219 C 313.1549987792969 46.17699813842773 312.9800109863281 46.22100067138672 312.6679992675781 46.3120002746582 C 312.5820007324219 46.33700180053711 312.4970092773438 46.36399841308594 312.4129943847656 46.39199829101562" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_ky4qhp =
    '<svg viewBox="314.6 44.0 1.0 1.5" ><path  d="M 315.5169982910156 44.02899932861328 C 315.6260070800781 44.02899932861328 315.6809997558594 44.09799957275391 315.6809997558594 44.23500061035156 C 315.6809997558594 44.44699859619141 315.5639953613281 44.7239990234375 315.3280029296875 45.06600189208984 C 315.2330017089844 45.20500183105469 315.1199951171875 45.33300018310547 314.989990234375 45.45000076293945 C 314.906005859375 45.52700042724609 314.8389892578125 45.56499862670898 314.7869873046875 45.56499862670898 C 314.7380065917969 45.56499862670898 314.6990051269531 45.54299926757812 314.6690063476562 45.49900054931641 C 314.6480102539062 45.47100067138672 314.6369934082031 45.4379997253418 314.6369934082031 45.4010009765625 C 314.6369934082031 45.34999847412109 314.68701171875 45.27899932861328 314.7869873046875 45.1879997253418 C 315.0710144042969 44.91600036621094 315.2380065917969 44.59700012207031 315.2869873046875 44.23099899291992 C 315.2980041503906 44.16400146484375 315.3299865722656 44.11199951171875 315.3810119628906 44.07400131225586 C 315.427001953125 44.04399871826172 315.4729919433594 44.02899932861328 315.5169982910156 44.02899932861328" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_j7ood5 =
    '<svg viewBox="314.6 46.3 2.1 2.5" ><path  d="M 316.3169860839844 46.32199859619141 C 316.4609985351562 46.32199859619141 316.5700073242188 46.34799957275391 316.6419982910156 46.39899826049805 C 316.7139892578125 46.45000076293945 316.75 46.52799987792969 316.75 46.63299942016602 C 316.75 46.77000045776367 316.6990051269531 46.90299987792969 316.5960083007812 47.03099822998047 C 316.4989929199219 47.15200042724609 316.3519897460938 47.24900054931641 316.156005859375 47.32400131225586 C 316.0490112304688 47.36399841308594 315.9599914550781 47.38299942016602 315.8880004882812 47.38299942016602 C 315.7900085449219 47.38299942016602 315.7409973144531 47.34000015258789 315.7409973144531 47.25400161743164 C 315.7409973144531 47.19599914550781 315.7690124511719 47.15200042724609 315.8250122070312 47.12099838256836 C 315.8389892578125 47.11399841308594 315.9179992675781 47.09500122070312 316.06201171875 47.0620002746582 C 316.1480102539062 47.04299926757812 316.2269897460938 47.00299835205078 316.2999877929688 46.93999862670898 C 316.3619995117188 46.88600158691406 316.3940124511719 46.82799911499023 316.3940124511719 46.76499938964844 C 316.3940124511719 46.71699905395508 316.3800048828125 46.68000030517578 316.3519897460938 46.65700149536133 C 316.3240051269531 46.63399887084961 316.2820129394531 46.62200164794922 316.2260131835938 46.62200164794922 C 316.0910034179688 46.62200164794922 315.9419860839844 46.67699813842773 315.7789916992188 46.7859992980957 C 315.5910034179688 46.90999984741211 315.4970092773438 47.05599975585938 315.4970092773438 47.22600173950195 C 315.4970092773438 47.34700012207031 315.5580139160156 47.49800109863281 315.6820068359375 47.68000030517578 C 315.8190002441406 47.87799835205078 315.8880004882812 48.04499816894531 315.8880004882812 48.18299865722656 C 315.8880004882812 48.38800048828125 315.7969970703125 48.54800033569336 315.614990234375 48.66500091552734 C 315.5039978027344 48.73699951171875 315.3770141601562 48.77299880981445 315.2349853515625 48.77299880981445 C 315.010986328125 48.77299880981445 314.8410034179688 48.69200134277344 314.7250061035156 48.53200149536133 C 314.6440124511719 48.41799926757812 314.6029968261719 48.28300094604492 314.6029968261719 48.12699890136719 C 314.6029968261719 47.94499969482422 314.6489868164062 47.79299926757812 314.7430114746094 47.66999816894531 C 314.8030090332031 47.5880012512207 314.8659973144531 47.54700088500977 314.9309997558594 47.54700088500977 C 314.989013671875 47.54700088500977 315.0180053710938 47.57099914550781 315.0180053710938 47.61700057983398 C 315.0180053710938 47.63600158691406 315.0079956054688 47.66400146484375 314.9869995117188 47.70100021362305 C 314.9330139160156 47.80099868774414 314.9070129394531 47.91899871826172 314.9070129394531 48.05400085449219 C 314.9070129394531 48.16799926757812 314.9469909667969 48.26399993896484 315.0289916992188 48.34299850463867 C 315.1010131835938 48.41299819946289 315.1839904785156 48.44800186157227 315.2770080566406 48.44800186157227 C 315.3670043945312 48.44800186157227 315.43798828125 48.41799926757812 315.489990234375 48.35699844360352 C 315.5320129394531 48.30599975585938 315.552001953125 48.24100112915039 315.552001953125 48.1619987487793 C 315.552001953125 48.06399917602539 315.4970092773438 47.9370002746582 315.385009765625 47.78099822998047 C 315.2309875488281 47.56700134277344 315.1539916992188 47.37300109863281 315.1539916992188 47.19800186157227 C 315.1539916992188 46.96599960327148 315.281005859375 46.7599983215332 315.5350036621094 46.58000183105469 C 315.7820129394531 46.40800094604492 316.0419921875 46.32199859619141 316.3169860839844 46.32199859619141" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_d71ha =
    '<svg viewBox="318.9 45.2 2.1 3.5" ><path  d="M 319.9559936523438 46.39199829101562 C 319.8049926757812 46.62699890136719 319.6650085449219 46.88999938964844 319.5369873046875 47.18099975585938 C 319.3529968261719 47.59500122070312 319.260986328125 47.90499877929688 319.260986328125 48.11000061035156 C 319.260986328125 48.16799926757812 319.2730102539062 48.21200180053711 319.2980041503906 48.24200057983398 C 319.3219909667969 48.27299880981445 319.3590087890625 48.28799819946289 319.4079895019531 48.28799819946289 C 319.5239868164062 48.28799819946289 319.6650085449219 48.17800140380859 319.8299865722656 47.95899963378906 C 319.9349975585938 47.82500076293945 320.0280151367188 47.68999862670898 320.1099853515625 47.55500030517578 C 320.1539916992188 47.47800064086914 320.2019958496094 47.43899917602539 320.2529907226562 47.43899917602539 C 320.2829895019531 47.43899917602539 320.3089904785156 47.45000076293945 320.3299865722656 47.47100067138672 C 320.3479919433594 47.49200057983398 320.3569946289062 47.51300048828125 320.3569946289062 47.53400039672852 C 320.3569946289062 47.61999893188477 320.2449951171875 47.8120002746582 320.0190124511719 48.11000061035156 C 319.7489929199219 48.46799850463867 319.5020141601562 48.64699935913086 319.2789916992188 48.64699935913086 C 319.1600036621094 48.64699935913086 319.0610046386719 48.59299850463867 318.9819946289062 48.48300170898438 C 318.9330139160156 48.41299819946289 318.9089965820312 48.31499862670898 318.9089965820312 48.1870002746582 C 318.9089965820312 47.90499877929688 318.989990234375 47.57699966430664 319.1530151367188 47.20199966430664 C 319.1929931640625 47.10900115966797 319.302001953125 46.88399887084961 319.4809875488281 46.52799987792969 C 319.4179992675781 46.54399871826172 319.3710021972656 46.55300140380859 319.3380126953125 46.55300140380859 C 319.2890014648438 46.55300140380859 319.2460021972656 46.54100036621094 319.2090148925781 46.51800155639648 C 319.1579895019531 46.48500061035156 319.1319885253906 46.44400024414062 319.1319885253906 46.39500045776367 C 319.1319885253906 46.33700180053711 319.1659851074219 46.29100036621094 319.2330017089844 46.25600051879883 C 319.2520141601562 46.24700164794922 319.3380126953125 46.23099899291992 319.4920043945312 46.20999908447266 C 319.5480041503906 46.20100021362305 319.6289978027344 46.17900085449219 319.7359924316406 46.14400100708008 C 319.8179931640625 45.99800109863281 319.9500122070312 45.79899978637695 320.1340026855469 45.54700088500977 C 320.2359924316406 45.40800094604492 320.3070068359375 45.31700134277344 320.3469848632812 45.27500152587891 C 320.4030151367188 45.21699905395508 320.4519958496094 45.1879997253418 320.4939880371094 45.1879997253418 C 320.5239868164062 45.1879997253418 320.5539855957031 45.20399856567383 320.5840148925781 45.23600006103516 C 320.6119995117188 45.26699829101562 320.6260070800781 45.29700088500977 320.6260070800781 45.32699966430664 C 320.6260070800781 45.38800048828125 320.5610046386719 45.50799942016602 320.4309997558594 45.6870002746582 C 320.3450012207031 45.80300140380859 320.281005859375 45.89699935913086 320.239013671875 45.97000122070312 C 320.4970092773438 45.90000152587891 320.6820068359375 45.8650016784668 320.7940063476562 45.8650016784668 C 320.9219970703125 45.8650016784668 320.9859924316406 45.91799926757812 320.9859924316406 46.02500152587891 C 320.9859924316406 46.07899856567383 320.9639892578125 46.11899948120117 320.9200134277344 46.14400100708008 C 320.89599609375 46.15800094604492 320.8359985351562 46.16999816894531 320.7380065917969 46.17900085449219 C 320.697998046875 46.17699813842773 320.5230102539062 46.22100067138672 320.2109985351562 46.3120002746582 C 320.125 46.33700180053711 320.0400085449219 46.36399841308594 319.9559936523438 46.39199829101562" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_rrykk =
    '<svg viewBox="320.6 46.4 1.7 2.4" ><path  d="M 321.6300048828125 48.06499862670898 C 321.5530090332031 48.20000076293945 321.4769897460938 48.31399917602539 321.4030151367188 48.40700149536133 C 321.2560119628906 48.5880012512207 321.1109924316406 48.67900085449219 320.9660034179688 48.67900085449219 C 320.8410034179688 48.67900085449219 320.7430114746094 48.61999893188477 320.6730041503906 48.50099945068359 C 320.6289978027344 48.42399978637695 320.6069946289062 48.33399963378906 320.6069946289062 48.22900009155273 C 320.6069946289062 47.97000122070312 320.68798828125 47.68500137329102 320.8510131835938 47.37300109863281 C 321.0329895019531 47.02700042724609 321.2510070800781 46.7599983215332 321.5069885253906 46.57400131225586 C 321.6749877929688 46.45299911499023 321.8370056152344 46.39199829101562 321.9930114746094 46.39199829101562 C 322.0899963378906 46.39199829101562 322.1719970703125 46.42300033569336 322.2369995117188 46.48300170898438 C 322.2929992675781 46.5369987487793 322.3210144042969 46.59700012207031 322.3210144042969 46.66500091552734 C 322.3210144042969 46.71599960327148 322.3009948730469 46.7869987487793 322.2619934082031 46.87799835205078 C 322.2959899902344 46.92599868774414 322.3139953613281 46.97000122070312 322.3139953613281 47.00699996948242 C 322.3139953613281 47.05599975585938 322.281005859375 47.13600158691406 322.2160034179688 47.24800109863281 C 322.1489868164062 47.36199951171875 322.0809936523438 47.51300048828125 322.0140075683594 47.70100021362305 C 321.9410095214844 47.90200042724609 321.9049987792969 48.0620002746582 321.9049987792969 48.18299865722656 C 321.9049987792969 48.28099822998047 321.9339904785156 48.36100006103516 321.9930114746094 48.42399978637695 C 322.0090026855469 48.44100189208984 322.0570068359375 48.46699905395508 322.135986328125 48.50400161743164 C 322.1940002441406 48.53200149536133 322.2229919433594 48.58100128173828 322.2229919433594 48.6510009765625 C 322.2229919433594 48.69499969482422 322.2070007324219 48.73099899291992 322.1740112304688 48.75899887084961 C 322.1390075683594 48.79000091552734 322.0989990234375 48.80500030517578 322.052001953125 48.80500030517578 C 321.9259948730469 48.80500030517578 321.8179931640625 48.74900054931641 321.7269897460938 48.63700103759766 C 321.6530151367188 48.54600143432617 321.6159973144531 48.43199920654297 321.6159973144531 48.29499816894531 C 321.6159973144531 48.24800109863281 321.6199951171875 48.17200088500977 321.6300048828125 48.06499862670898 M 322.0660095214844 46.91600036621094 C 322.0379943847656 46.8650016784668 322.0079956054688 46.82699966430664 321.9750061035156 46.80199813842773 C 321.9429931640625 46.77799987792969 321.9079895019531 46.76599884033203 321.8710021972656 46.76599884033203 C 321.6940002441406 46.76599884033203 321.5020141601562 46.92100143432617 321.2940063476562 47.22999954223633 C 321.0660095214844 47.57199859619141 320.9519958496094 47.86199951171875 320.9519958496094 48.0989990234375 C 320.9519958496094 48.15800094604492 320.9630126953125 48.20199966430664 320.9849853515625 48.23199844360352 C 321.0079956054688 48.26200103759766 321.0409851074219 48.27799987792969 321.0849914550781 48.27799987792969 C 321.1969909667969 48.27799987792969 321.3269958496094 48.15900039672852 321.4760131835938 47.92200088500977 C 321.5599975585938 47.79100036621094 321.6629943847656 47.5989990234375 321.7869873046875 47.34500122070312 C 321.8680114746094 47.18000030517578 321.9280090332031 47.07099914550781 321.9649963378906 47.01699829101562 C 321.9830017089844 46.98899841308594 322.0169982910156 46.95600128173828 322.0660095214844 46.91600036621094" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_oyk0xb =
    '<svg viewBox="322.6 44.2 2.8 4.4" ><path  d="M 323.2040100097656 47.48099899291992 C 323.1340026855469 47.66299819946289 323.0820007324219 47.80899810791016 323.0469970703125 47.92100143432617 C 323.0119934082031 48.03300094604492 322.9949951171875 48.11100006103516 322.9949951171875 48.15499877929688 C 322.9949951171875 48.2130012512207 323.0230102539062 48.24200057983398 323.0780029296875 48.24200057983398 C 323.1619873046875 48.24200057983398 323.2699890136719 48.16299819946289 323.4030151367188 48.00500106811523 C 323.4660034179688 47.92800140380859 323.5589904785156 47.78900146484375 323.6820068359375 47.5890007019043 C 323.7309875488281 47.5099983215332 323.7820129394531 47.47100067138672 323.8359985351562 47.47100067138672 C 323.8970031738281 47.47100067138672 323.927001953125 47.5 323.927001953125 47.55799865722656 C 323.927001953125 47.65800094604492 323.81201171875 47.86100006103516 323.5809936523438 48.16500091552734 C 323.3410034179688 48.48400115966797 323.1189880371094 48.64400100708008 322.9140014648438 48.64400100708008 C 322.8259887695312 48.64400100708008 322.7539978027344 48.60599899291992 322.697998046875 48.53200149536133 C 322.6579895019531 48.47800064086914 322.6390075683594 48.41299819946289 322.6390075683594 48.33599853515625 C 322.6390075683594 48.20600128173828 322.6780090332031 48.0260009765625 322.7569885253906 47.79499816894531 C 322.8359985351562 47.56499862670898 322.9540100097656 47.28400039672852 323.1099853515625 46.95399856567383 C 323.510009765625 46.11399841308594 323.9190063476562 45.42100143432617 324.3349914550781 44.87699890136719 C 324.6679992675781 44.43899917602539 324.9440002441406 44.22000122070312 325.1629943847656 44.22000122070312 C 325.2319946289062 44.22000122070312 325.2890014648438 44.24700164794922 325.3340148925781 44.30099868774414 C 325.3800048828125 44.35400009155273 325.4039916992188 44.41600036621094 325.4039916992188 44.48600006103516 C 325.4039916992188 44.8120002746582 325.1130065917969 45.35400009155273 324.531005859375 46.11299896240234 C 324.2699890136719 46.45000076293945 323.9580078125 46.78799819946289 323.5950012207031 47.125 C 323.5 47.2140007019043 323.3689880371094 47.33200073242188 323.2040100097656 47.48099899291992 M 323.4519958496094 46.92599868774414 C 323.9360046386719 46.51200103759766 324.3689880371094 45.98799896240234 324.7510070800781 45.35499954223633 C 324.947998046875 45.02700042724609 325.0469970703125 44.80899810791016 325.0469970703125 44.70199966430664 C 325.0469970703125 44.6510009765625 325.0249938964844 44.625 324.9809875488281 44.625 C 324.8529968261719 44.625 324.6199951171875 44.88000106811523 324.2829895019531 45.38999938964844 C 324.0039978027344 45.80899810791016 323.7269897460938 46.32099914550781 323.4519958496094 46.92599868774414" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_gzu01y =
    '<svg viewBox="324.3 44.3 3.1 4.5" ><path  d="M 325.7780151367188 47.14599990844727 C 325.6270141601562 47.52099990844727 325.5509948730469 47.80599975585938 325.5509948730469 48.00199890136719 C 325.5509948730469 48.09700012207031 325.5700073242188 48.17599868774414 325.6069946289062 48.23899841308594 C 325.6539916992188 48.31800079345703 325.7149963378906 48.35800170898438 325.7919921875 48.35800170898438 C 325.9500122070312 48.35800170898438 326.1329956054688 48.25199890136719 326.3399963378906 48.04000091552734 C 326.4779968261719 47.90499877929688 326.5929870605469 47.76800155639648 326.6860046386719 47.62799835205078 C 326.7460021972656 47.53499984741211 326.8030090332031 47.48899841308594 326.8569946289062 47.48899841308594 C 326.9110107421875 47.48899841308594 326.93701171875 47.51499938964844 326.93701171875 47.56900024414062 C 326.93701171875 47.65700149536133 326.8299865722656 47.8390007019043 326.6159973144531 48.11299896240234 C 326.2999877929688 48.52099990844727 325.9920043945312 48.72499847412109 325.6940002441406 48.72499847412109 C 325.5150146484375 48.72499847412109 325.3880004882812 48.63700103759766 325.3139953613281 48.4630012512207 C 325.2579956054688 48.33499908447266 325.2300109863281 48.20000076293945 325.2300109863281 48.05799865722656 C 325.2300109863281 47.93899917602539 325.2579956054688 47.76300048828125 325.3139953613281 47.53099822998047 C 325.1629943847656 47.65599822998047 324.9330139160156 47.9640007019043 324.6260070800781 48.45199966430664 C 324.5450134277344 48.58499908447266 324.4700012207031 48.6510009765625 324.4030151367188 48.6510009765625 C 324.3680114746094 48.6510009765625 324.3380126953125 48.63600158691406 324.31201171875 48.60599899291992 C 324.2860107421875 48.57300186157227 324.2739868164062 48.54100036621094 324.2739868164062 48.50799942016602 C 324.2739868164062 48.41500091552734 324.39599609375 48.10400009155273 324.6400146484375 47.57600021362305 C 325.0710144042969 46.65200042724609 325.5320129394531 45.875 326.0230102539062 45.24399948120117 C 326.2879943847656 44.89899826049805 326.5260009765625 44.64799880981445 326.7380065917969 44.4900016784668 C 326.9289855957031 44.34500122070312 327.0820007324219 44.27299880981445 327.1960144042969 44.27299880981445 C 327.2470092773438 44.27299880981445 327.2919921875 44.29399871826172 327.3320007324219 44.33599853515625 C 327.3829956054688 44.38700103759766 327.4089965820312 44.45000076293945 327.4089965820312 44.52500152587891 C 327.4089965820312 44.72200012207031 327.3049926757812 44.97600173950195 327.0979919433594 45.2859992980957 C 326.8810119628906 45.60499954223633 326.5140075683594 45.9900016784668 325.9949951171875 46.44100189208984 C 325.7040100097656 46.69300079345703 325.4419860839844 46.88999938964844 325.2090148925781 47.03499984741211 C 325.1789855957031 47.09500122070312 325.093994140625 47.27199935913086 324.9540100097656 47.56600189208984 C 325.2449951171875 47.25099945068359 325.4760131835938 47.03499984741211 325.64599609375 46.91600036621094 C 325.7550048828125 46.84199905395508 325.9030151367188 46.76399993896484 326.0889892578125 46.68199920654297 C 326.2149963378906 46.62900161743164 326.3049926757812 46.60200119018555 326.3609924316406 46.60200119018555 C 326.3919982910156 46.60200119018555 326.4179992675781 46.61299896240234 326.4419860839844 46.63700103759766 C 326.4670104980469 46.65800094604492 326.4800109863281 46.68600082397461 326.4800109863281 46.72100067138672 C 326.4800109863281 46.79700088500977 326.4280090332031 46.85100173950195 326.322998046875 46.88100051879883 C 326.14599609375 46.93500137329102 325.9639892578125 47.02299880981445 325.7780151367188 47.14599990844727 M 325.4779968261719 46.54600143432617 C 325.8599853515625 46.29499816894531 326.2160034179688 45.97499847412109 326.5459899902344 45.58599853515625 C 326.7120056152344 45.39300155639648 326.843994140625 45.20700073242188 326.9440002441406 45.02700042724609 C 327.0140075683594 44.90200042724609 327.0490112304688 44.8120002746582 327.0490112304688 44.75899887084961 C 327.0490112304688 44.70500183105469 327.0249938964844 44.67800140380859 326.9760131835938 44.67800140380859 C 326.8450012207031 44.67800140380859 326.6210021972656 44.87799835205078 326.302001953125 45.27899932861328 C 326.0390014648438 45.61199951171875 325.7640075683594 46.03400039672852 325.4779968261719 46.54600143432617" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_nau9ab =
    '<svg viewBox="329.0 46.4 1.7 2.4" ><path  d="M 330.0599975585938 48.06499862670898 C 329.9830017089844 48.20000076293945 329.9070129394531 48.31399917602539 329.8330078125 48.40700149536133 C 329.6860046386719 48.5880012512207 329.5409851074219 48.67900085449219 329.39599609375 48.67900085449219 C 329.27099609375 48.67900085449219 329.1730041503906 48.61999893188477 329.1029968261719 48.50099945068359 C 329.0589904785156 48.42399978637695 329.0369873046875 48.33399963378906 329.0369873046875 48.22900009155273 C 329.0369873046875 47.97000122070312 329.1180114746094 47.68500137329102 329.281005859375 47.37300109863281 C 329.4630126953125 47.02700042724609 329.6809997558594 46.7599983215332 329.93701171875 46.57400131225586 C 330.1050109863281 46.45299911499023 330.2669982910156 46.39199829101562 330.4230041503906 46.39199829101562 C 330.5199890136719 46.39199829101562 330.6019897460938 46.42300033569336 330.6669921875 46.48300170898438 C 330.7229919433594 46.5369987487793 330.7510070800781 46.59700012207031 330.7510070800781 46.66500091552734 C 330.7510070800781 46.71599960327148 330.7309875488281 46.7869987487793 330.6919860839844 46.87799835205078 C 330.7260131835938 46.92599868774414 330.7439880371094 46.97000122070312 330.7439880371094 47.00699996948242 C 330.7439880371094 47.05599975585938 330.7109985351562 47.13600158691406 330.64599609375 47.24800109863281 C 330.5790100097656 47.36199951171875 330.510986328125 47.51300048828125 330.4440002441406 47.70100021362305 C 330.3710021972656 47.90200042724609 330.3349914550781 48.0620002746582 330.3349914550781 48.18299865722656 C 330.3349914550781 48.28099822998047 330.364013671875 48.36100006103516 330.4230041503906 48.42399978637695 C 330.4389953613281 48.44100189208984 330.4869995117188 48.46699905395508 330.5660095214844 48.50400161743164 C 330.6239929199219 48.53200149536133 330.6530151367188 48.58100128173828 330.6530151367188 48.6510009765625 C 330.6530151367188 48.69499969482422 330.6369934082031 48.73099899291992 330.60400390625 48.75899887084961 C 330.5690002441406 48.79000091552734 330.5289916992188 48.80500030517578 330.4819946289062 48.80500030517578 C 330.3559875488281 48.80500030517578 330.2479858398438 48.74900054931641 330.1570129394531 48.63700103759766 C 330.0830078125 48.54600143432617 330.0459899902344 48.43199920654297 330.0459899902344 48.29499816894531 C 330.0459899902344 48.24800109863281 330.0499877929688 48.17200088500977 330.0599975585938 48.06499862670898 M 330.4960021972656 46.91600036621094 C 330.4679870605469 46.8650016784668 330.43798828125 46.82699966430664 330.4049987792969 46.80199813842773 C 330.3729858398438 46.77799987792969 330.3380126953125 46.76599884033203 330.3009948730469 46.76599884033203 C 330.1239929199219 46.76599884033203 329.9320068359375 46.92100143432617 329.7239990234375 47.22999954223633 C 329.4960021972656 47.57199859619141 329.3819885253906 47.86199951171875 329.3819885253906 48.0989990234375 C 329.3819885253906 48.15800094604492 329.3930053710938 48.20199966430664 329.4150085449219 48.23199844360352 C 329.43798828125 48.26200103759766 329.4710083007812 48.27799987792969 329.5150146484375 48.27799987792969 C 329.6270141601562 48.27799987792969 329.7569885253906 48.15900039672852 329.906005859375 47.92200088500977 C 329.989990234375 47.79100036621094 330.0929870605469 47.5989990234375 330.2170104980469 47.34500122070312 C 330.2980041503906 47.18000030517578 330.3580017089844 47.07099914550781 330.3949890136719 47.01699829101562 C 330.4129943847656 46.98899841308594 330.4469909667969 46.95600128173828 330.4960021972656 46.91600036621094" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_sjw2mv =
    '<svg viewBox="330.9 44.5 2.4 4.3" ><path  d="M 332.0639953613281 46.80699920654297 C 332.2619934082031 46.63999938964844 332.4400024414062 46.55599975585938 332.5979919433594 46.55599975585938 C 332.6960144042969 46.55599975585938 332.7760009765625 46.59700012207031 332.8389892578125 46.67800140380859 C 332.8980102539062 46.75 332.927001953125 46.83399963378906 332.927001953125 46.92900085449219 C 332.927001953125 47.11100006103516 332.8670043945312 47.33100128173828 332.7489929199219 47.5890007019043 C 332.6159973144531 47.87599945068359 332.4240112304688 48.14199829101562 332.1730041503906 48.38899993896484 C 331.9649963378906 48.59400177001953 331.7680053710938 48.69599914550781 331.5790100097656 48.69599914550781 C 331.5090026855469 48.69599914550781 331.4460144042969 48.68299865722656 331.3890075683594 48.65800094604492 C 331.3320007324219 48.63199996948242 331.281005859375 48.59400177001953 331.2369995117188 48.54199981689453 C 331.2179870605469 48.57500076293945 331.2070007324219 48.59600067138672 331.2019958496094 48.60499954223633 C 331.1619873046875 48.69100189208984 331.135009765625 48.74399948120117 331.1199951171875 48.76200103759766 C 331.1050109863281 48.78099822998047 331.0809936523438 48.79000091552734 331.0480041503906 48.79000091552734 C 331.0069885253906 48.79000091552734 330.9670104980469 48.76599884033203 330.9299926757812 48.71699905395508 C 330.9039916992188 48.68399810791016 330.8909912109375 48.64899826049805 330.8909912109375 48.61199951171875 C 330.8909912109375 48.54700088500977 331.0249938964844 48.21799850463867 331.2929992675781 47.62400054931641 C 331.6669921875 46.79600143432617 332.1019897460938 45.97200012207031 332.5950012207031 45.15200042724609 C 332.7950134277344 44.81700134277344 332.9169921875 44.62099838256836 332.9620056152344 44.5620002746582 C 333.010009765625 44.49300003051758 333.0559997558594 44.45800018310547 333.0979919433594 44.45800018310547 C 333.1489868164062 44.45800018310547 333.1940002441406 44.48300170898438 333.2340087890625 44.53499984741211 C 333.2590026855469 44.56700134277344 333.2720031738281 44.60599899291992 333.2720031738281 44.65000152587891 C 333.2720031738281 44.69900131225586 333.25 44.7599983215332 333.2059936523438 44.83499908447266 C 333.1969909667969 44.85100173950195 333.1229858398438 44.97100067138672 332.9859924316406 45.19400024414062 C 332.5650024414062 45.84600067138672 332.2569885253906 46.38399887084961 332.0639953613281 46.80699920654297 M 331.4760131835938 48.31900024414062 C 331.5119934082031 48.34199905395508 331.5499877929688 48.35400009155273 331.5899963378906 48.35400009155273 C 331.7919921875 48.35400009155273 332.0060119628906 48.17800140380859 332.2319946289062 47.82699966430664 C 332.3370056152344 47.66799926757812 332.4190063476562 47.51100158691406 332.4800109863281 47.35499954223633 C 332.5329895019531 47.21599960327148 332.5599975585938 47.11199951171875 332.5599975585938 47.04499816894531 C 332.5599975585938 46.99800109863281 332.5499877929688 46.9640007019043 332.5289916992188 46.94200134277344 C 332.5079956054688 46.91999816894531 332.4750061035156 46.90800094604492 332.4309997558594 46.90800094604492 C 332.3240051269531 46.90800094604492 332.1950073242188 46.98199844360352 332.0429992675781 47.12799835205078 C 331.8919982910156 47.27299880981445 331.7430114746094 47.48099899291992 331.5960083007812 47.75299835205078 C 331.5270080566406 47.88399887084961 331.4660034179688 48.00600051879883 331.4150085449219 48.11999893188477 L 331.3699951171875 48.2140007019043 C 331.4039916992188 48.26100158691406 331.4400024414062 48.29600143432617 331.4760131835938 48.31900024414062" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_ii76at =
    '<svg viewBox="333.2 46.4 1.7 2.3" ><path  d="M 334.5780029296875 46.38800048828125 C 334.7690124511719 46.38800048828125 334.864013671875 46.50500106811523 334.864013671875 46.73699951171875 C 334.864013671875 47.04700088500977 334.7210083007812 47.43899917602539 334.4349975585938 47.91400146484375 C 334.1229858398438 48.42800140380859 333.8219909667969 48.68500137329102 333.531005859375 48.68500137329102 C 333.39599609375 48.68500137329102 333.2969970703125 48.62300109863281 333.2340087890625 48.49700164794922 C 333.2009887695312 48.43399810791016 333.1849975585938 48.35900115966797 333.1849975585938 48.27000045776367 C 333.1849975585938 47.97200012207031 333.2879943847656 47.64899826049805 333.4920043945312 47.29999923706055 C 333.6830139160156 46.97600173950195 333.9079895019531 46.72499847412109 334.1659851074219 46.54499816894531 C 334.3169860839844 46.44100189208984 334.4549865722656 46.38800048828125 334.5780029296875 46.38800048828125 M 334.2149963378906 47.70800018310547 C 334.1570129394531 47.6609992980957 334.1279907226562 47.625 334.1279907226562 47.59999847412109 C 334.1279907226562 47.58100128173828 334.1650085449219 47.52999877929688 334.239013671875 47.44599914550781 C 334.4490051269531 47.21099853515625 334.5539855957031 47.02099990844727 334.5539855957031 46.87699890136719 C 334.5539855957031 46.85800170898438 334.5480041503906 46.84000015258789 334.5360107421875 46.82099914550781 C 334.5180053710938 46.7859992980957 334.4880065917969 46.76900100708008 334.4490051269531 46.76900100708008 C 334.3739929199219 46.76900100708008 334.2650146484375 46.84099960327148 334.1210021972656 46.98500061035156 C 333.9349975585938 47.17200088500977 333.7929992675781 47.36399841308594 333.6950073242188 47.56100082397461 C 333.5809936523438 47.7869987487793 333.5239868164062 47.97499847412109 333.5239868164062 48.12400054931641 C 333.5239868164062 48.16299819946289 333.5339965820312 48.19800186157227 333.5549926757812 48.22800064086914 C 333.5849914550781 48.27000045776367 333.6239929199219 48.29100036621094 333.6700134277344 48.29100036621094 C 333.7820129394531 48.29100036621094 333.9020080566406 48.20700073242188 334.0299987792969 48.04000091552734 C 334.0859985351562 47.97000122070312 334.1310119628906 47.89799880981445 334.1659851074219 47.82300186157227 C 334.2009887695312 47.74900054931641 334.2170104980469 47.70999908447266 334.2149963378906 47.70800018310547" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_adzdd =
    '<svg viewBox="335.0 46.7 1.7 2.1" ><path  d="M 336.0419921875 48.10599899291992 C 335.9419860839844 48.24599838256836 335.8529968261719 48.35699844360352 335.7770080566406 48.44100189208984 C 335.6419982910156 48.59000015258789 335.5079956054688 48.66500091552734 335.375 48.66500091552734 C 335.260986328125 48.66500091552734 335.1730041503906 48.61299896240234 335.1099853515625 48.51100158691406 C 335.0660095214844 48.43899917602539 335.0440063476562 48.35300064086914 335.0440063476562 48.25299835205078 C 335.0440063476562 47.95199966430664 335.1719970703125 47.60800170898438 335.4280090332031 47.21900177001953 C 335.5459899902344 47.03799819946289 335.6640014648438 46.89899826049805 335.7799987792969 46.80400085449219 C 335.8710021972656 46.72700119018555 335.9450073242188 46.68899917602539 336.0039978027344 46.68899917602539 C 336.0360107421875 46.68899917602539 336.0660095214844 46.70299911499023 336.093994140625 46.73099899291992 C 336.1180114746094 46.75600051879883 336.1289978027344 46.78200149536133 336.1289978027344 46.80699920654297 C 336.1289978027344 46.85200119018555 336.0859985351562 46.92399978637695 336 47.02399826049805 C 335.8070068359375 47.25400161743164 335.6600036621094 47.46599960327148 335.5599975585938 47.65900039672852 C 335.4440002441406 47.8849983215332 335.385986328125 48.0620002746582 335.385986328125 48.18999862670898 C 335.385986328125 48.22200012207031 335.3930053710938 48.24700164794922 335.4079895019531 48.26499938964844 C 335.4230041503906 48.28200149536133 335.4450073242188 48.29100036621094 335.4729919433594 48.29100036621094 C 335.5920104980469 48.29100036621094 335.7569885253906 48.12099838256836 335.968994140625 47.78099822998047 C 336.0780029296875 47.60499954223633 336.1719970703125 47.40900039672852 336.2510070800781 47.19499969482422 C 336.2929992675781 47.07799911499023 336.3479919433594 46.97499847412109 336.4159851074219 46.88399887084961 C 336.4809875488281 46.80300140380859 336.5450134277344 46.76200103759766 336.6080017089844 46.76200103759766 C 336.6419982910156 46.76200103759766 336.6740112304688 46.77700042724609 336.7019958496094 46.80699920654297 C 336.7319946289062 46.84000015258789 336.7470092773438 46.87599945068359 336.7470092773438 46.91600036621094 C 336.7470092773438 46.99900054931641 336.6669921875 47.1879997253418 336.5060119628906 47.48099899291992 C 336.3970031738281 47.68399810791016 336.3420104980469 47.85200119018555 336.3420104980469 47.98699951171875 C 336.3420104980469 48.13199996948242 336.3810119628906 48.25500106811523 336.4570007324219 48.35699844360352 C 336.4779968261719 48.3849983215332 336.5419921875 48.43000030517578 336.6489868164062 48.4900016784668 C 336.7009887695312 48.52000045776367 336.7260131835938 48.56900024414062 336.7260131835938 48.63700103759766 C 336.7260131835938 48.67900085449219 336.7080078125 48.71500015258789 336.6719970703125 48.74499893188477 C 336.635986328125 48.77500152587891 336.5920104980469 48.79000091552734 336.5409851074219 48.79000091552734 C 336.4249877929688 48.79000091552734 336.3190002441406 48.74399948120117 336.2239990234375 48.6510009765625 C 336.1369934082031 48.56700134277344 336.0830078125 48.44599914550781 336.0589904785156 48.28799819946289 C 336.0549926757812 48.26699829101562 336.0490112304688 48.20600128173828 336.0419921875 48.10599899291992" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_z5qhkq =
    '<svg viewBox="337.3 45.2 2.1 3.5" ><path  d="M 338.3819885253906 46.39199829101562 C 338.2309875488281 46.62699890136719 338.0910034179688 46.88999938964844 337.9630126953125 47.18099975585938 C 337.7789916992188 47.59500122070312 337.68701171875 47.90499877929688 337.68701171875 48.11000061035156 C 337.68701171875 48.16799926757812 337.6990051269531 48.21200180053711 337.7239990234375 48.24200057983398 C 337.7479858398438 48.27299880981445 337.7850036621094 48.28799819946289 337.8340148925781 48.28799819946289 C 337.9500122070312 48.28799819946289 338.0910034179688 48.17800140380859 338.2560119628906 47.95899963378906 C 338.3609924316406 47.82500076293945 338.4540100097656 47.68999862670898 338.5360107421875 47.55500030517578 C 338.5799865722656 47.47800064086914 338.6279907226562 47.43899917602539 338.6789855957031 47.43899917602539 C 338.7090148925781 47.43899917602539 338.7349853515625 47.45000076293945 338.7560119628906 47.47100067138672 C 338.7739868164062 47.49200057983398 338.7829895019531 47.51300048828125 338.7829895019531 47.53400039672852 C 338.7829895019531 47.61999893188477 338.6709899902344 47.8120002746582 338.4450073242188 48.11000061035156 C 338.1749877929688 48.46799850463867 337.9280090332031 48.64699935913086 337.7049865722656 48.64699935913086 C 337.5859985351562 48.64699935913086 337.4869995117188 48.59299850463867 337.4079895019531 48.48300170898438 C 337.3590087890625 48.41299819946289 337.3349914550781 48.31499862670898 337.3349914550781 48.1870002746582 C 337.3349914550781 47.90499877929688 337.4159851074219 47.57699966430664 337.5790100097656 47.20199966430664 C 337.6189880371094 47.10900115966797 337.7279968261719 46.88399887084961 337.9070129394531 46.52799987792969 C 337.843994140625 46.54399871826172 337.7969970703125 46.55300140380859 337.7640075683594 46.55300140380859 C 337.7149963378906 46.55300140380859 337.6719970703125 46.54100036621094 337.635009765625 46.51800155639648 C 337.5840148925781 46.48500061035156 337.5580139160156 46.44400024414062 337.5580139160156 46.39500045776367 C 337.5580139160156 46.33700180053711 337.5920104980469 46.29100036621094 337.6589965820312 46.25600051879883 C 337.6780090332031 46.24700164794922 337.7640075683594 46.23099899291992 337.9179992675781 46.20999908447266 C 337.9739990234375 46.20100021362305 338.0549926757812 46.17900085449219 338.1619873046875 46.14400100708008 C 338.2439880371094 45.99800109863281 338.3760070800781 45.79899978637695 338.5599975585938 45.54700088500977 C 338.6619873046875 45.40800094604492 338.7330017089844 45.31700134277344 338.7730102539062 45.27500152587891 C 338.8290100097656 45.21699905395508 338.8779907226562 45.1879997253418 338.9200134277344 45.1879997253418 C 338.9500122070312 45.1879997253418 338.9800109863281 45.20399856567383 339.010009765625 45.23600006103516 C 339.0379943847656 45.26699829101562 339.052001953125 45.29700088500977 339.052001953125 45.32699966430664 C 339.052001953125 45.38800048828125 338.9869995117188 45.50799942016602 338.8569946289062 45.6870002746582 C 338.77099609375 45.80300140380859 338.7070007324219 45.89699935913086 338.6650085449219 45.97000122070312 C 338.9230041503906 45.90000152587891 339.1080017089844 45.8650016784668 339.2200012207031 45.8650016784668 C 339.3479919433594 45.8650016784668 339.4119873046875 45.91799926757812 339.4119873046875 46.02500152587891 C 339.4119873046875 46.07899856567383 339.3900146484375 46.11899948120117 339.3460083007812 46.14400100708008 C 339.3219909667969 46.15800094604492 339.2619934082031 46.16999816894531 339.1640014648438 46.17900085449219 C 339.1239929199219 46.17699813842773 338.9490051269531 46.22100067138672 338.6369934082031 46.3120002746582 C 338.5509948730469 46.33700180053711 338.4660034179688 46.36399841308594 338.3819885253906 46.39199829101562" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_g2fnl8 =
    '<svg viewBox="341.0 46.4 1.7 2.4" ><path  d="M 342.02099609375 48.06499862670898 C 341.9440002441406 48.20000076293945 341.8680114746094 48.31399917602539 341.7940063476562 48.40700149536133 C 341.6470031738281 48.5880012512207 341.5020141601562 48.67900085449219 341.3569946289062 48.67900085449219 C 341.2319946289062 48.67900085449219 341.1340026855469 48.61999893188477 341.0639953613281 48.50099945068359 C 341.0199890136719 48.42399978637695 340.9979858398438 48.33399963378906 340.9979858398438 48.22900009155273 C 340.9979858398438 47.97000122070312 341.0790100097656 47.68500137329102 341.2420043945312 47.37300109863281 C 341.4240112304688 47.02700042724609 341.6419982910156 46.7599983215332 341.8980102539062 46.57400131225586 C 342.0660095214844 46.45299911499023 342.2279968261719 46.39199829101562 342.3840026855469 46.39199829101562 C 342.4809875488281 46.39199829101562 342.56298828125 46.42300033569336 342.6279907226562 46.48300170898438 C 342.6839904785156 46.5369987487793 342.7120056152344 46.59700012207031 342.7120056152344 46.66500091552734 C 342.7120056152344 46.71599960327148 342.6919860839844 46.7869987487793 342.6520080566406 46.87799835205078 C 342.68701171875 46.92599868774414 342.7049865722656 46.97000122070312 342.7049865722656 47.00699996948242 C 342.7049865722656 47.05599975585938 342.6719970703125 47.13600158691406 342.6069946289062 47.24800109863281 C 342.5400085449219 47.36199951171875 342.4719848632812 47.51300048828125 342.4049987792969 47.70100021362305 C 342.3320007324219 47.90200042724609 342.2959899902344 48.0620002746582 342.2959899902344 48.18299865722656 C 342.2959899902344 48.28099822998047 342.3250122070312 48.36100006103516 342.3840026855469 48.42399978637695 C 342.3999938964844 48.44100189208984 342.447998046875 48.46699905395508 342.5270080566406 48.50400161743164 C 342.5849914550781 48.53200149536133 342.614013671875 48.58100128173828 342.614013671875 48.6510009765625 C 342.614013671875 48.69499969482422 342.5979919433594 48.73099899291992 342.5650024414062 48.75899887084961 C 342.5299987792969 48.79000091552734 342.489990234375 48.80500030517578 342.4429931640625 48.80500030517578 C 342.3169860839844 48.80500030517578 342.2090148925781 48.74900054931641 342.1180114746094 48.63700103759766 C 342.0440063476562 48.54600143432617 342.0069885253906 48.43199920654297 342.0069885253906 48.29499816894531 C 342.0069885253906 48.24800109863281 342.010986328125 48.17200088500977 342.02099609375 48.06499862670898 M 342.4570007324219 46.91600036621094 C 342.4289855957031 46.8650016784668 342.3989868164062 46.82699966430664 342.3659973144531 46.80199813842773 C 342.3340148925781 46.77799987792969 342.2990112304688 46.76599884033203 342.2619934082031 46.76599884033203 C 342.0849914550781 46.76599884033203 341.8930053710938 46.92100143432617 341.6849975585938 47.22999954223633 C 341.4570007324219 47.57199859619141 341.3429870605469 47.86199951171875 341.3429870605469 48.0989990234375 C 341.3429870605469 48.15800094604492 341.35400390625 48.20199966430664 341.3760070800781 48.23199844360352 C 341.3989868164062 48.26200103759766 341.4320068359375 48.27799987792969 341.4760131835938 48.27799987792969 C 341.5880126953125 48.27799987792969 341.7179870605469 48.15900039672852 341.8670043945312 47.92200088500977 C 341.9509887695312 47.79100036621094 342.0539855957031 47.5989990234375 342.1780090332031 47.34500122070312 C 342.2590026855469 47.18000030517578 342.3190002441406 47.07099914550781 342.3559875488281 47.01699829101562 C 342.3739929199219 46.98899841308594 342.4079895019531 46.95600128173828 342.4570007324219 46.91600036621094" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_p4ylhq =
    '<svg viewBox="342.9 44.5 2.9 4.2" ><path  d="M 344.4299926757812 46.60200119018555 C 344.6619873046875 46.1150016784668 344.8819885253906 45.69200134277344 345.0899963378906 45.33100128173828 C 345.2900085449219 44.98199844360352 345.4259948730469 44.76200103759766 345.4979858398438 44.67100143432617 C 345.5769958496094 44.57099914550781 345.6520080566406 44.52099990844727 345.7210083007812 44.52099990844727 C 345.7590026855469 44.52099990844727 345.7919921875 44.5359992980957 345.822998046875 44.56600189208984 C 345.8510131835938 44.59700012207031 345.864990234375 44.62900161743164 345.864990234375 44.66400146484375 C 345.864990234375 44.71799850463867 345.8250122070312 44.80699920654297 345.7460021972656 44.93299865722656 C 345.4079895019531 45.47800064086914 345.0989990234375 46.02999877929688 344.8169860839844 46.59099960327148 C 344.4909973144531 47.24499893188477 344.3280029296875 47.73500061035156 344.3280029296875 48.06100082397461 C 344.3280029296875 48.19400024414062 344.35400390625 48.29899978637695 344.4049987792969 48.375 C 344.4150085449219 48.39199829101562 344.4559936523438 48.42900085449219 344.531005859375 48.48699951171875 C 344.5450134277344 48.49900054931641 344.552001953125 48.52199935913086 344.552001953125 48.55699920654297 C 344.552001953125 48.60300064086914 344.5339965820312 48.64599990844727 344.4979858398438 48.68399810791016 C 344.4620056152344 48.72299957275391 344.4219970703125 48.74200057983398 344.3770141601562 48.74200057983398 C 344.3240051269531 48.74200057983398 344.2640075683594 48.70899963378906 344.1990051269531 48.64400100708008 C 344.1059875488281 48.55099868774414 344.0499877929688 48.44400024414062 344.0320129394531 48.32300186157227 C 344.0249938964844 48.27199935913086 344.0169982910156 48.17599868774414 344.0069885253906 48.0369987487793 C 343.7630004882812 48.47600173950195 343.5299987792969 48.69699859619141 343.3089904785156 48.69699859619141 C 343.1809997558594 48.69699859619141 343.0790100097656 48.62400054931641 343.0020141601562 48.47999954223633 C 342.9509887695312 48.3849983215332 342.9249877929688 48.2760009765625 342.9249877929688 48.15499877929688 C 342.9249877929688 47.79199981689453 343.0580139160156 47.42699813842773 343.322998046875 47.05899810791016 C 343.5859985351562 46.69599914550781 343.8689880371094 46.51399993896484 344.1709899902344 46.51399993896484 C 344.2550048828125 46.51399993896484 344.3410034179688 46.54399871826172 344.4299926757812 46.60200119018555 M 344.3110046386719 46.88800048828125 C 344.2479858398438 46.84600067138672 344.1929931640625 46.82500076293945 344.1470031738281 46.82500076293945 C 343.9509887695312 46.82500076293945 343.7659912109375 46.94499969482422 343.5920104980469 47.18500137329102 C 343.3609924316406 47.49700164794922 343.2460021972656 47.79800033569336 343.2460021972656 48.0890007019043 C 343.2460021972656 48.12400054931641 343.2529907226562 48.15700149536133 343.2669982910156 48.1870002746582 C 343.2950134277344 48.24499893188477 343.3370056152344 48.27399826049805 343.3930053710938 48.27399826049805 C 343.4739990234375 48.27399826049805 343.572998046875 48.19499969482422 343.6900024414062 48.0369987487793 C 343.8460083007812 47.82699966430664 343.989990234375 47.57899856567383 344.1220092773438 47.29299926757812 C 344.1690063476562 47.19499969482422 344.2139892578125 47.09700012207031 344.2590026855469 47 L 344.2900085449219 46.93299865722656 L 344.3110046386719 46.88800048828125 Z" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_gtxguy =
    '<svg viewBox="345.1 46.6 2.1 2.1" ><path  d="M 346.3580017089844 47.6870002746582 C 346.2160034179688 47.93099975585938 346.093994140625 48.11299896240234 345.9909973144531 48.23199844360352 C 345.7420043945312 48.52500152587891 345.5350036621094 48.67100143432617 345.3699951171875 48.67100143432617 C 345.2699890136719 48.67100143432617 345.1929931640625 48.61700057983398 345.1400146484375 48.50799942016602 C 345.1019897460938 48.43500137329102 345.0840148925781 48.36000061035156 345.0840148925781 48.27999877929688 C 345.0840148925781 48.12699890136719 345.1499938964844 47.90499877929688 345.2829895019531 47.61399841308594 C 345.4010009765625 47.36000061035156 345.5020141601562 47.15999984741211 345.5830078125 47.01300048828125 C 345.6430053710938 46.90800094604492 345.6799926757812 46.84000015258789 345.6910095214844 46.80699920654297 C 345.718994140625 46.74399948120117 345.7439880371094 46.69699859619141 345.7650146484375 46.66400146484375 C 345.7950134277344 46.6150016784668 345.8370056152344 46.59099960327148 345.8900146484375 46.59099960327148 C 345.9179992675781 46.59099960327148 345.9429931640625 46.60200119018555 345.9639892578125 46.62599945068359 C 345.9869995117188 46.65399932861328 345.9979858398438 46.68600082397461 345.9979858398438 46.72299957275391 C 345.9979858398438 46.82799911499023 345.9039916992188 47.0620002746582 345.7160034179688 47.42499923706055 C 345.5270080566406 47.78400039672852 345.4330139160156 48.02099990844727 345.4330139160156 48.13700103759766 C 345.4330139160156 48.21200180053711 345.4620056152344 48.24900054931641 345.5199890136719 48.24900054931641 C 345.6199951171875 48.24900054931641 345.7619934082031 48.11899948120117 345.9460144042969 47.85800170898438 C 346.0280151367188 47.74200057983398 346.1119995117188 47.59400177001953 346.2009887695312 47.41500091552734 C 346.1990051269531 47.35699844360352 346.1969909667969 47.3120002746582 346.1969909667969 47.28200149536133 C 346.1969909667969 47.10699844360352 346.2300109863281 46.95600128173828 346.2950134277344 46.82799911499023 C 346.3789978027344 46.66299819946289 346.4920043945312 46.58000183105469 346.6340026855469 46.58000183105469 C 346.7149963378906 46.58000183105469 346.7560119628906 46.62900161743164 346.7560119628906 46.72700119018555 C 346.7560119628906 46.88299942016602 346.6749877929688 47.11199951171875 346.5119934082031 47.41500091552734 C 346.5580139160156 47.42399978637695 346.5950012207031 47.42900085449219 346.6229858398438 47.42900085449219 C 346.7000122070312 47.42900085449219 346.7999877929688 47.38000106811523 346.9240112304688 47.28200149536133 C 347.02099609375 47.20299911499023 347.0849914550781 47.16299819946289 347.1159973144531 47.16299819946289 C 347.1409912109375 47.16299819946289 347.1679992675781 47.17800140380859 347.1960144042969 47.20899963378906 C 347.2170104980469 47.23400115966797 347.2269897460938 47.2599983215332 347.2269897460938 47.2859992980957 C 347.2269897460938 47.36899948120117 347.1690063476562 47.4640007019043 347.0530090332031 47.56800079345703 C 346.9179992675781 47.6870002746582 346.7640075683594 47.74599838256836 346.5920104980469 47.74599838256836 C 346.5239868164062 47.74599838256836 346.4460144042969 47.72700119018555 346.3580017089844 47.6870002746582" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_e4x2dz =
    '<svg viewBox="347.1 46.5 2.0 2.1" ><path  d="M 347.5 47.97000122070312 L 347.5 48.03300094604492 C 347.5 48.08399963378906 347.5130004882812 48.12900161743164 347.5390014648438 48.16600036621094 C 347.5969848632812 48.25199890136719 347.6919860839844 48.29499816894531 347.8250122070312 48.29499816894531 C 348.1159973144531 48.29499816894531 348.4519958496094 48.07099914550781 348.8340148925781 47.625 C 348.9010009765625 47.54800033569336 348.9580078125 47.50899887084961 349.0050048828125 47.50899887084961 C 349.0299987792969 47.50899887084961 349.0539855957031 47.52199935913086 349.0750122070312 47.54800033569336 C 349.0889892578125 47.56600189208984 349.0960083007812 47.58399963378906 349.0960083007812 47.59999847412109 C 349.0960083007812 47.69100189208984 348.9840087890625 47.84500122070312 348.760009765625 48.06100082397461 C 348.5859985351562 48.23099899291992 348.3999938964844 48.36899948120117 348.2019958496094 48.47600173950195 C 348.0039978027344 48.58300018310547 347.8200073242188 48.63700103759766 347.6499938964844 48.63700103759766 C 347.4760131835938 48.63700103759766 347.3380126953125 48.57600021362305 347.2380065917969 48.45500183105469 C 347.1709899902344 48.37200164794922 347.1369934082031 48.25799942016602 347.1369934082031 48.11299896240234 C 347.1369934082031 47.72000122070312 347.3219909667969 47.33499908447266 347.6919860839844 46.95800018310547 C 347.9920043945312 46.6510009765625 348.2539978027344 46.49700164794922 348.4779968261719 46.49700164794922 C 348.5379943847656 46.49700164794922 348.5929870605469 46.51599884033203 348.6419982910156 46.55300140380859 C 348.7019958496094 46.60200119018555 348.7330017089844 46.66600036621094 348.7330017089844 46.74499893188477 C 348.7330017089844 46.86800003051758 348.6759948730469 47.01900100708008 348.5610046386719 47.19900131225586 C 348.3259887695312 47.57099914550781 347.9729919433594 47.82799911499023 347.5 47.97000122070312 M 347.5769958496094 47.69800186157227 C 347.739990234375 47.64199829101562 347.8680114746094 47.57899856567383 347.9609985351562 47.50899887084961 C 348.1239929199219 47.38399887084961 348.2529907226562 47.24200057983398 348.3489990234375 47.08300018310547 C 348.3829956054688 47.02799987792969 348.4010009765625 46.97800064086914 348.4010009765625 46.93299865722656 C 348.4010009765625 46.88700103759766 348.3789978027344 46.86299896240234 348.3349914550781 46.86299896240234 C 348.2739868164062 46.86299896240234 348.18798828125 46.90900039672852 348.0759887695312 47 C 347.8760070800781 47.15999984741211 347.7099914550781 47.39300155639648 347.5769958496094 47.69800186157227" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_ms6xy2 =
    '<svg viewBox="349.2 46.5 2.5 2.3" ><path  d="M 350.0039978027344 47.49200057983398 C 350.2319946289062 47.24800109863281 350.4949951171875 47.00899887084961 350.7929992675781 46.7760009765625 C 350.8999938964844 46.69300079345703 351.0140075683594 46.6150016784668 351.135009765625 46.54199981689453 C 351.1960144042969 46.50799942016602 351.2340087890625 46.4900016784668 351.25 46.4900016784668 C 351.2850036621094 46.4900016784668 351.3200073242188 46.51599884033203 351.3550109863281 46.56700134277344 C 351.3760070800781 46.59500122070312 351.385986328125 46.61999893188477 351.385986328125 46.64400100708008 C 351.385986328125 46.68600082397461 351.3420104980469 46.74300003051758 351.2539978027344 46.81499862670898 C 351.0159912109375 47.00299835205078 350.8980102539062 47.14500045776367 350.8980102539062 47.24100112915039 C 350.8980102539062 47.29399871826172 350.9280090332031 47.32099914550781 350.9880065917969 47.32099914550781 C 351.0889892578125 47.32099914550781 351.260986328125 47.23799896240234 351.5050048828125 47.07300186157227 C 351.5469970703125 47.04499816894531 351.5820007324219 47.03099822998047 351.6099853515625 47.03099822998047 C 351.6289978027344 47.03099822998047 351.6470031738281 47.04000091552734 351.6659851074219 47.05899810791016 C 351.68701171875 47.08000183105469 351.6969909667969 47.10200119018555 351.6969909667969 47.125 C 351.6969909667969 47.19499969482422 351.5989990234375 47.30199813842773 351.4039916992188 47.44699859619141 C 351.1990051269531 47.59999847412109 351.0050048828125 47.67699813842773 350.8210144042969 47.67699813842773 C 350.7460021972656 47.67699813842773 350.6780090332031 47.65700149536133 350.614990234375 47.61800003051758 C 350.5610046386719 47.58499908447266 350.5350036621094 47.52700042724609 350.5350036621094 47.44300079345703 C 350.5350036621094 47.3849983215332 350.5589904785156 47.31900024414062 350.6080017089844 47.24399948120117 C 350.4240112304688 47.375 350.2080078125 47.59799957275391 349.9590148925781 47.91500091552734 C 349.8139953613281 48.11000061035156 349.6709899902344 48.35100173950195 349.5289916992188 48.63700103759766 C 349.4760131835938 48.74399948120117 349.4089965820312 48.79800033569336 349.3299865722656 48.79800033569336 C 349.2439880371094 48.79800033569336 349.2009887695312 48.75699996948242 349.2009887695312 48.67599868774414 C 349.2009887695312 48.59600067138672 349.2690124511719 48.3849983215332 349.4039916992188 48.04000091552734 C 349.60400390625 47.52799987792969 349.81298828125 47.13100051879883 350.0320129394531 46.84999847412109 C 350.1669921875 46.67499923706055 350.2799987792969 46.5880012512207 350.3710021972656 46.5880012512207 C 350.4010009765625 46.5880012512207 350.4289855957031 46.59700012207031 350.4540100097656 46.61600112915039 C 350.4849853515625 46.63899993896484 350.5 46.66799926757812 350.5 46.70299911499023 C 350.5 46.73799896240234 350.4760131835938 46.7869987487793 350.4299926757812 46.84999847412109 C 350.4209899902344 46.86100006103516 350.3590087890625 46.93899917602539 350.2449951171875 47.08399963378906 C 350.1400146484375 47.22100067138672 350.0599975585938 47.35699844360352 350.0039978027344 47.49200057983398" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_c97a1i =
    '<svg viewBox="352.0 45.2 2.1 3.5" ><path  d="M 353.010009765625 46.39199829101562 C 352.8590087890625 46.62699890136719 352.718994140625 46.88999938964844 352.5910034179688 47.18099975585938 C 352.4070129394531 47.59500122070312 352.3150024414062 47.90499877929688 352.3150024414062 48.11000061035156 C 352.3150024414062 48.16799926757812 352.3269958496094 48.21200180053711 352.3519897460938 48.24200057983398 C 352.3760070800781 48.27299880981445 352.4129943847656 48.28799819946289 352.4620056152344 48.28799819946289 C 352.5780029296875 48.28799819946289 352.718994140625 48.17800140380859 352.8840026855469 47.95899963378906 C 352.989013671875 47.82500076293945 353.0820007324219 47.68999862670898 353.1640014648438 47.55500030517578 C 353.2080078125 47.47800064086914 353.2560119628906 47.43899917602539 353.3070068359375 47.43899917602539 C 353.3370056152344 47.43899917602539 353.3630065917969 47.45000076293945 353.3840026855469 47.47100067138672 C 353.4020080566406 47.49200057983398 353.4110107421875 47.51300048828125 353.4110107421875 47.53400039672852 C 353.4110107421875 47.61999893188477 353.2990112304688 47.8120002746582 353.072998046875 48.11000061035156 C 352.8030090332031 48.46799850463867 352.5559997558594 48.64699935913086 352.3330078125 48.64699935913086 C 352.2139892578125 48.64699935913086 352.114990234375 48.59299850463867 352.0360107421875 48.48300170898438 C 351.9869995117188 48.41299819946289 351.9630126953125 48.31499862670898 351.9630126953125 48.1870002746582 C 351.9630126953125 47.90499877929688 352.0440063476562 47.57699966430664 352.2070007324219 47.20199966430664 C 352.2470092773438 47.10900115966797 352.3559875488281 46.88399887084961 352.5350036621094 46.52799987792969 C 352.4719848632812 46.54399871826172 352.4249877929688 46.55300140380859 352.3919982910156 46.55300140380859 C 352.3429870605469 46.55300140380859 352.2999877929688 46.54100036621094 352.2630004882812 46.51800155639648 C 352.2120056152344 46.48500061035156 352.1860046386719 46.44400024414062 352.1860046386719 46.39500045776367 C 352.1860046386719 46.33700180053711 352.2200012207031 46.29100036621094 352.2869873046875 46.25600051879883 C 352.3059997558594 46.24700164794922 352.3919982910156 46.23099899291992 352.5459899902344 46.20999908447266 C 352.6019897460938 46.20100021362305 352.6830139160156 46.17900085449219 352.7900085449219 46.14400100708008 C 352.8720092773438 45.99800109863281 353.0039978027344 45.79899978637695 353.18798828125 45.54700088500977 C 353.2900085449219 45.40800094604492 353.3609924316406 45.31700134277344 353.4010009765625 45.27500152587891 C 353.4570007324219 45.21699905395508 353.5060119628906 45.1879997253418 353.5480041503906 45.1879997253418 C 353.5780029296875 45.1879997253418 353.6080017089844 45.20399856567383 353.6380004882812 45.23600006103516 C 353.6659851074219 45.26699829101562 353.6799926757812 45.29700088500977 353.6799926757812 45.32699966430664 C 353.6799926757812 45.38800048828125 353.614990234375 45.50799942016602 353.4849853515625 45.6870002746582 C 353.3989868164062 45.80300140380859 353.3349914550781 45.89699935913086 353.2929992675781 45.97000122070312 C 353.5509948730469 45.90000152587891 353.7359924316406 45.8650016784668 353.8479919433594 45.8650016784668 C 353.9760131835938 45.8650016784668 354.0400085449219 45.91799926757812 354.0400085449219 46.02500152587891 C 354.0400085449219 46.07899856567383 354.0180053710938 46.11899948120117 353.9739990234375 46.14400100708008 C 353.9500122070312 46.15800094604492 353.8900146484375 46.16999816894531 353.7919921875 46.17900085449219 C 353.7520141601562 46.17699813842773 353.5769958496094 46.22100067138672 353.2650146484375 46.3120002746582 C 353.1789855957031 46.33700180053711 353.093994140625 46.36399841308594 353.010009765625 46.39199829101562" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_q92qaj =
    '<svg viewBox="353.5 45.3 1.9 3.5" ><path  d="M 354.5719909667969 46.54899978637695 C 354.6109924316406 46.54899978637695 354.6440124511719 46.56399917602539 354.6690063476562 46.59500122070312 C 354.68798828125 46.61999893188477 354.6969909667969 46.64599990844727 354.6969909667969 46.67100143432617 C 354.6969909667969 46.7130012512207 354.6640014648438 46.78300094604492 354.5960083007812 46.88100051879883 C 354.35400390625 47.25600051879883 354.1820068359375 47.56399917602539 354.0790100097656 47.80599975585938 C 353.9700012207031 48.05500030517578 353.8729858398438 48.31100082397461 353.7900085449219 48.57400131225586 C 353.7520141601562 48.68999862670898 353.6940002441406 48.74900054931641 353.614990234375 48.74900054931641 C 353.5690002441406 48.74900054931641 353.531005859375 48.72999954223633 353.5029907226562 48.69300079345703 C 353.4779968261719 48.6619987487793 353.4649963378906 48.63000106811523 353.4649963378906 48.59500122070312 C 353.4649963378906 48.52500152587891 353.5400085449219 48.29199981689453 353.68798828125 47.89699935913086 C 353.8049926757812 47.58499908447266 353.9930114746094 47.2400016784668 354.2539978027344 46.86299896240234 C 354.3380126953125 46.7400016784668 354.4010009765625 46.65700149536133 354.4429931640625 46.61600112915039 C 354.4840087890625 46.57099914550781 354.5270080566406 46.54899978637695 354.5719909667969 46.54899978637695 M 355.2349853515625 45.25400161743164 C 355.3399963378906 45.25400161743164 355.3919982910156 45.30799865722656 355.3919982910156 45.41500091552734 C 355.3919982910156 45.51200103759766 355.3410034179688 45.62099838256836 355.239013671875 45.73899841308594 C 355.1409912109375 45.85300064086914 355.0459899902344 45.90999984741211 354.9559936523438 45.90999984741211 C 354.9119873046875 45.90999984741211 354.875 45.89400100708008 354.8469848632812 45.86100006103516 C 354.8200073242188 45.83100128173828 354.8059997558594 45.79399871826172 354.8059997558594 45.75 C 354.8059997558594 45.63800048828125 354.8670043945312 45.51900100708008 354.9909973144531 45.39400100708008 C 355.0809936523438 45.30099868774414 355.1629943847656 45.25400161743164 355.2349853515625 45.25400161743164" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_fh7s40 =
    '<svg viewBox="354.7 46.3 2.1 2.5" ><path  d="M 356.3810119628906 46.32199859619141 C 356.5249938964844 46.32199859619141 356.6340026855469 46.34799957275391 356.7059936523438 46.39899826049805 C 356.7780151367188 46.45000076293945 356.8139953613281 46.52799987792969 356.8139953613281 46.63299942016602 C 356.8139953613281 46.77000045776367 356.7630004882812 46.90299987792969 356.6600036621094 47.03099822998047 C 356.56298828125 47.15200042724609 356.4159851074219 47.24900054931641 356.2200012207031 47.32400131225586 C 356.1130065917969 47.36399841308594 356.0239868164062 47.38299942016602 355.9519958496094 47.38299942016602 C 355.85400390625 47.38299942016602 355.8049926757812 47.34000015258789 355.8049926757812 47.25400161743164 C 355.8049926757812 47.19599914550781 355.8330078125 47.15200042724609 355.8890075683594 47.12099838256836 C 355.9030151367188 47.11399841308594 355.9819946289062 47.09500122070312 356.1260070800781 47.0620002746582 C 356.2120056152344 47.04299926757812 356.2909851074219 47.00299835205078 356.364013671875 46.93999862670898 C 356.4259948730469 46.88600158691406 356.4580078125 46.82799911499023 356.4580078125 46.76499938964844 C 356.4580078125 46.71699905395508 356.4440002441406 46.68000030517578 356.4159851074219 46.65700149536133 C 356.3880004882812 46.63399887084961 356.3460083007812 46.62200164794922 356.2900085449219 46.62200164794922 C 356.1549987792969 46.62200164794922 356.0060119628906 46.67699813842773 355.8429870605469 46.7859992980957 C 355.6549987792969 46.90999984741211 355.5610046386719 47.05599975585938 355.5610046386719 47.22600173950195 C 355.5610046386719 47.34700012207031 355.6220092773438 47.49800109863281 355.7460021972656 47.68000030517578 C 355.8829956054688 47.87799835205078 355.9519958496094 48.04499816894531 355.9519958496094 48.18299865722656 C 355.9519958496094 48.38800048828125 355.8609924316406 48.54800033569336 355.6789855957031 48.66500091552734 C 355.5679931640625 48.73699951171875 355.4410095214844 48.77299880981445 355.2990112304688 48.77299880981445 C 355.0750122070312 48.77299880981445 354.9049987792969 48.69200134277344 354.7890014648438 48.53200149536133 C 354.7080078125 48.41799926757812 354.6669921875 48.28300094604492 354.6669921875 48.12699890136719 C 354.6669921875 47.94499969482422 354.7130126953125 47.79299926757812 354.8070068359375 47.66999816894531 C 354.8670043945312 47.5880012512207 354.9299926757812 47.54700088500977 354.9949951171875 47.54700088500977 C 355.0530090332031 47.54700088500977 355.0820007324219 47.57099914550781 355.0820007324219 47.61700057983398 C 355.0820007324219 47.63600158691406 355.0719909667969 47.66400146484375 355.0509948730469 47.70100021362305 C 354.9970092773438 47.80099868774414 354.9710083007812 47.91899871826172 354.9710083007812 48.05400085449219 C 354.9710083007812 48.16799926757812 355.010986328125 48.26399993896484 355.0929870605469 48.34299850463867 C 355.1650085449219 48.41299819946289 355.2479858398438 48.44800186157227 355.3410034179688 48.44800186157227 C 355.4309997558594 48.44800186157227 355.5020141601562 48.41799926757812 355.5539855957031 48.35699844360352 C 355.5960083007812 48.30599975585938 355.6159973144531 48.24100112915039 355.6159973144531 48.1619987487793 C 355.6159973144531 48.06399917602539 355.5610046386719 47.9370002746582 355.4490051269531 47.78099822998047 C 355.2950134277344 47.56700134277344 355.2179870605469 47.37300109863281 355.2179870605469 47.19800186157227 C 355.2179870605469 46.96599960327148 355.3450012207031 46.7599983215332 355.5989990234375 46.58000183105469 C 355.8460083007812 46.40800094604492 356.1059875488281 46.32199859619141 356.3810119628906 46.32199859619141" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_sunjq =
    '<svg viewBox="356.6 45.3 1.9 3.5" ><path  d="M 357.6910095214844 46.54899978637695 C 357.7300109863281 46.54899978637695 357.7630004882812 46.56399917602539 357.7879943847656 46.59500122070312 C 357.8070068359375 46.61999893188477 357.8160095214844 46.64599990844727 357.8160095214844 46.67100143432617 C 357.8160095214844 46.7130012512207 357.7829895019531 46.78300094604492 357.7149963378906 46.88100051879883 C 357.4729919433594 47.25600051879883 357.3009948730469 47.56399917602539 357.197998046875 47.80599975585938 C 357.0889892578125 48.05500030517578 356.9920043945312 48.31100082397461 356.9089965820312 48.57400131225586 C 356.8710021972656 48.68999862670898 356.81298828125 48.74900054931641 356.7340087890625 48.74900054931641 C 356.68798828125 48.74900054931641 356.6499938964844 48.72999954223633 356.6220092773438 48.69300079345703 C 356.5969848632812 48.6619987487793 356.5840148925781 48.63000106811523 356.5840148925781 48.59500122070312 C 356.5840148925781 48.52500152587891 356.6589965820312 48.29199981689453 356.8070068359375 47.89699935913086 C 356.9240112304688 47.58499908447266 357.1119995117188 47.2400016784668 357.3729858398438 46.86299896240234 C 357.4570007324219 46.7400016784668 357.5199890136719 46.65700149536133 357.56201171875 46.61600112915039 C 357.6029968261719 46.57099914550781 357.64599609375 46.54899978637695 357.6910095214844 46.54899978637695 M 358.35400390625 45.25400161743164 C 358.4590148925781 45.25400161743164 358.510986328125 45.30799865722656 358.510986328125 45.41500091552734 C 358.510986328125 45.51200103759766 358.4599914550781 45.62099838256836 358.3569946289062 45.73899841308594 C 358.260009765625 45.85300064086914 358.1650085449219 45.90999984741211 358.0750122070312 45.90999984741211 C 358.0299987792969 45.90999984741211 357.9939880371094 45.89400100708008 357.9660034179688 45.86100006103516 C 357.9389953613281 45.83100128173828 357.9249877929688 45.79399871826172 357.9249877929688 45.75 C 357.9249877929688 45.63800048828125 357.9859924316406 45.51900100708008 358.1099853515625 45.39400100708008 C 358.2000122070312 45.30099868774414 358.2820129394531 45.25400161743164 358.35400390625 45.25400161743164" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_jraled =
    '<svg viewBox="357.7 46.6 2.0 2.4" ><path  d="M 358.5429992675781 47.44300079345703 C 358.572998046875 47.41500091552734 358.6019897460938 47.38700103759766 358.6300048828125 47.35900115966797 C 359.1170043945312 46.88399887084961 359.4429931640625 46.64699935913086 359.6080017089844 46.64699935913086 C 359.6990051269531 46.64699935913086 359.7439880371094 46.69699859619141 359.7439880371094 46.79700088500977 C 359.7439880371094 46.86700057983398 359.7030029296875 46.95000076293945 359.6220092773438 47.04499816894531 C 359.177001953125 47.56399917602539 358.9549865722656 48.02099990844727 358.9549865722656 48.41699981689453 C 358.9549865722656 48.54499816894531 358.989990234375 48.66699981689453 359.0599975585938 48.78400039672852 C 359.0920104980469 48.83700180053711 359.1090087890625 48.87900161743164 359.1090087890625 48.90900039672852 C 359.1090087890625 48.9370002746582 359.0950012207031 48.9640007019043 359.0669860839844 48.9900016784668 C 359.0360107421875 49.02199935913086 359 49.03900146484375 358.9580078125 49.03900146484375 C 358.8630065917969 49.03900146484375 358.7829895019531 48.97800064086914 358.7179870605469 48.85699844360352 C 358.6549987792969 48.74300003051758 358.6229858398438 48.60400009155273 358.6229858398438 48.44100189208984 C 358.6229858398438 48.12699890136719 358.7420043945312 47.77899932861328 358.97900390625 47.39799880981445 C 358.6629943847656 47.59999847412109 358.3680114746094 47.95899963378906 358.0960083007812 48.47299957275391 C 358.0260009765625 48.59600067138672 357.9519958496094 48.65800094604492 357.8729858398438 48.65800094604492 C 357.8330078125 48.65800094604492 357.8009948730469 48.64400100708008 357.7749938964844 48.61600112915039 C 357.7420043945312 48.58300018310547 357.7260131835938 48.54199981689453 357.7260131835938 48.4900016784668 C 357.7260131835938 48.3650016784668 357.8689880371094 48.03499984741211 358.1549987792969 47.50199890136719 C 358.3089904785156 47.2140007019043 358.4299926757812 47.00400161743164 358.5190124511719 46.87400054931641 C 358.6069946289062 46.74599838256836 358.6830139160156 46.68199920654297 358.7449951171875 46.68199920654297 C 358.7760009765625 46.68199920654297 358.8049926757812 46.69599914550781 358.8330078125 46.7239990234375 C 358.864990234375 46.75600051879883 358.8819885253906 46.79399871826172 358.8819885253906 46.83599853515625 C 358.8819885253906 46.88700103759766 358.8479919433594 46.95999908447266 358.7799987792969 47.05599975585938 C 358.6830139160156 47.19699859619141 358.60400390625 47.32699966430664 358.5429992675781 47.44300079345703" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_itxren =
    '<svg viewBox="358.9 46.3 3.2 4.3" ><path  d="M 360.9590148925781 48.34099960327148 C 361.2080078125 48.15900039672852 361.3930053710938 47.99399948120117 361.5150146484375 47.84500122070312 C 361.6940002441406 47.62799835205078 361.8210144042969 47.45299911499023 361.8949890136719 47.31800079345703 C 361.9320068359375 47.25699996948242 361.9710083007812 47.22700119018555 362.010009765625 47.22700119018555 C 362.0660095214844 47.22700119018555 362.093994140625 47.25400161743164 362.093994140625 47.30699920654297 C 362.093994140625 47.36999893188477 362.0499877929688 47.47499847412109 361.9609985351562 47.62099838256836 C 361.68701171875 48.06800079345703 361.2749938964844 48.45800018310547 360.7260131835938 48.79100036621094 C 360.4700012207031 49.32600021362305 360.281005859375 49.68899917602539 360.1600036621094 49.88000106811523 C 359.8389892578125 50.38299942016602 359.5360107421875 50.63399887084961 359.2520141601562 50.63399887084961 C 359.1029968261719 50.63399887084961 358.9960021972656 50.57600021362305 358.9309997558594 50.45999908447266 C 358.8940124511719 50.39199829101562 358.875 50.31499862670898 358.875 50.22900009155273 C 358.875 49.86399841308594 359.1099853515625 49.51399993896484 359.5799865722656 49.17800140380859 C 359.6549987792969 49.12300109863281 359.9559936523438 48.94800186157227 360.4849853515625 48.65499877929688 C 360.5870056152344 48.4379997253418 360.6659851074219 48.26800155639648 360.7219848632812 48.14500045776367 C 360.4779968261719 48.4010009765625 360.2749938964844 48.52899932861328 360.114990234375 48.52899932861328 C 360.0150146484375 48.52899932861328 359.93701171875 48.47800064086914 359.8810119628906 48.375 C 359.8460083007812 48.30799865722656 359.8280029296875 48.23799896240234 359.8280029296875 48.16600036621094 C 359.8280029296875 47.99800109863281 359.8970031738281 47.78300094604492 360.0339965820312 47.52000045776367 C 360.2300109863281 47.14099884033203 360.4649963378906 46.84000015258789 360.739990234375 46.61899948120117 C 360.9700012207031 46.43500137329102 361.1740112304688 46.34400177001953 361.3500061035156 46.34400177001953 C 361.4410095214844 46.34400177001953 361.5190124511719 46.37699890136719 361.5840148925781 46.44499969482422 C 361.6289978027344 46.48899841308594 361.6510009765625 46.55400085449219 361.6510009765625 46.63999938964844 C 361.6510009765625 46.74700164794922 361.614990234375 46.88000106811523 361.5419921875 47.03799819946289 C 361.5960083007812 47.0890007019043 361.6229858398438 47.12799835205078 361.6229858398438 47.15299987792969 C 361.6229858398438 47.16999816894531 361.6109924316406 47.19300079345703 361.5880126953125 47.22299957275391 C 361.5249938964844 47.31000137329102 361.4240112304688 47.47100067138672 361.2839965820312 47.70899963378906 C 361.1610107421875 47.91600036621094 361.0530090332031 48.12599945068359 360.9590148925781 48.34099960327148 M 360.2749938964844 49.06000137329102 C 359.9679870605469 49.18999862670898 359.6969909667969 49.38800048828125 359.4620056152344 49.65299987792969 C 359.3519897460938 49.7760009765625 359.2739868164062 49.90700149536133 359.2279968261719 50.04399871826172 C 359.2139892578125 50.08599853515625 359.2070007324219 50.12099838256836 359.2070007324219 50.14899826049805 C 359.2070007324219 50.17900085449219 359.2139892578125 50.20600128173828 359.2279968261719 50.22900009155273 C 359.2529907226562 50.27099990844727 359.2900085449219 50.29199981689453 359.3359985351562 50.29199981689453 C 359.4800109863281 50.29199981689453 359.6489868164062 50.13700103759766 359.8420104980469 49.82799911499023 C 360.010009765625 49.56000137329102 360.1539916992188 49.30400085449219 360.2749938964844 49.06000137329102 M 360.9349975585938 47.53400039672852 C 360.9020080566406 47.49900054931641 360.885986328125 47.47499847412109 360.885986328125 47.46099853515625 C 360.885986328125 47.43999862670898 360.9039916992188 47.41299819946289 360.93798828125 47.38000106811523 C 361.0549926757812 47.26900100708008 361.1489868164062 47.15200042724609 361.2210083007812 47.03099822998047 C 361.2789916992188 46.93600082397461 361.3089904785156 46.86100006103516 361.3089904785156 46.80799865722656 C 361.3089904785156 46.74499893188477 361.2789916992188 46.7140007019043 361.2210083007812 46.7140007019043 C 361.1210021972656 46.7140007019043 360.9779968261719 46.80899810791016 360.7919921875 47 C 360.5710144042969 47.22600173950195 360.3989868164062 47.47800064086914 360.2749938964844 47.75699996948242 C 360.2149963378906 47.89699935913086 360.1839904785156 48.00400161743164 360.1839904785156 48.07899856567383 C 360.1839904785156 48.12099838256836 360.1940002441406 48.15200042724609 360.2120056152344 48.17300033569336 C 360.2309875488281 48.19400024414062 360.2579956054688 48.20399856567383 360.2929992675781 48.20399856567383 C 360.3739929199219 48.20399856567383 360.4880065917969 48.12099838256836 360.635009765625 47.95299911499023 C 360.7279968261719 47.84600067138672 360.8070068359375 47.74100112915039 360.8720092773438 47.63899993896484 C 360.9159851074219 47.57099914550781 360.93701171875 47.5359992980957 360.9349975585938 47.53400039672852" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_yc7sa =
    '<svg viewBox="362.3 44.2 2.8 4.9" ><path  d="M 362.6430053710938 48.3849983215332 C 362.6940002441406 48.3849983215332 362.7369995117188 48.40900039672852 362.7720031738281 48.45500183105469 C 362.7950134277344 48.48500061035156 362.8070068359375 48.52399826049805 362.8070068359375 48.57099914550781 C 362.8070068359375 48.68000030517578 362.7770080566406 48.79499816894531 362.7160034179688 48.91600036621094 C 362.6530151367188 49.04399871826172 362.5710144042969 49.10800170898438 362.4679870605469 49.10800170898438 C 362.3609924316406 49.10800170898438 362.3080139160156 49.04800033569336 362.3080139160156 48.92699813842773 C 362.3080139160156 48.80599975585938 362.3450012207031 48.68199920654297 362.4190063476562 48.55699920654297 C 362.4869995117188 48.44300079345703 362.5610046386719 48.3849983215332 362.6430053710938 48.3849983215332 M 364.9119873046875 44.23799896240234 C 364.9630126953125 44.23799896240234 365.0029907226562 44.25899887084961 365.031005859375 44.30099868774414 C 365.0539855957031 44.33599853515625 365.0660095214844 44.375 365.0660095214844 44.41999816894531 C 365.0660095214844 44.51499938964844 364.9960021972656 44.69400024414062 364.8559875488281 44.95700073242188 C 364.2839965820312 46.02999877929688 363.7669982910156 46.92599868774414 363.3059997558594 47.64500045776367 C 363.2319946289062 47.76399993896484 363.1849975585938 47.84299850463867 363.1659851074219 47.88299942016602 C 363.1059875488281 47.99700164794922 363.0429992675781 48.05400085449219 362.9779968261719 48.05400085449219 C 362.9309997558594 48.05400085449219 362.8909912109375 48.02700042724609 362.8559875488281 47.97299957275391 C 362.8259887695312 47.92900085449219 362.8099975585938 47.88199996948242 362.8099975585938 47.83000183105469 C 362.8099975585938 47.76499938964844 362.843994140625 47.67499923706055 362.9119873046875 47.55799865722656 C 362.9299926757812 47.5260009765625 363.0119934082031 47.39899826049805 363.156005859375 47.17699813842773 C 363.3399963378906 46.86800003051758 363.5230102539062 46.5620002746582 363.7040100097656 46.25899887084961 C 363.7650146484375 46.15499877929688 363.9460144042969 45.82400131225586 364.2489929199219 45.26800155639648 C 364.3559875488281 45.07199859619141 364.4410095214844 44.91899871826172 364.5039978027344 44.80699920654297 C 364.5780029296875 44.67399978637695 364.6489868164062 44.5369987487793 364.7170104980469 44.39500045776367 C 364.7680053710938 44.29000091552734 364.8330078125 44.23799896240234 364.9119873046875 44.23799896240234" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_jexd0 =
    '<svg viewBox="187.5 4.5 1.0 118.0" ><path transform="translate(187.5, 4.5)" d="M 0 0 L 0 118" fill="none" stroke="#ffcc00" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" /></svg>';
const String _svg_alfhce =
    '<svg viewBox="13.0 45.6 2.9 4.2" ><path  d="M 13.00699996948242 45.57710266113281 L 13.00699996948242 49.79910278320312 L 15.9069995880127 49.79910278320312 L 15.9069995880127 49.34910583496094 L 13.5959997177124 49.34910583496094 L 13.5959997177124 47.84210968017578 L 15.60099983215332 47.84210968017578 L 15.60099983215332 47.39310455322266 L 13.5959997177124 47.39310455322266 L 13.5959997177124 46.02910614013672 L 15.87399959564209 46.02910614013672 L 15.87399959564209 45.57810974121094 L 13.00699996948242 45.57710266113281 Z" fill="#242524" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_xnrc3 =
    '<svg viewBox="10.9 105.9 13.8 13.8" ><path  d="M 23.4060001373291 116.7050018310547 C 24.17300033569336 115.5950012207031 24.625 114.2509994506836 24.625 112.802001953125 C 24.625 109.004997253418 21.5359992980957 105.9150009155273 17.73900032043457 105.9150009155273 C 15.28600025177002 105.9150009155273 13.13500022888184 107.2080001831055 11.91499996185303 109.1439971923828 C 11.90499973297119 109.1559982299805 11.89200019836426 109.1630020141602 11.88399982452393 109.1750030517578 C 11.86999988555908 109.1949996948242 11.86699962615967 109.2170028686523 11.85799980163574 109.2379989624023 C 11.22399997711182 110.2789993286133 10.85299968719482 111.4960021972656 10.85299968719482 112.802001953125 C 10.85299968719482 114.2509994506836 11.30500030517578 115.5950012207031 12.07199954986572 116.7050018310547 L 12.07800006866455 116.7200012207031 C 12.08399963378906 116.7300033569336 12.09500026702881 116.7360000610352 12.10200023651123 116.745002746582 C 13.34899997711182 118.5220031738281 15.40900039672852 119.6880035400391 17.73900032043457 119.6880035400391 C 20.05200004577637 119.6880035400391 22.09900093078613 118.5380020141602 23.34799957275391 116.7829971313477 C 23.36599922180176 116.7630004882812 23.38500022888184 116.7440032958984 23.39999961853027 116.7200012207031 L 23.4060001373291 116.7050018310547 M 22.89299964904785 115.9069976806641 C 22.05200004577637 115.4209976196289 21.15099906921387 115.0599975585938 20.2140007019043 114.8290023803711 C 20.28400039672852 114.1699981689453 20.32099914550781 113.4860000610352 20.32099914550781 112.802001953125 C 20.32099914550781 112.2620010375977 20.29700088500977 111.7229995727539 20.25300025939941 111.1959991455078 C 21.2450008392334 110.947998046875 22.19499969482422 110.552001953125 23.07799911499023 110.0179977416992 C 23.51399993896484 110.8509979248047 23.76399993896484 111.7969970703125 23.76399993896484 112.802001953125 C 23.76399993896484 113.9380035400391 23.4419994354248 114.9980010986328 22.89299964904785 115.9069976806641 M 17.73900032043457 118.8270034790039 C 17.22999954223633 118.8270034790039 16.55599975585938 117.5899963378906 16.22299957275391 115.5100021362305 C 16.72200012207031 115.4300003051758 17.22800064086914 115.3840026855469 17.73900032043457 115.3840026855469 C 18.25 115.3840026855469 18.75600051879883 115.4300003051758 19.2549991607666 115.5100021362305 C 18.92200088500977 117.5899963378906 18.24799919128418 118.8270034790039 17.73900032043457 118.8270034790039 M 17.73900032043457 114.5230026245117 C 17.19000053405762 114.5230026245117 16.64599990844727 114.5709991455078 16.11000061035156 114.6559982299805 C 16.05200004577637 114.0849990844727 16.01700019836426 113.4660034179688 16.01700019836426 112.802001953125 C 16.01700019836426 112.2990036010742 16.03800010681152 111.822998046875 16.07299995422363 111.3720016479492 C 16.6200008392334 111.4609985351562 17.17700004577637 111.5110015869141 17.73900032043457 111.5110015869141 C 18.30100059509277 111.5110015869141 18.85700035095215 111.4609985351562 19.40500068664551 111.3720016479492 C 19.44000053405762 111.822998046875 19.46100044250488 112.2990036010742 19.46100044250488 112.802001953125 C 19.46100044250488 113.4660034179688 19.42600059509277 114.0849990844727 19.36800003051758 114.6559982299805 C 18.83200073242188 114.5709991455078 18.28800010681152 114.5230026245117 17.73900032043457 114.5230026245117 M 17.73900032043457 106.7760009765625 C 18.2810001373291 106.7760009765625 19.01099967956543 108.1809997558594 19.31599998474121 110.5139999389648 C 18.79800033569336 110.6009979248047 18.27099990844727 110.6500015258789 17.73900032043457 110.6500015258789 C 17.20599937438965 110.6500015258789 16.68000030517578 110.6009979248047 16.16200065612793 110.5139999389648 C 16.46699905395508 108.1809997558594 17.19700050354004 106.7760009765625 17.73900032043457 106.7760009765625 M 22.62299919128418 109.2870025634766 C 21.85199928283691 109.7529983520508 21.02499961853027 110.1029968261719 20.16200065612793 110.3300018310547 C 19.98100090026855 108.9720001220703 19.64599990844727 107.7630004882812 19.16399955749512 106.9540023803711 C 20.57799911499023 107.2979965209961 21.79599952697754 108.140998840332 22.62299919128418 109.2870025634766 M 16.31399917602539 106.9540023803711 C 15.83199977874756 107.7630004882812 15.49699974060059 108.9720001220703 15.31599998474121 110.3300018310547 C 14.45300006866455 110.1029968261719 13.62600040435791 109.7529983520508 12.85400009155273 109.2870025634766 C 13.68200016021729 108.140998840332 14.89999961853027 107.2979965209961 16.31399917602539 106.9540023803711 M 12.39999961853027 110.0179977416992 C 13.28299999237061 110.552001953125 14.23299980163574 110.947998046875 15.22500038146973 111.1959991455078 C 15.18099975585938 111.7239990234375 15.1569995880127 112.2630004882812 15.1569995880127 112.802001953125 C 15.1569995880127 113.4860000610352 15.19400024414062 114.1699981689453 15.26399993896484 114.8290023803711 C 14.32699966430664 115.0599975585938 13.42599964141846 115.4209976196289 12.58500003814697 115.9069976806641 C 12.03600025177002 114.9980010986328 11.71300029754639 113.9380035400391 11.71300029754639 112.802001953125 C 11.71300029754639 111.7969970703125 11.96399974822998 110.8519973754883 12.39999961853027 110.0179977416992 M 13.07800006866455 116.6149978637695 C 13.80300045013428 116.2040023803711 14.57600021362305 115.8929977416992 15.37899971008301 115.6869964599609 C 15.56900024414062 116.8759994506836 15.88199996948242 117.9240036010742 16.31399917602539 118.6500015258789 C 15.02400016784668 118.3359985351562 13.89400005340576 117.6110000610352 13.07800006866455 116.6149978637695 M 19.16399955749512 118.6500015258789 C 19.59600067138672 117.9240036010742 19.90900039672852 116.8759994506836 20.09900093078613 115.6869964599609 C 20.90200042724609 115.8929977416992 21.67499923706055 116.2040023803711 22.39999961853027 116.6149978637695 C 21.58399963378906 117.6110000610352 20.45400047302246 118.3359985351562 19.16399955749512 118.6500015258789" fill="#050605" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_amb6d2 =
    '<svg viewBox="17.5 69.5 6.5 6.5" ><path  d="M 23.9419994354248 75.35700225830078 C 22.78800010681152 72.70500183105469 20.71599960327148 70.64399719238281 18.10799980163574 69.55100250244141 C 17.88999938964844 69.45999908447266 17.64299964904785 69.56800079345703 17.55500030517578 69.79199981689453 C 17.46699905395508 70.01699829101562 17.57099914550781 70.27200317382812 17.78899955749512 70.36299896240234 C 20.19300079345703 71.37000274658203 22.10300064086914 73.27100372314453 23.16699981689453 75.71600341796875 C 23.23800086975098 75.87799835205078 23.39299964904785 75.97499847412109 23.55500030517578 75.97499847412109 C 23.61300086975098 75.97499847412109 23.67200088500977 75.96199798583984 23.72800064086914 75.93599700927734 C 23.9419994354248 75.83699798583984 24.03800010681152 75.5780029296875 23.9419994354248 75.35700225830078" fill="#050605" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_nhpqyj =
    '<svg viewBox="17.3 71.9 4.3 4.3" ><path  d="M 17.56500053405762 72.70099639892578 C 19.02400016784668 73.30999755859375 20.18099975585938 74.46099853515625 20.82699966430664 75.94100189208984 C 20.89599990844727 76.09700012207031 21.04500007629395 76.19000244140625 21.20100021362305 76.19000244140625 C 21.25799942016602 76.19000244140625 21.31599998474121 76.17800140380859 21.36899948120117 76.15299987792969 C 21.57600021362305 76.05699920654297 21.66900062561035 75.80699920654297 21.57600021362305 75.59400177001953 C 20.8439998626709 73.91500091552734 19.52799987792969 72.60900115966797 17.87299919128418 71.91799926757812 C 17.66300010681152 71.83000183105469 17.42399978637695 71.93399810791016 17.33799934387207 72.15000152587891 C 17.25300025939941 72.36699676513672 17.35400009155273 72.61299896240234 17.56500053405762 72.70099639892578" fill="#050605" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_yv3xg2 =
    '<svg viewBox="10.9 69.7 12.9 12.9" ><path  d="M 21.71100044250488 77.81099700927734 C 21.47800064086914 77.58100128173828 21.21599960327148 77.46600341796875 20.95400047302246 77.46600341796875 C 20.6919994354248 77.46600341796875 20.43000030517578 77.58100128173828 20.19799995422363 77.81099700927734 C 19.84499931335449 78.16200256347656 19.49099922180176 78.51300048828125 19.14299964904785 78.86900329589844 C 19.08499908447266 78.92900085449219 19.0319995880127 78.95999908447266 18.97299957275391 78.95999908447266 C 18.93600082397461 78.95999908447266 18.89699935913086 78.947998046875 18.85199928283691 78.92299652099609 C 18.62299919128418 78.79799652099609 18.37899971008301 78.69699859619141 18.15900039672852 78.55999755859375 C 17.13400077819824 77.91500091552734 16.27499961853027 77.08599853515625 15.51399993896484 76.15299987792969 C 15.13700008392334 75.68900299072266 14.80099964141846 75.19300079345703 14.56599998474121 74.63400268554688 C 14.51799964904785 74.52100372314453 14.52700042724609 74.44699859619141 14.61900043487549 74.35500335693359 C 14.97299957275391 74.01300048828125 15.31799983978271 73.66200256347656 15.66600036621094 73.31099700927734 C 16.14999961853027 72.82399749755859 16.14999961853027 72.25299835205078 15.66300010681152 71.76300048828125 C 15.38599967956543 71.48300170898438 15.10999965667725 71.20999908447266 14.83300018310547 70.93099975585938 C 14.54800033569336 70.64499664306641 14.26599979400635 70.35700225830078 13.97700023651123 70.07499694824219 C 13.74400043487549 69.84799957275391 13.48299980163574 69.73400115966797 13.2209997177124 69.73400115966797 C 12.95899963378906 69.73400115966797 12.69699954986572 69.84799957275391 12.46399974822998 70.0780029296875 C 12.10799980163574 70.42800140380859 11.76599979400635 70.78800201416016 11.40299987792969 71.13300323486328 C 11.06799983978271 71.45099639892578 10.89799976348877 71.83999633789062 10.86200046539307 72.29499816894531 C 10.80599975585938 73.03500366210938 10.98700046539307 73.73300170898438 11.24300003051758 74.41400146484375 C 11.76599979400635 75.822998046875 12.5629997253418 77.07399749755859 13.5290002822876 78.22100067138672 C 14.83300018310547 79.77300262451172 16.39100074768066 81 18.21299934387207 81.88600158691406 C 19.03300094604492 82.28399658203125 19.88299942016602 82.59100341796875 20.8080005645752 82.64099884033203 C 20.86400032043457 82.64399719238281 20.91900062561035 82.64600372314453 20.97400093078613 82.64600372314453 C 21.54000091552734 82.64600372314453 22.0359992980957 82.47200012207031 22.43899917602539 82.01999664306641 C 22.74300003051758 81.68099975585938 23.08399963378906 81.37200164794922 23.40500068664551 81.04799652099609 C 23.88100051879883 80.56600189208984 23.88400077819824 79.98400115966797 23.4109992980957 79.50800323486328 C 22.84700012207031 78.94100189208984 22.27899932861328 78.37599945068359 21.71100044250488 77.81099700927734 M 22.79400062561035 80.44200134277344 C 22.6879997253418 80.54900360107422 22.57999992370605 80.65399932861328 22.47100067138672 80.75900268554688 C 22.24799919128418 80.97599792480469 22.01700019836426 81.19999694824219 21.79700088500977 81.44699859619141 C 21.58600044250488 81.68399810791016 21.3390007019043 81.78500366210938 20.97400093078613 81.78500366210938 C 20.93499946594238 81.78500366210938 20.89599990844727 81.78399658203125 20.85400009155273 81.78199768066406 C 20.16399955749512 81.74400329589844 19.46500015258789 81.53700256347656 18.5890007019043 81.11199951171875 C 16.89999961853027 80.29100036621094 15.41899967193604 79.13200378417969 14.1870002746582 77.66699981689453 C 13.20199966430664 76.49700164794922 12.50300025939941 75.33499908447266 12.04899978637695 74.11100006103516 C 11.78299999237061 73.40499877929688 11.68200016021729 72.86499786376953 11.7209997177124 72.36199951171875 C 11.74100017547607 72.10500335693359 11.82499980926514 71.91899871826172 11.99699974060059 71.75599670410156 C 12.22000026702881 71.54399871826172 12.4370002746582 71.32499694824219 12.65299987792969 71.10700225830078 C 12.79100036621094 70.96800231933594 12.92800045013428 70.82900238037109 13.06900024414062 70.69000244140625 C 13.14599990844727 70.61499786376953 13.20100021362305 70.59500122070312 13.2209997177124 70.59500122070312 C 13.24199962615967 70.59500122070312 13.29899978637695 70.61499786376953 13.375 70.69000244140625 C 13.5649995803833 70.875 13.75100040435791 71.06300354003906 13.9379997253418 71.25199890136719 L 14.2209997177124 71.53600311279297 C 14.36200046539307 71.67800140380859 14.50300025939941 71.81900024414062 14.64400005340576 71.95999908447266 C 14.7790002822876 72.09500122070312 14.91499996185303 72.23100280761719 15.05200004577637 72.37000274658203 C 15.21100044250488 72.52899932861328 15.20100021362305 72.55699920654297 15.05399990081787 72.70500183105469 L 14.90900039672852 72.85199737548828 C 14.61499977111816 73.14900207519531 14.32100009918213 73.44599914550781 14.01099967956543 73.74600219726562 C 13.67399978637695 74.08200073242188 13.58699989318848 74.52799987792969 13.77200031280518 74.96800231933594 C 14.01500034332275 75.54399871826172 14.35599994659424 76.09400177001953 14.84700012207031 76.69699859619141 C 15.74400043487549 77.7969970703125 16.67799949645996 78.64499664306641 17.70499992370605 79.29100036621094 C 17.87400054931641 79.39600372314453 18.04500007629395 79.48000335693359 18.19599914550781 79.55500030517578 C 18.27799987792969 79.59500122070312 18.36000061035156 79.63500213623047 18.42799949645996 79.6719970703125 C 18.60400009155273 79.77100372314453 18.78700065612793 79.82099914550781 18.97299957275391 79.82099914550781 C 19.17700004577637 79.82099914550781 19.47800064086914 79.76000213623047 19.76000022888184 79.47000122070312 C 20.10000038146973 79.12200164794922 20.44499969482422 78.77899932861328 20.80500030517578 78.4219970703125 C 20.88100051879883 78.34600067138672 20.93499946594238 78.32700347900391 20.95400047302246 78.32700347900391 C 20.97200012207031 78.32700347900391 21.02799987792969 78.34700012207031 21.10400009155273 78.4219970703125 C 21.67099952697754 78.98500061035156 22.23699951171875 79.54900360107422 22.80100059509277 80.11499786376953 C 22.93099975585938 80.24600219726562 22.94499969482422 80.28900146484375 22.79400062561035 80.44200134277344" fill="#050605" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_ijsfex =
    '<svg viewBox="10.4 89.3 13.8 9.9" ><path  d="M 22.47299957275391 89.33100128173828 L 12.14400005340576 89.33100128173828 C 11.19400024414062 89.33100128173828 10.42199993133545 90.10399627685547 10.42199993133545 91.05300140380859 L 10.42199993133545 97.50800323486328 C 10.42199993133545 98.45800018310547 11.19400024414062 99.23000335693359 12.14400005340576 99.23000335693359 L 22.47299957275391 99.23000335693359 C 23.42200088500977 99.23000335693359 24.19499969482422 98.45800018310547 24.19499969482422 97.50800323486328 L 24.19499969482422 91.05300140380859 C 24.19499969482422 90.10399627685547 23.42200088500977 89.33100128173828 22.47299957275391 89.33100128173828 M 23.33399963378906 97.50800323486328 C 23.33399963378906 97.98400115966797 22.94799995422363 98.36900329589844 22.47299957275391 98.36900329589844 L 12.14400005340576 98.36900329589844 C 11.66899967193604 98.36900329589844 11.28299999237061 97.98400115966797 11.28299999237061 97.50800323486328 L 11.28299999237061 91.05300140380859 C 11.28299999237061 90.57700347900391 11.66899967193604 90.19200134277344 12.14400005340576 90.19200134277344 L 22.47299957275391 90.19200134277344 C 22.94799995422363 90.19200134277344 23.33399963378906 90.57700347900391 23.33399963378906 91.05300140380859 L 23.33399963378906 97.50800323486328 Z" fill="#050605" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_kkwtxs =
    '<svg viewBox="12.1 91.5 10.3 4.7" ><path  d="M 22.375 91.64099884033203 C 22.22500038146973 91.45700073242188 21.95299911499023 91.43000030517578 21.76899909973145 91.58000183105469 L 17.3080005645752 95.23100280761719 L 12.8459997177124 91.58000183105469 C 12.66100025177002 91.43000030517578 12.39099979400635 91.45700073242188 12.23999977111816 91.64099884033203 C 12.09000015258789 91.82499694824219 12.11699962615967 92.09600067138672 12.30099964141846 92.24700164794922 L 17.03499984741211 96.12000274658203 C 17.11400032043457 96.18499755859375 17.21100044250488 96.21800231933594 17.3080005645752 96.21800231933594 C 17.40399932861328 96.21800231933594 17.50099945068359 96.18499755859375 17.57999992370605 96.12000274658203 L 22.31399917602539 92.24700164794922 C 22.49799919128418 92.09600067138672 22.52499961853027 91.82499694824219 22.375 91.64099884033203" fill="#050605" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_ib55m5 =
    '<svg viewBox="19.9 94.9 2.6 2.6" ><path  d="M 20.625 95.052001953125 C 20.45700073242188 94.88400268554688 20.18499946594238 94.88400268554688 20.01600074768066 95.052001953125 C 19.84799957275391 95.22000122070312 19.84799957275391 95.49199676513672 20.01600074768066 95.66100311279297 L 21.73800086975098 97.38200378417969 C 21.82200050354004 97.46600341796875 21.93199920654297 97.50800323486328 22.04199981689453 97.50800323486328 C 22.15200042724609 97.50800323486328 22.26300048828125 97.46600341796875 22.34700012207031 97.38200378417969 C 22.51499938964844 97.21399688720703 22.51499938964844 96.94200134277344 22.34700012207031 96.77400207519531 L 20.625 95.052001953125 Z" fill="#050605" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_o31au =
    '<svg viewBox="12.1 94.9 2.6 2.6" ><path  d="M 13.99100017547607 95.052001953125 L 12.26900005340576 96.77400207519531 C 12.10099983215332 96.94200134277344 12.10099983215332 97.21399688720703 12.26900005340576 97.38200378417969 C 12.35299968719482 97.46600341796875 12.46399974822998 97.50800323486328 12.57400035858154 97.50800323486328 C 12.68400001525879 97.50800323486328 12.79399967193604 97.46600341796875 12.87800025939941 97.38200378417969 L 14.60000038146973 95.66100311279297 C 14.76799964904785 95.49199676513672 14.76799964904785 95.22000122070312 14.60000038146973 95.052001953125 C 14.43200016021729 94.88400268554688 14.15900039672852 94.88400268554688 13.99100017547607 95.052001953125" fill="#050605" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_ns5j =
    '<svg viewBox="197.5 106.2 13.8 13.8" ><path  d="M 210.0299987792969 117.0169982910156 C 210.7969970703125 115.9069976806641 211.2489929199219 114.5630035400391 211.2489929199219 113.1139984130859 C 211.2489929199219 109.3170013427734 208.1600036621094 106.2269973754883 204.3630065917969 106.2269973754883 C 201.9100036621094 106.2269973754883 199.7590026855469 107.5199966430664 198.5390014648438 109.4560012817383 C 198.5290069580078 109.4680023193359 198.5160064697266 109.4749984741211 198.5079956054688 109.4869995117188 C 198.4940032958984 109.5070037841797 198.4909973144531 109.5289993286133 198.4819946289062 109.5500030517578 C 197.8480072021484 110.5910034179688 197.4770050048828 111.8079986572266 197.4770050048828 113.1139984130859 C 197.4770050048828 114.5630035400391 197.9290008544922 115.9069976806641 198.6959991455078 117.0169982910156 L 198.7019958496094 117.0319976806641 C 198.7079925537109 117.0419998168945 198.718994140625 117.0479965209961 198.7259979248047 117.056999206543 C 199.9730072021484 118.8339996337891 202.0330047607422 120 204.3630065917969 120 C 206.6759948730469 120 208.7230072021484 118.8499984741211 209.9720001220703 117.0950012207031 C 209.9900054931641 117.0749969482422 210.0090026855469 117.0559997558594 210.0240020751953 117.0319976806641 L 210.0299987792969 117.0169982910156 M 209.5169982910156 116.2190017700195 C 208.6759948730469 115.7330017089844 207.7749938964844 115.3720016479492 206.8379974365234 115.140998840332 C 206.9080047607422 114.4820022583008 206.9450073242188 113.7979965209961 206.9450073242188 113.1139984130859 C 206.9450073242188 112.5739974975586 206.9210052490234 112.0350036621094 206.8769989013672 111.5080032348633 C 207.8690032958984 111.2600021362305 208.8190002441406 110.8639984130859 209.7019958496094 110.3300018310547 C 210.1380004882812 111.1630020141602 210.3880004882812 112.109001159668 210.3880004882812 113.1139984130859 C 210.3880004882812 114.25 210.0659942626953 115.3099975585938 209.5169982910156 116.2190017700195 M 204.3630065917969 119.1389999389648 C 203.85400390625 119.1389999389648 203.1799926757812 117.9020004272461 202.8470001220703 115.8219985961914 C 203.3459930419922 115.7419967651367 203.8520050048828 115.6959991455078 204.3630065917969 115.6959991455078 C 204.8739929199219 115.6959991455078 205.3800048828125 115.7419967651367 205.8789978027344 115.8219985961914 C 205.5460052490234 117.9020004272461 204.8719940185547 119.1389999389648 204.3630065917969 119.1389999389648 M 204.3630065917969 114.8349990844727 C 203.8139953613281 114.8349990844727 203.2700042724609 114.8830032348633 202.7339935302734 114.9680023193359 C 202.6759948730469 114.3970031738281 202.6410064697266 113.7779998779297 202.6410064697266 113.1139984130859 C 202.6410064697266 112.6110000610352 202.6620025634766 112.1350021362305 202.6970062255859 111.6839981079102 C 203.2440032958984 111.7730026245117 203.8009948730469 111.822998046875 204.3630065917969 111.822998046875 C 204.9250030517578 111.822998046875 205.4810028076172 111.7730026245117 206.0290069580078 111.6839981079102 C 206.0639953613281 112.1350021362305 206.0850067138672 112.6110000610352 206.0850067138672 113.1139984130859 C 206.0850067138672 113.7779998779297 206.0500030517578 114.3970031738281 205.9920043945312 114.9680023193359 C 205.4559936523438 114.8830032348633 204.9120025634766 114.8349990844727 204.3630065917969 114.8349990844727 M 204.3630065917969 107.0879974365234 C 204.9049987792969 107.0879974365234 205.6349945068359 108.4929962158203 205.9400024414062 110.8259963989258 C 205.4219970703125 110.9130020141602 204.8950042724609 110.9619979858398 204.3630065917969 110.9619979858398 C 203.8300018310547 110.9619979858398 203.3040008544922 110.9130020141602 202.7859954833984 110.8259963989258 C 203.0910034179688 108.4929962158203 203.8209991455078 107.0879974365234 204.3630065917969 107.0879974365234 M 209.2469940185547 109.5989990234375 C 208.4759979248047 110.0650024414062 207.6490020751953 110.4150009155273 206.7859954833984 110.6419982910156 C 206.6049957275391 109.2839965820312 206.2700042724609 108.0749969482422 205.7879943847656 107.265998840332 C 207.2019958496094 107.6100006103516 208.4199981689453 108.4530029296875 209.2469940185547 109.5989990234375 M 202.9380035400391 107.265998840332 C 202.4559936523438 108.0749969482422 202.1210021972656 109.2839965820312 201.9400024414062 110.6419982910156 C 201.0769958496094 110.4150009155273 200.25 110.0650024414062 199.4779968261719 109.5989990234375 C 200.3059997558594 108.4530029296875 201.5240020751953 107.6100006103516 202.9380035400391 107.265998840332 M 199.0240020751953 110.3300018310547 C 199.9069976806641 110.8639984130859 200.8569946289062 111.2600021362305 201.8489990234375 111.5080032348633 C 201.8049926757812 112.036003112793 201.781005859375 112.5749969482422 201.781005859375 113.1139984130859 C 201.781005859375 113.7979965209961 201.8179931640625 114.4820022583008 201.8880004882812 115.140998840332 C 200.9510040283203 115.3720016479492 200.0500030517578 115.7330017089844 199.2089996337891 116.2190017700195 C 198.6600036621094 115.3099975585938 198.3370056152344 114.25 198.3370056152344 113.1139984130859 C 198.3370056152344 112.109001159668 198.5879974365234 111.1640014648438 199.0240020751953 110.3300018310547 M 199.7019958496094 116.927001953125 C 200.427001953125 116.515998840332 201.1999969482422 116.2050018310547 202.0030059814453 115.9990005493164 C 202.1929931640625 117.1880035400391 202.5059967041016 118.2360000610352 202.9380035400391 118.9619979858398 C 201.6479949951172 118.6480026245117 200.5180053710938 117.9229965209961 199.7019958496094 116.927001953125 M 205.7879943847656 118.9619979858398 C 206.2200012207031 118.2360000610352 206.5330047607422 117.1880035400391 206.7230072021484 115.9990005493164 C 207.5260009765625 116.2050018310547 208.2989959716797 116.515998840332 209.0240020751953 116.927001953125 C 208.2079925537109 117.9229965209961 207.0780029296875 118.6480026245117 205.7879943847656 118.9619979858398" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_roaowd =
    '<svg viewBox="204.1 69.8 6.5 6.5" ><path  d="M 210.5659942626953 75.66899871826172 C 209.4120025634766 73.01699829101562 207.3399963378906 70.95600128173828 204.7319946289062 69.86299896240234 C 204.5140075683594 69.77200317382812 204.2669982910156 69.87999725341797 204.1790008544922 70.10399627685547 C 204.0910034179688 70.32900238037109 204.1950073242188 70.58399963378906 204.4129943847656 70.67500305175781 C 206.8170013427734 71.68199920654297 208.7270050048828 73.58300018310547 209.7910003662109 76.02799987792969 C 209.8619995117188 76.19000244140625 210.0169982910156 76.28700256347656 210.1790008544922 76.28700256347656 C 210.2369995117188 76.28700256347656 210.2960052490234 76.27400207519531 210.3520050048828 76.24800109863281 C 210.5659942626953 76.14900207519531 210.6620025634766 75.88999938964844 210.5659942626953 75.66899871826172" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_ifuyyc =
    '<svg viewBox="203.9 72.2 4.3 4.3" ><path  d="M 204.1889953613281 73.01300048828125 C 205.6479949951172 73.62200164794922 206.8059997558594 74.77300262451172 207.4519958496094 76.25299835205078 C 207.5200042724609 76.40899658203125 207.6690063476562 76.50199890136719 207.8260040283203 76.50199890136719 C 207.8829956054688 76.50199890136719 207.9400024414062 76.48999786376953 207.9940032958984 76.46499633789062 C 208.2010040283203 76.36900329589844 208.2929992675781 76.11900329589844 208.1999969482422 75.90599822998047 C 207.4680023193359 74.22699737548828 206.1529998779297 72.92099761962891 204.4980010986328 72.23000335693359 C 204.2870025634766 72.14199829101562 204.0480041503906 72.24600219726562 203.9629974365234 72.46199798583984 C 203.8780059814453 72.67900085449219 203.97900390625 72.92500305175781 204.1889953613281 73.01300048828125" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_u8tg =
    '<svg viewBox="197.5 70.0 12.9 12.9" ><path  d="M 208.3359985351562 78.12300109863281 C 208.1029968261719 77.89299774169922 207.8410034179688 77.77799987792969 207.5789947509766 77.77799987792969 C 207.3170013427734 77.77799987792969 207.0549926757812 77.89299774169922 206.822998046875 78.12300109863281 C 206.4700012207031 78.4739990234375 206.1159973144531 78.82499694824219 205.7680053710938 79.18099975585938 C 205.7100067138672 79.24099731445312 205.6569976806641 79.27200317382812 205.5980072021484 79.27200317382812 C 205.5610046386719 79.27200317382812 205.5220031738281 79.26000213623047 205.4770050048828 79.23500061035156 C 205.2480010986328 79.11000061035156 205.0039978027344 79.00900268554688 204.7839965820312 78.87200164794922 C 203.7590026855469 78.22699737548828 202.8999938964844 77.39800262451172 202.1390075683594 76.46499633789062 C 201.7619934082031 76.00099945068359 201.4259948730469 75.50499725341797 201.1909942626953 74.94599914550781 C 201.1430053710938 74.83300018310547 201.1519927978516 74.75900268554688 201.2440032958984 74.66699981689453 C 201.5980072021484 74.32499694824219 201.9429931640625 73.9739990234375 202.2910003662109 73.62300109863281 C 202.7749938964844 73.13600158691406 202.7749938964844 72.56500244140625 202.2879943847656 72.07499694824219 C 202.0110015869141 71.79499816894531 201.7350006103516 71.52200317382812 201.4579925537109 71.24299621582031 C 201.1730041503906 70.95700073242188 200.8910064697266 70.66899871826172 200.6020050048828 70.38700103759766 C 200.3690032958984 70.16000366210938 200.1080017089844 70.04599761962891 199.8459930419922 70.04599761962891 C 199.5839996337891 70.04599761962891 199.3220062255859 70.16000366210938 199.0890045166016 70.38999938964844 C 198.7330017089844 70.73999786376953 198.3910064697266 71.09999847412109 198.0279998779297 71.44499969482422 C 197.6920013427734 71.76300048828125 197.5229949951172 72.15200042724609 197.4869995117188 72.60700225830078 C 197.4309997558594 73.34700012207031 197.6119995117188 74.04499816894531 197.8679962158203 74.72599792480469 C 198.3910064697266 76.13500213623047 199.1880035400391 77.38600158691406 200.1540069580078 78.53299713134766 C 201.4579925537109 80.08499908447266 203.0160064697266 81.31199645996094 204.8379974365234 82.197998046875 C 205.6580047607422 82.59600067138672 206.5079956054688 82.90299987792969 207.4329986572266 82.9530029296875 C 207.4889984130859 82.95600128173828 207.5440063476562 82.95800018310547 207.5989990234375 82.95800018310547 C 208.1649932861328 82.95800018310547 208.6609954833984 82.78399658203125 209.0639953613281 82.33200073242188 C 209.3679962158203 81.99299621582031 209.7089996337891 81.68399810791016 210.0299987792969 81.36000061035156 C 210.5059967041016 80.87799835205078 210.5090026855469 80.29599761962891 210.0359954833984 79.81999969482422 C 209.4720001220703 79.25299835205078 208.9040069580078 78.68800354003906 208.3359985351562 78.12300109863281 M 209.4190063476562 80.75399780273438 C 209.3130035400391 80.86100006103516 209.2050018310547 80.96600341796875 209.0959930419922 81.07099914550781 C 208.8730010986328 81.28800201416016 208.6419982910156 81.51200103759766 208.4219970703125 81.75900268554688 C 208.2109985351562 81.99600219726562 207.9640045166016 82.09700012207031 207.5989990234375 82.09700012207031 C 207.5599975585938 82.09700012207031 207.52099609375 82.09600067138672 207.47900390625 82.09400177001953 C 206.7890014648438 82.05599975585938 206.0899963378906 81.8489990234375 205.2140045166016 81.42400360107422 C 203.5249938964844 80.60299682617188 202.0440063476562 79.44400024414062 200.8119964599609 77.97899627685547 C 199.8269958496094 76.80899810791016 199.1280059814453 75.64700317382812 198.6739959716797 74.42299652099609 C 198.4080047607422 73.71700286865234 198.3070068359375 73.177001953125 198.3459930419922 72.67400360107422 C 198.3659973144531 72.41699981689453 198.4499969482422 72.23100280761719 198.6219940185547 72.06800079345703 C 198.8450012207031 71.85600280761719 199.0619964599609 71.63700103759766 199.2779998779297 71.41899871826172 C 199.4160003662109 71.27999877929688 199.5529937744141 71.14099884033203 199.6940002441406 71.00199890136719 C 199.77099609375 70.927001953125 199.8260040283203 70.90699768066406 199.8459930419922 70.90699768066406 C 199.8670043945312 70.90699768066406 199.9239959716797 70.927001953125 200 71.00199890136719 C 200.1900024414062 71.18699645996094 200.3760070800781 71.375 200.5630035400391 71.56400299072266 L 200.8459930419922 71.84799957275391 C 200.9869995117188 71.98999786376953 201.1280059814453 72.13099670410156 201.2689971923828 72.27200317382812 C 201.4040069580078 72.40699768066406 201.5399932861328 72.54299926757812 201.677001953125 72.68199920654297 C 201.8359985351562 72.84100341796875 201.8260040283203 72.86900329589844 201.6790008544922 73.01699829101562 L 201.5339965820312 73.16400146484375 C 201.2400054931641 73.46099853515625 200.9459991455078 73.75800323486328 200.6360015869141 74.05799865722656 C 200.2989959716797 74.39399719238281 200.2120056152344 74.83999633789062 200.3970031738281 75.27999877929688 C 200.6399993896484 75.85600280761719 200.9810028076172 76.40599822998047 201.4720001220703 77.00900268554688 C 202.3690032958984 78.10900115966797 203.3029937744141 78.95700073242188 204.3300018310547 79.60299682617188 C 204.4989929199219 79.70800018310547 204.6699981689453 79.79199981689453 204.8209991455078 79.86699676513672 C 204.9029998779297 79.90699768066406 204.9850006103516 79.94699859619141 205.0529937744141 79.98400115966797 C 205.22900390625 80.08300018310547 205.4120025634766 80.13300323486328 205.5980072021484 80.13300323486328 C 205.802001953125 80.13300323486328 206.1029968261719 80.07199859619141 206.3849945068359 79.78199768066406 C 206.7250061035156 79.43399810791016 207.0700073242188 79.09100341796875 207.4299926757812 78.73400115966797 C 207.5059967041016 78.65799713134766 207.5599975585938 78.63899993896484 207.5789947509766 78.63899993896484 C 207.5970001220703 78.63899993896484 207.6529998779297 78.65899658203125 207.72900390625 78.73400115966797 C 208.2960052490234 79.2969970703125 208.8619995117188 79.86100006103516 209.4259948730469 80.427001953125 C 209.5559997558594 80.55799865722656 209.5700073242188 80.60099792480469 209.4190063476562 80.75399780273438" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_or052 =
    '<svg viewBox="197.0 89.6 13.8 9.9" ><path  d="M 209.0970001220703 89.64399719238281 L 198.7680053710938 89.64399719238281 C 197.8179931640625 89.64399719238281 197.0460052490234 90.41600036621094 197.0460052490234 91.36499786376953 L 197.0460052490234 97.82099914550781 C 197.0460052490234 98.76999664306641 197.8179931640625 99.54299926757812 198.7680053710938 99.54299926757812 L 209.0970001220703 99.54299926757812 C 210.0460052490234 99.54299926757812 210.8190002441406 98.76999664306641 210.8190002441406 97.82099914550781 L 210.8190002441406 91.36499786376953 C 210.8190002441406 90.41600036621094 210.0460052490234 89.64399719238281 209.0970001220703 89.64399719238281 M 209.9579925537109 97.82099914550781 C 209.9579925537109 98.29599761962891 209.5720062255859 98.68199920654297 209.0970001220703 98.68199920654297 L 198.7680053710938 98.68199920654297 C 198.2929992675781 98.68199920654297 197.9069976806641 98.29599761962891 197.9069976806641 97.82099914550781 L 197.9069976806641 91.36499786376953 C 197.9069976806641 90.88999938964844 198.2929992675781 90.50399780273438 198.7680053710938 90.50399780273438 L 209.0970001220703 90.50399780273438 C 209.5720062255859 90.50399780273438 209.9579925537109 90.88999938964844 209.9579925537109 91.36499786376953 L 209.9579925537109 97.82099914550781 Z" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_lnrs5t =
    '<svg viewBox="198.8 91.8 10.3 4.7" ><path  d="M 209 91.9530029296875 C 208.8500061035156 91.76899719238281 208.5780029296875 91.74199676513672 208.3939971923828 91.89199829101562 L 203.9329986572266 95.54299926757812 L 199.4709930419922 91.89199829101562 C 199.2859954833984 91.74199676513672 199.0149993896484 91.76899719238281 198.8650054931641 91.9530029296875 C 198.7149963378906 92.13700103759766 198.7420043945312 92.40799713134766 198.9259948730469 92.55899810791016 L 203.6600036621094 96.43199920654297 C 203.7389984130859 96.49700164794922 203.8359985351562 96.52999877929688 203.9329986572266 96.52999877929688 C 204.0290069580078 96.52999877929688 204.1260070800781 96.49700164794922 204.2050018310547 96.43199920654297 L 208.9389953613281 92.55899810791016 C 209.1230010986328 92.40799713134766 209.1499938964844 92.13700103759766 209 91.9530029296875" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_gv1kzr =
    '<svg viewBox="206.5 95.2 2.6 2.6" ><path  d="M 207.2489929199219 95.36399841308594 C 207.0809936523438 95.19599914550781 206.8090057373047 95.19599914550781 206.6399993896484 95.36399841308594 C 206.4720001220703 95.53199768066406 206.4720001220703 95.80400085449219 206.6399993896484 95.97299957275391 L 208.3619995117188 97.69400024414062 C 208.4459991455078 97.77799987792969 208.5559997558594 97.81999969482422 208.6660003662109 97.81999969482422 C 208.7760009765625 97.81999969482422 208.8869934082031 97.77799987792969 208.9709930419922 97.69400024414062 C 209.1390075683594 97.5260009765625 209.1390075683594 97.25399780273438 208.9709930419922 97.08599853515625 L 207.2489929199219 95.36399841308594 Z" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_pustts =
    '<svg viewBox="198.8 95.2 2.6 2.6" ><path  d="M 200.6150054931641 95.36399841308594 L 198.8930053710938 97.08599853515625 C 198.7250061035156 97.25399780273438 198.7250061035156 97.5260009765625 198.8930053710938 97.69400024414062 C 198.9770050048828 97.77799987792969 199.0879974365234 97.81999969482422 199.197998046875 97.81999969482422 C 199.3079986572266 97.81999969482422 199.4179992675781 97.77799987792969 199.5019989013672 97.69400024414062 L 201.2239990234375 95.97299957275391 C 201.3919982910156 95.80400085449219 201.3919982910156 95.53199768066406 201.2239990234375 95.36399841308594 C 201.0559997558594 95.19599914550781 200.7830047607422 95.19599914550781 200.6150054931641 95.36399841308594" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_pyv499 =
    '<svg viewBox="0.0 40.6 81.1 10.0" ><path transform="translate(0.0, -252.8)" d="M 75.88474273681641 295.4244079589844 L 81.07770538330078 295.4244079589844 L 81.07770538330078 293.5283203125 L 73.76620483398438 293.5283203125 L 73.76620483398438 295.4244079589844 L 75.88474273681641 295.4244079589844 Z M 81.14710998535156 303.2200622558594 L 81.14710998535156 301.3232727050781 L 75.88474273681641 301.3232727050781 L 75.88474273681641 299.2883911132812 L 80.45461273193359 299.2883911132812 L 80.45461273193359 297.3911743164062 L 75.88474273681641 297.3911743164062 L 73.76620483398438 297.3911743164062 L 73.76620483398438 303.2200622558594 L 81.14710998535156 303.2200622558594 Z M 70.82423400878906 293.5283203125 L 68.52595520019531 293.5283203125 L 65.99197387695312 300.3544311523438 L 63.45757293701172 293.5283203125 L 61.10372161865234 293.5283203125 L 65.02284240722656 303.2900390625 L 66.90553283691406 303.2900390625 L 70.82423400878906 293.5283203125 Z M 58.06470489501953 293.5283203125 L 55.93246841430664 293.5283203125 L 55.93246841430664 303.22021484375 L 58.06470489501953 303.22021484375 L 58.06470489501953 293.5283203125 Z M 52.75561904907227 295.494384765625 L 52.75561904907227 293.5283203125 L 44.72355270385742 293.5283203125 L 44.72355270385742 295.494384765625 L 47.67339706420898 295.494384765625 L 47.67339706420898 303.2200622558594 L 49.80577087402344 303.2200622558594 L 49.80577087402344 295.494384765625 L 52.75561904907227 295.494384765625 Z M 43.72040557861328 303.2200622558594 L 39.56654357910156 293.4583740234375 L 37.60006713867188 293.4583740234375 L 33.44564437866211 303.2200622558594 L 35.61977005004883 303.2200622558594 C 37.03945922851562 299.7372741699219 37.08674240112305 299.6053771972656 38.55593109130859 296.0198669433594 C 40.05179595947266 299.6732788085938 40.02774429321289 299.6300048828125 41.49111938476562 303.2200622558594 L 43.72040557861328 303.2200622558594 Z M 25.6710033416748 295.4244079589844 L 30.86396026611328 295.4244079589844 L 30.86396026611328 293.5283203125 L 23.55301094055176 293.5283203125 L 23.55301094055176 295.4244079589844 L 25.6710033416748 295.4244079589844 Z M 30.93280792236328 303.2200622558594 L 30.93280792236328 301.3232727050781 L 25.6710033416748 301.3232727050781 L 25.6710033416748 299.2883911132812 L 30.24031257629395 299.2883911132812 L 30.24031257629395 297.3911743164062 L 25.6710033416748 297.3911743164062 L 23.55301094055176 297.3911743164062 L 23.55301094055176 303.2200622558594 L 30.93280792236328 303.2200622558594 Z M 18.02133750915527 296.8646850585938 C 18.02133750915527 297.6817626953125 17.42575645446777 298.2360229492188 16.38722038269043 298.2360229492188 L 14.22733688354492 298.2360229492188 L 14.22733688354492 295.452880859375 L 16.34574508666992 295.452880859375 C 17.38442039489746 295.452880859375 18.02133750915527 295.9234924316406 18.02133750915527 296.8369140625 L 18.02133750915527 296.8646850585938 Z M 20.47265434265137 303.2200622558594 L 18.10456466674805 299.7588500976562 C 19.33651351928711 299.3021850585938 20.18122100830078 298.3185424804688 20.18122100830078 296.75439453125 L 20.18122100830078 296.7268676757812 C 20.18122100830078 294.7323608398438 18.81088447570801 293.5283203125 16.52547073364258 293.5283203125 L 12.09441089630127 293.5283203125 L 12.09441089630127 303.2200622558594 L 14.22733688354492 303.2200622558594 L 14.22733688354492 300.1192626953125 L 15.90279102325439 300.1192626953125 L 17.97958755493164 303.2200622558594 L 20.47265434265137 303.2200622558594 Z M 8.945208549499512 301.6559143066406 L 7.588143348693848 300.2855834960938 C 6.826661109924316 300.9776611328125 6.147990226745605 301.4205932617188 5.040467262268066 301.4205932617188 C 3.378698587417603 301.4205932617188 2.229285717010498 300.0364379882812 2.229285717010498 298.3748168945312 L 2.229285717010498 298.34619140625 C 2.229285717010498 296.6844482421875 3.406210422515869 295.3277587890625 5.040467262268066 295.3277587890625 C 6.009601593017578 295.3277587890625 6.771083831787109 295.7432250976562 7.519294261932373 296.421630859375 L 8.875805854797363 294.8572998046875 C 7.976073265075684 293.9702758789062 6.881822109222412 293.3619995117188 5.054153442382812 293.3619995117188 C 2.077210426330566 293.3619995117188 0 295.6182250976562 0 298.3748168945312 L 0 298.40234375 C 0 301.1854248046875 2.118547439575195 303.3875122070312 4.971065521240234 303.3875122070312 C 6.839932441711426 303.3875122070312 7.948423385620117 302.7221069335938 8.945208549499512 301.6559143066406" fill="#00070f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_vlvtax =
    '<svg viewBox="12.1 53.7 57.0 3.6" ><path transform="translate(-75.39, -334.5)" d="M 144.4387664794922 391.6971435546875 L 144.4387664794922 388.2200317382812 L 143.6830749511719 388.2200317382812 L 143.6830749511719 390.3612670898438 L 142.053955078125 388.2200317382812 L 141.3486022949219 388.2200317382812 L 141.3486022949219 391.6971435546875 L 142.1037292480469 391.6971435546875 L 142.1037292480469 389.4861450195312 L 143.7874603271484 391.6971435546875 L 144.4387664794922 391.6971435546875 Z M 137.4654235839844 390.2422180175781 L 136.5409545898438 390.2422180175781 L 137.0032653808594 389.1139526367188 L 137.4654235839844 390.2422180175781 Z M 138.85595703125 391.6971435546875 L 137.3660278320312 388.1944580078125 L 136.6606750488281 388.1944580078125 L 135.1701965332031 391.6971435546875 L 135.9497985839844 391.6971435546875 L 136.2679138183594 390.9175720214844 L 137.7386169433594 390.9175720214844 L 138.0565795898438 391.6971435546875 L 138.85595703125 391.6971435546875 Z M 132.7774963378906 391.2049865722656 L 132.7774963378906 389.6947631835938 L 131.266845703125 389.6947631835938 L 131.266845703125 390.3562622070312 L 132.0371704101562 390.3562622070312 L 132.0371704101562 390.8524780273438 C 131.8432006835938 390.9923706054688 131.5951843261719 391.0612182617188 131.3164672851562 391.0612182617188 C 130.7006988525391 391.0612182617188 130.2637023925781 390.5946044921875 130.2637023925781 389.9586791992188 L 130.2637023925781 389.9488525390625 C 130.2637023925781 389.3571472167969 130.7056884765625 388.8659362792969 131.2624206542969 388.8659362792969 C 131.6645812988281 388.8659362792969 131.9027862548828 388.9949340820312 132.1709899902344 389.2183227539062 L 132.6533508300781 388.6365661621094 C 132.2901611328125 388.3294067382812 131.91259765625 388.1600341796875 131.2870178222656 388.1600341796875 C 130.2335510253906 388.1600341796875 129.4637756347656 388.9703063964844 129.4637756347656 389.9586791992188 L 129.4637756347656 389.9683532714844 C 129.4637756347656 390.9971923828125 130.2089385986328 391.7572937011719 131.2919921875 391.7572937011719 C 131.9278106689453 391.7572937011719 132.4195556640625 391.5081787109375 132.7774963378906 391.2049865722656 M 126.1817169189453 389.9683532714844 C 126.1817169189453 390.5650329589844 125.7543792724609 391.0513916015625 125.1386108398438 391.0513916015625 C 124.5224304199219 391.0513916015625 124.0852813720703 390.5542602539062 124.0852813720703 389.9586791992188 L 124.0852813720703 389.9488525390625 C 124.0852813720703 389.3521728515625 124.5124740600586 388.8659362792969 125.1282424926758 388.8659362792969 C 125.7441558837891 388.8659362792969 126.1817169189453 389.3630981445312 126.1817169189453 389.9586791992188 L 126.1817169189453 389.9683532714844 Z M 126.9814910888672 389.9586791992188 L 126.9814910888672 389.9488525390625 C 126.9814910888672 388.9603576660156 126.2115783691406 388.1600341796875 125.1386108398438 388.1600341796875 C 124.0650939941406 388.1600341796875 123.285514831543 388.9703063964844 123.285514831543 389.9586791992188 L 123.285514831543 389.9683532714844 C 123.285514831543 390.9568481445312 124.0556945800781 391.7572937011719 125.1282424926758 391.7572937011719 C 126.2013473510742 391.7572937011719 126.9814910888672 390.947021484375 126.9814910888672 389.9586791992188 M 121.1058502197266 391.6971435546875 L 121.1058502197266 391.002197265625 L 119.3721923828125 391.002197265625 L 119.3721923828125 388.2200317382812 L 118.6073913574219 388.2200317382812 L 118.6073913574219 391.6971435546875 L 121.1058502197266 391.6971435546875 Z M 115.9857559204102 390.66943359375 L 115.9857559204102 390.6586303710938 C 115.9857559204102 390.05322265625 115.5885620117188 389.8002319335938 114.8832092285156 389.6160888671875 C 114.282096862793 389.4615173339844 114.132926940918 389.3875427246094 114.132926940918 389.1583251953125 L 114.132926940918 389.1483764648438 C 114.132926940918 388.9801330566406 114.2870788574219 388.84619140625 114.5798873901367 388.84619140625 C 114.8732528686523 388.84619140625 115.1760177612305 388.9751586914062 115.4841842651367 389.1889038085938 L 115.8813781738281 388.6119689941406 C 115.5289764404297 388.3294067382812 115.0962524414062 388.1699829101562 114.5896987915039 388.1699829101562 C 113.879508972168 388.1699829101562 113.3729629516602 388.5872192382812 113.3729629516602 389.2183227539062 L 113.3729629516602 389.2281494140625 C 113.3729629516602 389.9192504882812 113.8249053955078 390.1122436523438 114.525276184082 390.2913208007812 C 115.1066284179688 390.4400634765625 115.226203918457 390.5394592285156 115.226203918457 390.7333984375 L 115.226203918457 390.7432250976562 C 115.226203918457 390.947021484375 115.0372161865234 391.071044921875 114.7242202758789 391.071044921875 C 114.3268814086914 391.071044921875 113.9986801147461 390.9075927734375 113.685546875 390.648681640625 L 113.2336044311523 391.190185546875 C 113.6511154174805 391.5633544921875 114.1826934814453 391.7463684082031 114.7088775634766 391.7463684082031 C 115.4590148925781 391.7463684082031 115.9857559204102 391.3595581054688 115.9857559204102 390.66943359375 M 107.0705490112305 389.4171447753906 C 107.0705490112305 389.7095336914062 106.8569488525391 389.9084777832031 106.4843597412109 389.9084777832031 L 105.7090606689453 389.9084777832031 L 105.7090606689453 388.91015625 L 106.4695739746094 388.91015625 C 106.842155456543 388.91015625 107.0705490112305 389.0795288085938 107.0705490112305 389.4073486328125 L 107.0705490112305 389.4171447753906 Z M 107.9496841430664 391.6971435546875 L 107.1005477905273 390.454833984375 C 107.5425338745117 390.2913208007812 107.8452987670898 389.9390258789062 107.8452987670898 389.3778686523438 L 107.8452987670898 389.366943359375 C 107.8452987670898 388.65234375 107.3535461425781 388.2200317382812 106.5339965820312 388.2200317382812 L 104.9441223144531 388.2200317382812 L 104.9441223144531 391.6971435546875 L 105.7090606689453 391.6971435546875 L 105.7090606689453 390.5847778320312 L 106.3105926513672 390.5847778320312 L 107.0557556152344 391.6971435546875 L 107.9496841430664 391.6971435546875 Z M 102.2088394165039 390.1820678710938 L 102.2088394165039 388.2200317382812 L 101.4434814453125 388.2200317382812 L 101.4434814453125 390.211669921875 C 101.4434814453125 390.7630004882812 101.1609039306641 391.0464172363281 100.6931991577148 391.0464172363281 C 100.2266082763672 391.0464172363281 99.94319152832031 390.7530517578125 99.94319152832031 390.1870727539062 L 99.94319152832031 388.2200317382812 L 99.17825317382812 388.2200317382812 L 99.17825317382812 390.2066955566406 C 99.17825317382812 391.2304077148438 99.74964141845703 391.7523193359375 100.6839370727539 391.7523193359375 C 101.61767578125 391.7523193359375 102.2088394165039 391.2355346679688 102.2088394165039 390.1820678710938 M 95.79664611816406 389.9683532714844 C 95.79664611816406 390.5650329589844 95.36946105957031 391.0513916015625 94.75369262695312 391.0513916015625 C 94.13778686523438 391.0513916015625 93.70022583007812 390.5542602539062 93.70022583007812 389.9586791992188 L 93.70022583007812 389.9488525390625 C 93.70022583007812 389.3521728515625 94.1275634765625 388.8659362792969 94.74373626708984 388.8659362792969 C 95.35950469970703 388.8659362792969 95.79664611816406 389.3630981445312 95.79664611816406 389.9586791992188 L 95.79664611816406 389.9683532714844 Z M 96.59656524658203 389.9586791992188 L 96.59656524658203 389.9488525390625 C 96.59656524658203 388.9603576660156 95.82665252685547 388.1600341796875 94.75369262695312 388.1600341796875 C 93.68059539794922 388.1600341796875 92.90045166015625 388.9703063964844 92.90045166015625 389.9586791992188 L 92.90045166015625 389.9683532714844 C 92.90045166015625 390.9568481445312 93.67063903808594 391.7572937011719 94.74373626708984 391.7572937011719 C 95.81683349609375 391.7572937011719 96.59656524658203 390.947021484375 96.59656524658203 389.9586791992188 M 90.92015075683594 388.2200317382812 L 90.0504150390625 388.2200317382812 L 89.20626068115234 389.6160888671875 L 88.37648010253906 388.2200317382812 L 87.48200225830078 388.2200317382812 L 88.81832885742188 390.3257141113281 L 88.81832885742188 391.6971435546875 L 89.58382415771484 391.6971435546875 L 89.58382415771484 390.3110656738281 L 90.92015075683594 388.2200317382812 Z" fill="#00070f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_iv1 =
    '<svg viewBox="14.5 0.0 52.1 30.6" ><path transform="translate(-90.51, 0.0)" d="M 128.1074523925781 0 L 142.9529113769531 19.14102745056152 C 143.0213623046875 19.24499130249023 143.09765625 19.34328651428223 143.1808776855469 19.43536186218262 C 143.6115417480469 19.90845680236816 144.2321472167969 20.2047233581543 144.9217376708984 20.2047233581543 C 146.8089904785156 20.2047233581543 147.8972930908203 18.10940361022949 146.8966369628906 16.56971168518066 C 146.8252868652344 16.45993995666504 146.7449798583984 16.35652923583984 146.6563720703125 16.26058197021484 L 139.7579345703125 7.365560531616211 L 151.1445159912109 7.365560531616211 C 154.4538269042969 7.365560531616211 157.1364135742188 10.04830646514893 157.1364135742188 13.35788059234619 C 157.1364135742188 14.60227203369141 156.7573394775391 15.75749015808105 156.1081237792969 16.71542549133301 L 146.7095947265625 28.83444595336914 C 145.779296875 29.90547180175781 144.4074401855469 30.58178901672363 142.8775634765625 30.58178901672363 C 141.3398132324219 30.58178901672363 139.9625549316406 29.89772987365723 139.0324096679688 28.81771850585938 L 134.1953125 22.58124732971191 L 129.3457641601562 28.83444595336914 C 128.4156188964844 29.90547180175781 127.0437698364258 30.58178901672363 125.5138778686523 30.58178901672363 C 123.9766845703125 30.58178901672363 122.5990219116211 29.89772987365723 121.668586730957 28.81771850585938 L 105.0309982299805 7.365560531616211 L 110.7437744140625 0 L 116.456413269043 7.365560531616211 L 125.589225769043 19.14102745056152 C 125.6576690673828 19.24499130249023 125.7338333129883 19.34328651428223 125.8176193237305 19.43536186218262 C 126.2478561401367 19.90845680236816 126.8684616088867 20.2047233581543 127.5586090087891 20.2047233581543 C 129.4447479248047 20.2047233581543 130.5335998535156 18.10940361022949 129.532958984375 16.56971168518066 C 129.4614868164062 16.45993995666504 129.3812866210938 16.35652923583984 129.2926940917969 16.26058197021484 L 122.3946838378906 7.365560531616211 L 128.1074523925781 0 Z" fill="#004c98" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_w3637r =
    '<svg viewBox="320.0 521.0 155.0 209.5" ><path transform="translate(320.0, 521.0)" d="M 17 0 L 138 0 C 147.3888397216797 0 155 8.219915390014648 155 18.35969734191895 L 155 191.1568450927734 C 155 201.2966156005859 147.3888397216797 209.5165405273438 138 209.5165405273438 L 62.31201171875 209.5165405273438 L 17 209.5165405273438 C 7.61115837097168 209.5165405273438 0 201.2966156005859 0 191.1568450927734 L 0 18.35969734191895 C 0 8.219915390014648 7.61115837097168 0 17 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_llabxp =
    '<svg viewBox="0.0 0.0 11.0 13.4" ><path transform="translate(0.0, 0.0)" d="M 0.3555223047733307 13.35853004455566 C 0.05028818547725677 13.22700595855713 -0.02455940842628479 12.99693965911865 0.006500341463834047 12.67537593841553 C 0.1513124257326126 11.17481994628906 0.2781130373477936 9.672585487365723 0.4122783541679382 8.17107105255127 C 0.54188072681427 6.721429347991943 0.6726839542388916 5.27194881439209 0.8027665615081787 3.822386741638184 C 0.8333460688591003 3.481449604034424 1.013460516929626 3.313263177871704 1.353356719017029 3.312782526016235 C 1.883533716201782 3.31206226348877 2.413711071014404 3.312622785568237 2.965741634368896 3.312622785568237 C 2.965741634368896 3.249222040176392 2.965261220932007 3.190704822540283 2.965821504592896 3.132267713546753 C 2.970064640045166 2.711600303649902 2.948690891265869 2.291253089904785 3.059961318969727 1.876189231872559 C 3.392813444137573 0.6354804635047913 4.668504238128662 -0.1849612146615982 5.936751365661621 0.03621942549943924 C 7.157206535339355 0.2489146739244461 8.032321929931641 1.251392006874084 8.075070381164551 2.49194073677063 C 8.084355354309082 2.760111570358276 8.076430320739746 3.028922080993652 8.076430320739746 3.312622785568237 L 8.241815567016602 3.312622785568237 C 8.724443435668945 3.312622785568237 9.206990242004395 3.31206226348877 9.689536094665527 3.312782526016235 C 10.02142810821533 3.313343048095703 10.2035436630249 3.468081712722778 10.23580360412598 3.796530246734619 C 10.29560279846191 4.406198024749756 10.34611511230469 5.016746520996094 10.40086841583252 5.626814365386963 C 10.48476219177246 6.561487674713135 10.56937599182129 7.496081829071045 10.65310859680176 8.430675506591797 C 10.72667694091797 9.25287914276123 10.79944229125977 10.07508182525635 10.87260818481445 10.89728450775146 C 10.92616367340088 11.49878787994385 10.96762943267822 12.10173034667969 11.03847408294678 12.70115184783936 C 11.07593727111816 13.01807308197021 10.97891712188721 13.23148918151855 10.68881130218506 13.35853004455566 L 0.3555223047733307 13.35853004455566 Z M 2.96606183052063 4.273393630981445 C 2.583898782730103 4.273393630981445 2.223029613494873 4.278597354888916 1.86240017414093 4.270431518554688 C 1.74552595615387 4.2677903175354 1.719349503517151 4.308296203613281 1.71070396900177 4.416604518890381 C 1.660351753234863 5.044603824615479 1.602315068244934 5.672042846679688 1.546039223670959 6.299561500549316 C 1.462626218795776 7.230072975158691 1.378572702407837 8.160504341125488 1.294679284095764 9.090935707092285 C 1.220151901245117 9.91754150390625 1.145224332809448 10.74406719207764 1.071017026901245 11.57067203521729 C 1.046681642532349 11.84156513214111 1.024187326431274 12.11253643035889 1.000572323799133 12.3870325088501 L 10.04368114471436 12.3870325088501 C 10.01454257965088 12.06018447875977 9.986444473266602 11.74446392059326 9.958267211914062 11.42874336242676 C 9.885180473327637 10.61070251464844 9.812414169311523 9.792662620544434 9.738847732543945 8.974701881408691 C 9.65599536895752 8.052916526794434 9.572021484375 7.131210803985596 9.48932933807373 6.209344387054443 C 9.434574127197266 5.599116802215576 9.379899978637695 4.988888740539551 9.328826904296875 4.378340721130371 C 9.321702003479004 4.293646335601807 9.28840160369873 4.268350124359131 9.20674991607666 4.271872520446777 C 9.072184562683105 4.277716636657715 8.937217712402344 4.273393630981445 8.802412033081055 4.273393630981445 L 8.078592300415039 4.273393630981445 L 8.078592300415039 4.417005062103271 C 8.078513145446777 4.65179443359375 8.082515716552734 4.886663913726807 8.077151298522949 5.121292591094971 C 8.070906639099121 5.398428440093994 7.862775325775146 5.606320858001709 7.599808216094971 5.607522010803223 C 7.34300422668457 5.608642578125 7.133590698242188 5.409075736999512 7.119902610778809 5.137302398681641 C 7.110697746276855 4.95518684387207 7.117260456085205 4.772270679473877 7.116940498352051 4.589674949645996 C 7.116701126098633 4.487129688262939 7.116860866546631 4.384504318237305 7.116860866546631 4.283159732818604 L 3.927313327789307 4.283159732818604 C 3.927313327789307 4.561736583709717 3.929954767227173 4.830707550048828 3.926512956619263 5.09959888458252 C 3.923550844192505 5.336069107055664 3.796990394592285 5.51634407043457 3.597023248672485 5.581425189971924 C 3.282423257827759 5.683890342712402 2.974947214126587 5.462069511413574 2.967342615127563 5.120011806488037 C 2.96117901802063 4.842955589294434 2.96606183052063 4.565659523010254 2.96606183052063 4.273393630981445 M 7.115180015563965 3.306538820266724 C 7.115180015563965 3.032764434814453 7.120222568511963 2.768356561660767 7.114218711853027 2.504188537597656 C 7.098449230194092 1.813109040260315 6.611579418182373 1.194555878639221 5.950839519500732 1.019164443016052 C 5.257359504699707 0.8350472450256348 4.546667098999023 1.117546916007996 4.168906688690186 1.707682132720947 C 3.84846305847168 2.208160400390625 3.943243026733398 2.759150743484497 3.927713394165039 3.306538820266724 L 7.115180015563965 3.306538820266724 Z" fill="#727272" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_wkpk4v =
    '<svg viewBox="296.0 464.0 17.5 17.5" ><path transform="translate(296.0, 464.0)" d="M 8.75 0 C 13.58249187469482 0 17.5 3.917508602142334 17.5 8.75 C 17.5 13.58249187469482 13.58249187469482 17.5 8.75 17.5 C 3.917508602142334 17.5 0 13.58249187469482 0 8.75 C 0 3.917508602142334 3.917508602142334 0 8.75 0 Z" fill="#fe4365" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_f9bi5 =
    '<svg viewBox="301.2 469.2 7.3 7.0" ><path transform="translate(253.25, 413.25)" d="M 53.31999969482422 55.99999618530273 L 53.30250549316406 55.99999618530273 C 52.60774993896484 55.99999618530273 51.99349975585938 56.36750030517578 51.64000701904297 56.90999221801758 C 51.28650665283203 56.36750030517578 50.67224884033203 55.99999618530273 49.97750854492188 55.99999618530273 L 49.95999908447266 55.99999618530273 C 48.87675476074219 56.010498046875 48.00000762939453 56.8907470703125 48.00000762939453 57.97749710083008 C 48.00000762939453 58.62499618530273 48.28350067138672 59.54374313354492 48.83650207519531 60.29974365234375 C 49.89000701904297 61.739990234375 51.64000701904297 62.99999237060547 51.64000701904297 62.99999237060547 C 51.64000701904297 62.99999237060547 53.39000701904297 61.739990234375 54.44349670410156 60.29974365234375 C 54.99650573730469 59.54374313354492 55.27999877929688 58.62499618530273 55.27999877929688 57.97749710083008 C 55.27999877929688 56.8907470703125 54.40325164794922 56.010498046875 53.31999969482422 55.99999618530273 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_yxsvr =
    '<svg viewBox="147.0 520.0 155.0 209.5" ><path transform="translate(147.0, 520.0)" d="M 17 0 L 138 0 C 147.3888397216797 0 155 8.219915390014648 155 18.35969734191895 L 155 191.1568450927734 C 155 201.2966156005859 147.3888397216797 209.5165405273438 138 209.5165405273438 L 62.31201171875 209.5165405273438 L 17 209.5165405273438 C 7.61115837097168 209.5165405273438 0 201.2966156005859 0 191.1568450927734 L 0 18.35969734191895 C 0 8.219915390014648 7.61115837097168 0 17 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_p6n =
    '<svg viewBox="152.0 706.0 7.3 10.4" ><path transform="translate(144.5, 703.0)" d="M 11.14231491088867 3 C 9.128635406494141 3 7.5 4.628635406494141 7.5 6.642315864562988 C 7.5 9.374052047729492 11.14231491088867 13.4066162109375 11.14231491088867 13.4066162109375 C 11.14231491088867 13.4066162109375 14.78463077545166 9.374052047729492 14.78463077545166 6.642315864562988 C 14.78463077545166 4.628635406494141 13.15599632263184 3 11.14231491088867 3 Z M 11.14231491088867 7.943142890930176 C 10.42425918579102 7.943142890930176 9.841487884521484 7.360371589660645 9.841487884521484 6.642315864562988 C 9.841487884521484 5.924259185791016 10.42425918579102 5.341488838195801 11.14231491088867 5.341488838195801 C 11.86037254333496 5.341488838195801 12.44314193725586 5.924259185791016 12.44314193725586 6.642315864562988 C 12.44314193725586 7.360371589660645 11.86037254333496 7.943142890930176 11.14231491088867 7.943142890930176 Z" fill="#ffd700" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_vj5mf =
    '<svg viewBox="-26.0 520.0 155.0 209.5" ><path transform="translate(-26.0, 520.0)" d="M 17 0 L 138 0 C 147.3888397216797 0 155 8.219915390014648 155 18.35969734191895 L 155 191.1568450927734 C 155 201.2966156005859 147.3888397216797 209.5165405273438 138 209.5165405273438 L 62.31201171875 209.5165405273438 L 17 209.5165405273438 C 7.61115837097168 209.5165405273438 0 201.2966156005859 0 191.1568450927734 L 0 18.35969734191895 C 0 8.219915390014648 7.61115837097168 0 17 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_oka1xd =
    '<svg viewBox="-21.0 706.0 7.3 10.4" ><path transform="translate(-28.5, 703.0)" d="M 11.14231491088867 3 C 9.128635406494141 3 7.5 4.628635406494141 7.5 6.642315864562988 C 7.5 9.374052047729492 11.14231491088867 13.4066162109375 11.14231491088867 13.4066162109375 C 11.14231491088867 13.4066162109375 14.78463077545166 9.374052047729492 14.78463077545166 6.642315864562988 C 14.78463077545166 4.628635406494141 13.15599632263184 3 11.14231491088867 3 Z M 11.14231491088867 7.943142890930176 C 10.42425918579102 7.943142890930176 9.841487884521484 7.360371589660645 9.841487884521484 6.642315864562988 C 9.841487884521484 5.924259185791016 10.42425918579102 5.341488838195801 11.14231491088867 5.341488838195801 C 11.86037254333496 5.341488838195801 12.44314193725586 5.924259185791016 12.44314193725586 6.642315864562988 C 12.44314193725586 7.360371589660645 11.86037254333496 7.943142890930176 11.14231491088867 7.943142890930176 Z" fill="#ffd700" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_u5d6pv =
    '<svg viewBox="203.0 1187.0 155.0 194.0" ><path transform="translate(203.0, 1187.0)" d="M 17 0 L 138 0 C 147.3888397216797 0 155 7.61115837097168 155 17 L 155 177 C 155 186.3888397216797 147.3888397216797 194 138 194 L 17 194 C 7.61115837097168 194 0 186.3888397216797 0 177 L 0 17 C 0 7.61115837097168 7.61115837097168 0 17 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_v0etfk =
    '<svg viewBox="211.6 1355.5 10.7 13.1" ><path transform="translate(207.07, 1354.0)" d="M 9.856934547424316 1.5 L 4.5 3.880859375 L 4.5 7.452147960662842 C 4.5 10.75559139251709 6.785625457763672 13.84475612640381 9.856934547424316 14.59472751617432 C 12.92824268341064 13.84475612640381 15.2138671875 10.75559139251709 15.2138671875 7.452147960662842 L 15.2138671875 3.880859375 L 9.856934547424316 1.5 Z M 8.666504859924316 11.02343845367432 L 6.28564453125 8.642579078674316 L 7.124897956848145 7.803325176239014 L 8.666504859924316 9.338979721069336 L 12.58897018432617 5.416513442993164 L 13.42822360992432 6.261719226837158 L 8.666504859924316 11.02343845367432 Z" fill="#077f33" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_b8ea97 =
    '<svg viewBox="18.0 1187.0 155.0 194.0" ><path transform="translate(18.0, 1187.0)" d="M 17 0 L 138 0 C 147.3888397216797 0 155 7.61115837097168 155 17 L 155 177 C 155 186.3888397216797 147.3888397216797 194 138 194 L 17 194 C 7.61115837097168 194 0 186.3888397216797 0 177 L 0 17 C 0 7.61115837097168 7.61115837097168 0 17 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_lvyzu =
    '<svg viewBox="27.5 1355.5 10.7 13.1" ><path transform="translate(23.03, 1354.0)" d="M 9.856934547424316 1.5 L 4.5 3.880859375 L 4.5 7.452147960662842 C 4.5 10.75559139251709 6.785625457763672 13.84475612640381 9.856934547424316 14.59472751617432 C 12.92824268341064 13.84475612640381 15.2138671875 10.75559139251709 15.2138671875 7.452147960662842 L 15.2138671875 3.880859375 L 9.856934547424316 1.5 Z M 8.666504859924316 11.02343845367432 L 6.28564453125 8.642579078674316 L 7.124897956848145 7.803325176239014 L 8.666504859924316 9.338979721069336 L 12.58897018432617 5.416513442993164 L 13.42822360992432 6.261719226837158 L 8.666504859924316 11.02343845367432 Z" fill="#077f33" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_lvtv =
    '<svg viewBox="18.0 1305.0 155.0 1.0" ><path transform="translate(18.0, 1305.0)" d="M 155 0 L 0 0" fill="none" stroke="#707070" stroke-width="0.20000000298023224" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_v6qxih =
    '<svg viewBox="18.0 957.0 155.0 194.0" ><path transform="translate(18.0, 957.0)" d="M 17 0 L 138 0 C 147.3888397216797 0 155 7.611157894134521 155 17 L 155 177 C 155 186.3888397216797 147.3888397216797 194 138 194 L 17 194 C 7.61115837097168 194 0 186.3888397216797 0 177 L 0 17 C 0 7.611157894134521 7.61115837097168 0 17 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_pdazp1 =
    '<svg viewBox="18.0 1073.0 155.0 1.0" ><path transform="translate(18.0, 1073.0)" d="M 155 0 L 0 0" fill="none" stroke="#707070" stroke-width="0.20000000298023224" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_k8ou4z =
    '<svg viewBox="25.0 1122.0 10.7 13.1" ><path transform="translate(20.5, 1120.5)" d="M 9.856934547424316 1.5 L 4.5 3.880859375 L 4.5 7.452147960662842 C 4.5 10.75559139251709 6.785625457763672 13.84475612640381 9.856934547424316 14.59472751617432 C 12.92824268341064 13.84475612640381 15.2138671875 10.75559139251709 15.2138671875 7.452147960662842 L 15.2138671875 3.880859375 L 9.856934547424316 1.5 Z M 8.666504859924316 11.02343845367432 L 6.28564453125 8.642579078674316 L 7.124897956848145 7.803325176239014 L 8.666504859924316 9.338979721069336 L 12.58897018432617 5.416513442993164 L 13.42822360992432 6.261719226837158 L 8.666504859924316 11.02343845367432 Z" fill="#077f33" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_ssvmij =
    '<svg viewBox="203.0 957.0 155.0 194.0" ><path transform="translate(203.0, 957.0)" d="M 17 0 L 138 0 C 147.3888397216797 0 155 7.61115837097168 155 17 L 155 177 C 155 186.3888397216797 147.3888397216797 194 138 194 L 17 194 C 7.61115837097168 194 0 186.3888397216797 0 177 L 0 17 C 0 7.61115837097168 7.61115837097168 0 17 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_gn4xvl =
    '<svg viewBox="212.5 1120.1 10.7 13.1" ><path transform="translate(208.03, 1118.59)" d="M 9.856934547424316 1.5 L 4.5 3.880859375 L 4.5 7.452147960662842 C 4.5 10.75559139251709 6.785625457763672 13.84475612640381 9.856934547424316 14.59472751617432 C 12.92824268341064 13.84475612640381 15.2138671875 10.75559139251709 15.2138671875 7.452147960662842 L 15.2138671875 3.880859375 L 9.856934547424316 1.5 Z M 8.666504859924316 11.02343845367432 L 6.28564453125 8.642579078674316 L 7.124897956848145 7.803325176239014 L 8.666504859924316 9.338979721069336 L 12.58897018432617 5.416513442993164 L 13.42822360992432 6.261719226837158 L 8.666504859924316 11.02343845367432 Z" fill="#077f33" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_yi66gh =
    '<svg viewBox="325.0 707.0 7.3 10.4" ><path transform="translate(317.5, 704.0)" d="M 11.14231491088867 3 C 9.128635406494141 3 7.5 4.628635406494141 7.5 6.642315864562988 C 7.5 9.374052047729492 11.14231491088867 13.4066162109375 11.14231491088867 13.4066162109375 C 11.14231491088867 13.4066162109375 14.78463077545166 9.374052047729492 14.78463077545166 6.642315864562988 C 14.78463077545166 4.628635406494141 13.15599632263184 3 11.14231491088867 3 Z M 11.14231491088867 7.943142890930176 C 10.42425918579102 7.943142890930176 9.841487884521484 7.360371589660645 9.841487884521484 6.642315864562988 C 9.841487884521484 5.924259185791016 10.42425918579102 5.341488838195801 11.14231491088867 5.341488838195801 C 11.86037254333496 5.341488838195801 12.44314193725586 5.924259185791016 12.44314193725586 6.642315864562988 C 12.44314193725586 7.360371589660645 11.86037254333496 7.943142890930176 11.14231491088867 7.943142890930176 Z" fill="#ffd700" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_dbt3z =
    '<svg viewBox="220.4 764.0 25.0 24.0" ><path transform="translate(172.42, 708.0)" d="M 66.23999786376953 55.99999237060547 L 66.18001556396484 55.99999237060547 C 63.79799270629883 55.99999237060547 61.69198608398438 57.26000213623047 60.47999954223633 59.11999130249023 C 59.26801300048828 57.26000213623047 57.16199111938477 55.99999237060547 54.78000259399414 55.99999237060547 L 54.71998977661133 55.99999237060547 C 51.00600051879883 56.0359992980957 48.00000381469727 59.05399703979492 48.00000381469727 62.78000640869141 C 48.00000381469727 64.99998474121094 48.97200775146484 68.14997100830078 50.86800384521484 70.74198913574219 C 54.48000335693359 75.67999267578125 60.47999954223633 79.99998474121094 60.47999954223633 79.99998474121094 C 60.47999954223633 79.99998474121094 66.48001098632812 75.67999267578125 70.09197998046875 70.74198913574219 C 71.98799133300781 68.14997100830078 72.95999908447266 64.99998474121094 72.95999908447266 62.78000640869141 C 72.95999908447266 59.05399703979492 69.95400238037109 56.0359992980957 66.23999786376953 55.99999237060547 Z" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_czb =
    '<svg viewBox="25.0 764.0 30.9 24.0" ><path transform="translate(25.0, 761.75)" d="M 15.0212574005127 8.479752540588379 L 5.143179893493652 16.61549186706543 L 5.143179893493652 25.39630126953125 C 5.143179893493652 25.8697395324707 5.526978969573975 26.2535400390625 6.000419139862061 26.2535400390625 L 12.00430965423584 26.23800277709961 C 12.47607612609863 26.23564720153809 12.85726928710938 25.85253524780273 12.85726261138916 25.38076400756836 L 12.85726261138916 20.25286483764648 C 12.85726261138916 19.7794246673584 13.24106216430664 19.3956241607666 13.71450233459473 19.3956241607666 L 17.14345932006836 19.3956241607666 C 17.61690139770508 19.3956241607666 18.00069808959961 19.7794246673584 18.00069808959961 20.25286483764648 L 18.00069808959961 25.37701225280762 C 17.9999885559082 25.60482978820801 18.08998680114746 25.82356071472168 18.25082778930664 25.98490715026855 C 18.41166877746582 26.14624977111816 18.63011932373047 26.2369327545166 18.85793876647949 26.2369327545166 L 24.85968399047852 26.2535400390625 C 25.3331241607666 26.2535400390625 25.7169246673584 25.8697395324707 25.7169246673584 25.39630126953125 L 25.7169246673584 16.60959815979004 L 15.84099102020264 8.479752540588379 C 15.60176563262939 8.286923408508301 15.26048374176025 8.286923408508301 15.0212574005127 8.479752540588379 Z M 30.62462043762207 14.00948143005371 L 26.14554595947266 10.31746006011963 L 26.14554595947266 2.896445512771606 C 26.14554595947266 2.541365146636963 25.85769653320312 2.253515958786011 25.50261497497559 2.253515958786011 L 22.50227546691895 2.253515958786011 C 22.14719772338867 2.253515958786011 21.85934829711914 2.541365146636963 21.85934829711914 2.896445512771606 L 21.85934829711914 6.786704540252686 L 17.06255722045898 2.840189218521118 C 16.11320686340332 2.058967351913452 14.74368667602539 2.058967351913452 13.79433250427246 2.840189218521118 L 0.232269823551178 14.00948143005371 C -0.04153881967067719 14.2357931137085 -0.07992671430110931 14.64126777648926 0.1465460658073425 14.91494274139404 L 1.512771248817444 16.57584381103516 C 1.62122917175293 16.70772361755371 1.777693033218384 16.79104423522949 1.947655081748962 16.80742645263672 C 2.117616891860962 16.82380867004395 2.287114858627319 16.77190971374512 2.418766260147095 16.66317558288574 L 15.0212574005127 6.283076286315918 C 15.26048374176025 6.090249538421631 15.60176563262939 6.090249538421631 15.84099292755127 6.283077239990234 L 28.44401931762695 16.66317558288574 C 28.71769332885742 16.88964653015137 29.12317085266113 16.85125923156738 29.34947967529297 16.57745170593262 L 30.7157039642334 14.91654872894287 C 30.82434844970703 14.78436374664307 30.87581825256348 14.61432647705078 30.85872268676758 14.44408130645752 C 30.84162712097168 14.27383613586426 30.75737762451172 14.1174259185791 30.6246280670166 14.00948143005371 Z" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_feo4dn =
    '<svg viewBox="119.9 764.0 24.0 24.0" ><path transform="translate(118.51, 762.56)" d="M 19.00174140930176 15.8081750869751 C 19.89999771118164 14.33287715911865 20.37506866455078 12.63889312744141 20.37495803833008 10.91165256500244 C 20.37495803833008 5.679129600524902 16.14104461669922 1.442086458206177 10.90747833251953 1.439999461174011 C 5.678608417510986 1.441565036773682 1.440000057220459 5.679130077362061 1.440000057220459 10.91061019897461 C 1.440000057220459 16.13739204406738 5.679130077362061 20.37443542480469 10.91060924530029 20.37443542480469 C 12.70539283752441 20.37443542480469 14.37756538391113 19.8673038482666 15.80660915374756 19.00069618225098 L 22.24643707275391 25.44000244140625 L 25.44000244140625 22.244873046875 L 19.00174140930176 15.8081750869751 Z M 10.90956592559814 16.76869583129883 C 7.673740386962891 16.7608699798584 5.0577392578125 14.14591312408447 5.052000045776367 10.91687107086182 C 5.056597709655762 7.6835618019104 7.676260471343994 5.063432216644287 10.90956687927246 5.058260440826416 C 14.14382743835449 5.06660795211792 16.7608699798584 7.681565761566162 16.76765251159668 10.91687107086182 C 16.7608699798584 14.14226150512695 14.14278316497803 16.7608699798584 10.90956592559814 16.76869583129883 Z" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_q1qd0a =
    '<svg viewBox="321.8 764.0 24.0 24.0" ><path transform="translate(273.84, 716.0)" d="M 60 48 C 53.79808044433594 48 48.69807434082031 52.70192718505859 48.06922912597656 58.73654174804688 C 48.02307891845703 59.15192413330078 48 59.57308197021484 48 60 C 48 60.42692565917969 48.02307891845703 60.84808349609375 48.06922912597656 61.26345825195312 C 48.69807434082031 67.29808044433594 53.79808044433594 72 60 72 C 66.62884521484375 72 72 66.62884521484375 72 60 C 72 53.37115478515625 66.62884521484375 48 60 48 Z M 67.83461761474609 66.81346130371094 C 66.52500152587891 66.31730651855469 64.40192413330078 65.59038543701172 63.08077239990234 65.19808197021484 C 62.94230651855469 65.15769958496094 62.92500305175781 65.14615631103516 62.92500305175781 64.58077239990234 C 62.92500305175781 64.11346435546875 63.11538696289062 63.64038848876953 63.30577087402344 63.23654174804688 C 63.51345825195312 62.80384826660156 63.75 62.07115173339844 63.83654022216797 61.41346740722656 C 64.07884979248047 61.13076782226562 64.41346740722656 60.57692718505859 64.62115478515625 59.51538848876953 C 64.80577087402344 58.58077239990234 64.71923828125 58.24038696289062 64.59808349609375 57.92308044433594 C 64.58654022216797 57.88845825195312 64.56923675537109 57.85385131835938 64.56346130371094 57.82500457763672 C 64.51731109619141 57.60577392578125 64.58077239990234 56.46923065185547 64.7423095703125 55.58654022216797 C 64.8519287109375 54.98077392578125 64.71346282958984 53.69422912597656 63.8826904296875 52.62692260742188 C 63.35769653320312 51.95192718505859 62.34808349609375 51.12692260742188 60.5076904296875 51.01153564453125 L 59.49807739257812 51.01153564453125 C 57.68653869628906 51.12692260742188 56.68269348144531 51.95192718505859 56.15193176269531 52.62692260742188 C 55.31538391113281 53.69422912597656 55.17692565917969 54.98077392578125 55.28654479980469 55.58654022216797 C 55.44808197021484 56.46923065185547 55.51154327392578 57.60577392578125 55.46539306640625 57.82500457763672 C 55.45384979248047 57.86538696289062 55.44231414794922 57.89423370361328 55.43077087402344 57.92884826660156 C 55.30961608886719 58.24615478515625 55.21731567382812 58.58654022216797 55.40769958496094 59.52115631103516 C 55.62115478515625 60.58269500732422 55.95000457763672 61.13654327392578 56.19231414794922 61.41923522949219 C 56.27885437011719 62.07692718505859 56.52115631103516 62.80384826660156 56.72308349609375 63.2423095703125 C 56.87307739257812 63.55961608886719 56.94231414794922 63.9923095703125 56.94231414794922 64.60385131835938 C 56.94231414794922 65.17500305175781 56.91923522949219 65.18077087402344 56.79231262207031 65.22116088867188 C 55.42500305175781 65.625 53.39423370361328 66.34039306640625 52.17692565917969 66.82500457763672 C 50.51538848876953 64.92692565917969 49.61538696289062 62.53269958496094 49.61538696289062 60 C 49.61538696289062 57.22500610351562 50.69422912597656 54.6173095703125 52.65576934814453 52.65576934814453 C 54.6173095703125 50.69422912597656 57.22500610351562 49.61538696289062 60 49.61538696289062 C 62.77500152587891 49.61538696289062 65.3826904296875 50.69422912597656 67.34423065185547 52.65576934814453 C 69.30577087402344 54.6173095703125 70.38461303710938 57.22500610351562 70.38461303710938 60 C 70.38461303710938 62.53269958496094 69.484619140625 64.92692565917969 67.83461761474609 66.81346130371094 Z" fill="#2f302f" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_u6s623 =
    '<svg viewBox="18.0 701.0 155.0 194.0" ><path transform="translate(18.0, 701.0)" d="M 17 0 L 138 0 C 147.3888397216797 0 155 7.61115837097168 155 17 L 155 177 C 155 186.3888397216797 147.3888397216797 194 138 194 L 17 194 C 7.61115837097168 194 0 186.3888397216797 0 177 L 0 17 C 0 7.61115837097168 7.61115837097168 0 17 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_w5xwkp =
    '<svg viewBox="22.0 865.0 7.3 10.4" ><path transform="translate(14.5, 862.0)" d="M 11.14231491088867 3 C 9.128635406494141 3 7.5 4.628635406494141 7.5 6.642315864562988 C 7.5 9.374052047729492 11.14231491088867 13.4066162109375 11.14231491088867 13.4066162109375 C 11.14231491088867 13.4066162109375 14.78463077545166 9.374052047729492 14.78463077545166 6.642315864562988 C 14.78463077545166 4.628635406494141 13.15599632263184 3 11.14231491088867 3 Z M 11.14231491088867 7.943142890930176 C 10.42425918579102 7.943142890930176 9.841487884521484 7.360371589660645 9.841487884521484 6.642315864562988 C 9.841487884521484 5.924259185791016 10.42425918579102 5.341488838195801 11.14231491088867 5.341488838195801 C 11.86037254333496 5.341488838195801 12.44314193725586 5.924259185791016 12.44314193725586 6.642315864562988 C 12.44314193725586 7.360371589660645 11.86037254333496 7.943142890930176 11.14231491088867 7.943142890930176 Z" fill="#ffd700" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_ta2jpn =
    '<svg viewBox="203.0 701.0 155.0 194.0" ><path transform="translate(203.0, 701.0)" d="M 17 0 L 138 0 C 147.3888397216797 0 155 7.61115837097168 155 17 L 155 177 C 155 186.3888397216797 147.3888397216797 194 138 194 L 17 194 C 7.61115837097168 194 0 186.3888397216797 0 177 L 0 17 C 0 7.61115837097168 7.61115837097168 0 17 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_mlkl0t =
    '<svg viewBox="217.0 623.0 7.3 10.4" ><path transform="translate(209.5, 620.0)" d="M 11.14231491088867 3 C 9.128635406494141 3 7.5 4.628635406494141 7.5 6.642315864562988 C 7.5 9.374052047729492 11.14231491088867 13.4066162109375 11.14231491088867 13.4066162109375 C 11.14231491088867 13.4066162109375 14.78463077545166 9.374052047729492 14.78463077545166 6.642315864562988 C 14.78463077545166 4.628635406494141 13.15599632263184 3 11.14231491088867 3 Z M 11.14231491088867 7.943142890930176 C 10.42425918579102 7.943142890930176 9.841487884521484 7.360371589660645 9.841487884521484 6.642315864562988 C 9.841487884521484 5.924259185791016 10.42425918579102 5.341488838195801 11.14231491088867 5.341488838195801 C 11.86037254333496 5.341488838195801 12.44314193725586 5.924259185791016 12.44314193725586 6.642315864562988 C 12.44314193725586 7.360371589660645 11.86037254333496 7.943142890930176 11.14231491088867 7.943142890930176 Z" fill="#ffd700" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_owdjhr =
    '<svg viewBox="20.0 86.0 330.0 50.0" ><path transform="translate(20.0, 86.0)" d="M 10.31250095367432 0 L 319.6875305175781 0 C 325.3829650878906 0 330.0000305175781 3.581721782684326 330.0000305175781 8 L 330.0000305175781 42 C 330.0000305175781 46.41827774047852 325.3829650878906 50 319.6875305175781 50 L 10.31250095367432 50 C 4.617063522338867 50 0 46.41827774047852 0 42 L 0 8 C 0 3.581721782684326 4.617063522338867 0 10.31250095367432 0 Z" fill="#ffffff" fill-opacity="0.5" stroke="none" stroke-width="1" stroke-opacity="0.5" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_px8a =
    '<svg viewBox="0.0 0.0 13.1 17.0" ><path transform="translate(0.0, 0.0)" d="M 12.58821773529053 17.01661491394043 L 0.4818284809589386 17.01661491394043 C 0.09335926175117493 16.87448310852051 -0.0366949699819088 16.59151268005371 0.008688538335263729 16.19299697875977 C 0.0393393449485302 15.92385578155518 0.03747658431529999 15.651047706604 0.05130613595247269 15.37993049621582 C 0.1105756461620331 14.21796703338623 0.1697887182235718 13.05600261688232 0.2299049198627472 11.89409351348877 C 0.3029475212097168 10.48325443267822 0.3767239451408386 9.072416305541992 0.4505567848682404 7.661574363708496 C 0.5020930171012878 6.676797866821289 0.5495650172233582 5.691738128662109 0.6085523962974548 4.707413196563721 C 0.631413459777832 4.326225280761719 0.8690560460090637 4.114491939544678 1.249171137809753 4.111952304840088 C 1.76459014415741 4.108565330505371 2.280065298080444 4.110992908477783 2.795484066009521 4.110936164855957 L 2.997790813446045 4.110936164855957 C 2.997790813446045 3.940296173095703 2.99875020980835 3.786760807037354 2.997621536254883 3.633224010467529 C 2.99372673034668 3.10053277015686 3.078284502029419 2.584323406219482 3.304016590118408 2.09899115562439 C 4.066843509674072 0.45897576212883 5.767087936401367 -0.3341630399227142 7.511474132537842 0.1319774687290192 C 8.919718742370605 0.5082540512084961 10.01332473754883 1.881161451339722 10.05978202819824 3.33603048324585 C 10.0678539276123 3.588800430297852 10.06096649169922 3.842078685760498 10.06096649169922 4.110936164855957 L 10.27501392364502 4.110936164855957 C 10.76830673217773 4.110936164855957 11.26159858703613 4.110371112823486 11.75483226776123 4.111105442047119 C 12.21578025817871 4.111782550811768 12.4388599395752 4.303476810455322 12.46448612213135 4.758159160614014 C 12.55248737335205 6.318019390106201 12.63264179229736 7.878333568572998 12.71307945251465 9.438589096069336 C 12.82947254180908 11.69602108001709 12.94344043731689 13.95356845855713 13.0585355758667 16.2110595703125 C 13.08252716064453 16.68132019042969 13.00575828552246 16.81312370300293 12.58821773529053 17.01661491394043 M 8.263125419616699 4.100662708282471 C 8.263125419616699 3.887405395507812 8.268601417541504 3.683913707733154 8.262166023254395 3.480817079544067 C 8.240206718444824 2.78838038444519 7.791621685028076 2.152616024017334 7.138301849365234 1.917569994926453 C 6.474427223205566 1.678742170333862 5.869144439697266 1.806877136230469 5.351355075836182 2.282331466674805 C 4.812736511230469 2.776921272277832 4.751660346984863 3.41934609413147 4.821429252624512 4.100662708282471 L 8.263125419616699 4.100662708282471 Z M 3.856069564819336 5.269401073455811 C 3.493622541427612 5.271997451782227 3.204105138778687 5.566030502319336 3.207548856735229 5.928082466125488 C 3.210935354232788 6.288328647613525 3.508129596710205 6.579483032226562 3.8691086769104 6.57626485824585 C 4.231105327606201 6.573047161102295 4.51768684387207 6.279409408569336 4.514525413513184 5.91493034362793 C 4.511364936828613 5.548701286315918 4.223765850067139 5.26674747467041 3.856069564819336 5.269401073455811 M 8.555465698242188 5.916680335998535 C 8.553037643432617 6.280990123748779 8.840523719787598 6.57395076751709 9.202630996704102 6.576322078704834 C 9.563442230224609 6.578692436218262 9.860071182250977 6.286521911621094 9.862610816955566 5.926332473754883 C 9.865096092224121 5.564337253570557 9.57490062713623 5.271093845367432 9.212284088134766 5.269288063049316 C 8.844982147216797 5.267481803894043 8.557892799377441 5.550451278686523 8.555465698242188 5.916680335998535" fill="#004c98" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_yoibv8 =
    '<svg viewBox="0.0 0.0 14.0 14.1" ><path transform="translate(0.0, 0.0)" d="M 12.77746200561523 7.601104736328125 C 12.68822479248047 7.543996334075928 12.62783241271973 7.518840312957764 12.58508014678955 7.475998878479004 C 10.53893756866455 5.428956508636475 8.49306583404541 3.381599903106689 6.451783180236816 1.329742312431335 C 6.276320934295654 1.153380274772644 6.087403297424316 1.076247215270996 5.838993072509766 1.077957272529602 C 4.693607807159424 1.085967540740967 3.548086643218994 1.081107378005981 2.402610778808594 1.081602573394775 C 1.590552806854248 1.08200740814209 1.080997347831726 1.594668030738831 1.080727219581604 2.411000728607178 C 1.080412268638611 3.569752216339111 1.083742499351501 4.728548526763916 1.077982306480408 5.887255191802979 C 1.076857209205627 6.111813545227051 1.151695251464844 6.283630847930908 1.309336543083191 6.441001892089844 C 2.951812505722046 8.08100414276123 4.590688705444336 9.724605560302734 6.230329036712646 11.36748695373535 C 6.455968379974365 11.5935754776001 6.506865501403809 11.80827808380127 6.390491008758545 12.03144264221191 C 6.206928253173828 12.38349151611328 5.787331104278564 12.45108318328857 5.504315376281738 12.16851806640625 C 4.665165901184082 11.33071994781494 3.828537940979004 10.49031162261963 2.990784645080566 9.651027679443359 C 2.172921657562256 8.831589698791504 1.357443571090698 8.009811401367188 0.5358904004096985 7.19415283203125 C 0.1727708429098129 6.833687782287598 -0.00282620987854898 6.407701015472412 0.0001889117993414402 5.894545078277588 C 0.007074189372360706 4.718963146209717 0.001583968172781169 3.543291330337524 0.002574007492512465 2.367663860321045 C 0.003654050873592496 1.011804699897766 1.012189507484436 0.002684156643226743 2.367509126663208 0.001469107926823199 C 3.54106616973877 0.0004340662271715701 4.71462345123291 0.005204258020967245 5.888135433197021 -0.0005559735000133514 C 6.399896144866943 -0.003076074412092566 6.824623584747314 0.1762111186981201 7.185267448425293 0.5381156802177429 C 9.386936187744141 2.74756932258606 11.59171009063721 4.953917503356934 13.7950439453125 7.161706447601318 C 14.09664821624756 7.463938236236572 14.09993171691895 7.756539821624756 13.80224418640137 8.054947853088379 C 11.87706565856934 9.984624862670898 9.950539588928223 11.91286277770996 8.026082038879395 13.84321594238281 C 7.85921573638916 14.01057720184326 7.675832271575928 14.10881519317627 7.437503337860107 14.03033256530762 C 7.042972087860107 13.90036773681641 6.920927047729492 13.43689346313477 7.207723617553711 13.13646125793457 C 7.498705863952637 12.83161926269531 7.801072120666504 12.53766822814941 8.098850250244141 12.23935127258301 C 9.595700263977051 10.73984527587891 11.09255027770996 9.24029541015625 12.59030055999756 7.741734981536865 C 12.62976741790771 7.70222282409668 12.68008041381836 7.673601627349854 12.77746200561523 7.601104736328125" fill="#004c98" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_s90m1x =
    '<svg viewBox="2.2 2.2 3.2 3.2" ><path transform="translate(-45.82, -45.89)" d="M 51.21492767333984 49.68125915527344 C 51.21199798583984 50.57328033447266 50.48535537719727 51.29479598999023 49.59085845947266 51.29389953613281 C 48.70306015014648 51.29295349121094 47.97533798217773 50.55739974975586 47.98123550415039 49.66694641113281 C 47.98712539672852 48.77397537231445 48.71309661865234 48.05322647094727 49.60584259033203 48.05398941040039 C 50.4939079284668 48.05475616455078 51.21785354614258 48.78689193725586 51.21492767333984 49.68125915527344 M 49.60390853881836 49.13457489013672 C 49.3091926574707 49.13259506225586 49.06514739990234 49.37007141113281 49.05992889404297 49.6639289855957 C 49.05452346801758 49.96490478515625 49.30032348632812 50.21443557739258 49.60075759887695 50.21295547485352 C 49.89457321166992 50.21151351928711 50.13488388061523 49.97043991088867 50.13654708862305 49.67544937133789 C 50.1381721496582 49.38334655761719 49.89515686035156 49.13655471801758 49.60390853881836 49.13457489013672" fill="#004c98" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_i4lwc =
    '<svg viewBox="336.0 17.3 22.0 11.3" ><path transform="translate(336.0, 17.33)" d="M 2.666666984558105 0 L 19.33333015441895 0 L 19.33333015441895 0 C 20.80608940124512 0 22 1.193907022476196 22 2.666666984558105 L 22 8.666666984558105 L 22 8.666666984558105 C 22 10.13943004608154 20.80608940124512 11.33333015441895 19.33333015441895 11.33333015441895 L 2.666666984558105 11.33333015441895 L 2.666666984558105 11.33333015441895 C 1.193907022476196 11.33333015441895 0 10.13943004608154 0 8.666666984558105 L 0 2.666666984558105 L 0 2.666666984558105 C 0 1.193907022476196 1.193907022476196 0 2.666666984558105 0 Z" fill="none" stroke="#000000" stroke-width="2" stroke-opacity="0.35" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_hn =
    '<svg viewBox="336.0 17.3 22.0 11.3" ><path transform="translate(0.0, 44.0)" d="M 338.6666870117188 -26.66666984558105 L 355.3333129882812 -26.66666984558105 L 355.3333129882812 -26.66666984558105 C 356.8060913085938 -26.66666984558105 358 -25.47275924682617 358 -24 L 358 -18 L 358 -18 C 358 -16.52724075317383 356.8060913085938 -15.33333015441895 355.3333129882812 -15.33333015441895 L 338.6666870117188 -15.33333015441895 L 338.6666870117188 -15.33333015441895 C 337.1939086914062 -15.33333015441895 336 -16.52724075317383 336 -18 L 336 -24 L 336 -24 C 336 -25.47275924682617 337.1939086914062 -26.66666984558105 338.6666870117188 -26.66666984558105 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tszyk4 =
    '<svg viewBox="354.0 16.0 11.3 14.0" ><path transform="translate(0.0, 44.0)" d="M 354 -28 L 365.3280029296875 -28 L 365.3280029296875 -14 L 354 -14 L 354 -28 Z" fill="#000000" fill-opacity="0.4" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_w6qqk0 =
    '<svg viewBox="359.0 21.0 1.3 4.0" ><path transform="translate(0.0, 44.0)" d="M 359 -23 L 359 -19 C 359.8046875 -19.33877944946289 360.3280029296875 -20.12686920166016 360.3280029296875 -21 C 360.3280029296875 -21.87313079833984 359.8046875 -22.66122055053711 359 -23" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_hy2fm =
    '<svg viewBox="333.0 14.3 28.0 17.3" ><path transform="translate(0.0, 44.0)" d="M 333 -29.66666984558105 L 361 -29.66666984558105 L 361 -12.33333015441895 L 333 -12.33333015441895 L 333 -29.66666984558105 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_avi4k =
    '<svg viewBox="338.0 19.3 18.0 7.3" ><path transform="translate(0.0, 44.0)" d="M 339.3333129882812 -24.66666984558105 L 354.6666870117188 -24.66666984558105 L 354.6666870117188 -24.66666984558105 C 355.4030151367188 -24.66666984558105 356 -24.06970977783203 356 -23.33333015441895 L 356 -18.66666984558105 L 356 -18.66666984558105 C 356 -17.93029022216797 355.4030151367188 -17.33333015441895 354.6666870117188 -17.33333015441895 L 339.3333129882812 -17.33333015441895 L 339.3333129882812 -17.33333015441895 C 338.5969848632812 -17.33333015441895 338 -17.93029022216797 338 -18.66666984558105 L 338 -23.33333015441895 L 338 -23.33333015441895 C 338 -24.06970977783203 338.5969848632812 -24.66666984558105 339.3333129882812 -24.66666984558105 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tav08 =
    '<svg viewBox="310.7 12.3 25.3 21.0" ><path transform="translate(0.0, 44.0)" d="M 310.6936950683594 -31.66933059692383 L 335.9660949707031 -31.66933059692383 L 335.9660949707031 -10.70376014709473 L 310.6936950683594 -10.70376014709473 L 310.6936950683594 -31.66933059692383 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_iki5el =
    '<svg viewBox="315.7 17.3 15.3 11.0" ><path transform="translate(0.0, 44.0)" d="M 323.3302917480469 -24.39200019836426 C 325.5462036132812 -24.39189910888672 327.6773986816406 -23.54047012329102 329.2832946777344 -22.01366996765137 C 329.404296875 -21.89579010009766 329.5975952148438 -21.89727973937988 329.7167053222656 -22.01700019836426 L 330.8727111816406 -23.18367004394531 C 330.9330139160156 -23.2443904876709 330.9666137695312 -23.32663917541504 330.9660949707031 -23.4122200012207 C 330.9656066894531 -23.49780082702637 330.9309997558594 -23.57965087890625 330.8699951171875 -23.63966941833496 C 326.6549072265625 -27.6792106628418 320.0050964355469 -27.6792106628418 315.7900085449219 -23.63966941833496 C 315.7289123535156 -23.5797004699707 315.6943054199219 -23.49786949157715 315.6936950683594 -23.41229057312012 C 315.6932067871094 -23.32670974731445 315.7267150878906 -23.24443054199219 315.7869873046875 -23.18367004394531 L 316.9432983398438 -22.01700019836426 C 317.0624084472656 -21.8971004486084 317.2557983398438 -21.89561080932617 317.376708984375 -22.01366996765137 C 318.9827880859375 -23.54056930541992 321.1141967773438 -24.39200973510742 323.3302917480469 -24.39200019836426 L 323.3302917480469 -24.39200019836426 Z M 323.3302917480469 -20.5963306427002 C 324.5477905273438 -20.59641075134277 325.7218933105469 -20.14388084411621 326.6242980957031 -19.32666969299316 C 326.7463989257812 -19.21068954467773 326.9386901855469 -19.21319961547852 327.0577087402344 -19.33233070373535 L 328.2123107910156 -20.49900054931641 C 328.2731018066406 -20.56019020080566 328.306884765625 -20.64320945739746 328.3059997558594 -20.7294807434082 C 328.3051147460938 -20.81574058532715 328.2697143554688 -20.89805030822754 328.2077026367188 -20.95800018310547 C 325.4595031738281 -23.51437950134277 321.2034912109375 -23.51437950134277 318.4552917480469 -20.95800018310547 C 318.393310546875 -20.89805030822754 318.3577880859375 -20.81570053100586 318.3569946289062 -20.72941017150879 C 318.356201171875 -20.64311981201172 318.3901062011719 -20.56011009216309 318.4509887695312 -20.49900054931641 L 319.6052856445312 -19.33233070373535 C 319.7243041992188 -19.21319961547852 319.9165954589844 -19.21068954467773 320.0386962890625 -19.32666969299316 C 320.9404907226562 -20.14333915710449 322.1135864257812 -20.5958309173584 323.3302917480469 -20.5963306427002 L 323.3302917480469 -20.5963306427002 Z M 325.5492858886719 -17.8120002746582 C 325.6111145019531 -17.87261009216309 325.6451110839844 -17.95601081848145 325.643310546875 -18.04250907897949 C 325.6416015625 -18.12902069091797 325.6041870117188 -18.21096992492676 325.5400085449219 -18.26899909973145 C 324.264404296875 -19.34787940979004 322.3962097167969 -19.34787940979004 321.1206970214844 -18.26899909973145 C 321.056396484375 -18.21100997924805 321.0190124511719 -18.12908935546875 321.0172119140625 -18.04258918762207 C 321.0152893066406 -17.95607948303223 321.0492858886719 -17.87265014648438 321.1109924316406 -17.8120002746582 L 323.1087036132812 -15.79633045196533 C 323.1672058105469 -15.73709011077881 323.2470092773438 -15.70376014709473 323.3302917480469 -15.70376014709473 C 323.4136047363281 -15.70376014709473 323.493408203125 -15.73709011077881 323.552001953125 -15.79633045196533 L 325.5492858886719 -17.8120002746582 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_nqpuq1 =
    '<svg viewBox="288.7 12.7 27.0 20.7" ><path transform="translate(0.0, 44.0)" d="M 288.6666870117188 -31.33333015441895 L 315.6666870117188 -31.33333015441895 L 315.6666870117188 -10.66666984558105 L 288.6666870117188 -10.66666984558105 L 288.6666870117188 -31.33333015441895 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_n4r2 =
    '<svg viewBox="293.7 17.7 17.0 10.7" ><path transform="translate(0.0, 44.0)" d="M 294.6666870117188 -19.66666984558105 L 295.6666870117188 -19.66666984558105 C 296.218994140625 -19.66666984558105 296.6666870117188 -19.21895027160645 296.6666870117188 -18.66666984558105 L 296.6666870117188 -16.66666984558105 C 296.6666870117188 -16.1143798828125 296.218994140625 -15.66666984558105 295.6666870117188 -15.66666984558105 L 294.6666870117188 -15.66666984558105 C 294.1144104003906 -15.66666984558105 293.6666870117188 -16.1143798828125 293.6666870117188 -16.66666984558105 L 293.6666870117188 -18.66666984558105 C 293.6666870117188 -19.21895027160645 294.1144104003906 -19.66666984558105 294.6666870117188 -19.66666984558105 L 294.6666870117188 -19.66666984558105 Z M 299.3333129882812 -21.66666984558105 L 300.3333129882812 -21.66666984558105 C 300.8855895996094 -21.66666984558105 301.3333129882812 -21.21895027160645 301.3333129882812 -20.66666984558105 L 301.3333129882812 -16.66666984558105 C 301.3333129882812 -16.1143798828125 300.8855895996094 -15.66666984558105 300.3333129882812 -15.66666984558105 L 299.3333129882812 -15.66666984558105 C 298.781005859375 -15.66666984558105 298.3333129882812 -16.1143798828125 298.3333129882812 -16.66666984558105 L 298.3333129882812 -20.66666984558105 C 298.3333129882812 -21.21895027160645 298.781005859375 -21.66666984558105 299.3333129882812 -21.66666984558105 Z M 304 -24 L 305 -24 C 305.5523071289062 -24 306 -23.55228042602539 306 -23 L 306 -16.66666984558105 C 306 -16.1143798828125 305.5523071289062 -15.66666984558105 305 -15.66666984558105 L 304 -15.66666984558105 C 303.4476928710938 -15.66666984558105 303 -16.1143798828125 303 -16.66666984558105 L 303 -23 C 303 -23.55228042602539 303.4476928710938 -24 304 -24 Z M 308.6666870117188 -26.33333015441895 L 309.6666870117188 -26.33333015441895 C 310.218994140625 -26.33333015441895 310.6666870117188 -25.8856201171875 310.6666870117188 -25.33333015441895 L 310.6666870117188 -16.66666984558105 C 310.6666870117188 -16.1143798828125 310.218994140625 -15.66666984558105 309.6666870117188 -15.66666984558105 L 308.6666870117188 -15.66666984558105 C 308.1144104003906 -15.66666984558105 307.6666870117188 -16.1143798828125 307.6666870117188 -16.66666984558105 L 307.6666870117188 -25.33333015441895 C 307.6666870117188 -25.8856201171875 308.1144104003906 -26.33333015441895 308.6666870117188 -26.33333015441895 L 308.6666870117188 -26.33333015441895 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_u6yej =
    '<svg viewBox="29.0 15.0 54.0 16.0" ><path transform="translate(8.0, 50.0)" d="M 21 -19 L 75 -19 L 75 -35 L 21 -35 L 21 -19 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_snrsq =
    '<svg viewBox="41.8 19.9 27.5 10.3" ><path transform="translate(29.0, 17.0)" d="M 16.43259620666504 13.2392578125 C 18.94138526916504 13.2392578125 20.43161964416504 11.27734375 20.43161964416504 7.955078125 C 20.43161964416504 6.7041015625 20.19236183166504 5.6513671875 19.73435401916504 4.837890625 C 19.07126808166504 3.5732421875 17.92966651916504 2.8896484375 16.48728370666504 2.8896484375 C 14.34079933166504 2.8896484375 12.82322120666504 4.33203125 12.82322120666504 6.35546875 C 12.82322120666504 8.255859375 14.19040870666504 9.63671875 16.07029151916504 9.63671875 C 17.22556495666504 9.63671875 18.16208839416504 9.0966796875 18.62693214416504 8.16015625 L 18.64743995666504 8.16015625 C 18.64743995666504 8.16015625 18.67478370666504 8.16015625 18.68161964416504 8.16015625 C 18.69529151916504 8.16015625 18.74314308166504 8.16015625 18.74314308166504 8.16015625 C 18.74314308166504 10.416015625 17.88865089416504 11.7626953125 16.44626808166504 11.7626953125 C 15.59861183166504 11.7626953125 14.94236183166504 11.2978515625 14.71677589416504 10.552734375 L 12.95993995666504 10.552734375 C 13.25388526916504 12.1728515625 14.62790870666504 13.2392578125 16.43259620666504 13.2392578125 Z M 16.49411964416504 8.2353515625 C 15.35935401916504 8.2353515625 14.55271339416504 7.4287109375 14.55271339416504 6.30078125 C 14.55271339416504 5.2001953125 15.40036964416504 4.359375 16.50095558166504 4.359375 C 17.60154151916504 4.359375 18.44919776916504 5.2138671875 18.44919776916504 6.328125 C 18.44919776916504 7.4287109375 17.62204933166504 8.2353515625 16.49411964416504 8.2353515625 Z M 23.53221893310547 11.9541015625 C 24.18163299560547 11.9541015625 24.62596893310547 11.4892578125 24.62596893310547 10.8740234375 C 24.62596893310547 10.251953125 24.18163299560547 9.7939453125 23.53221893310547 9.7939453125 C 22.88964080810547 9.7939453125 22.43846893310547 10.251953125 22.43846893310547 10.8740234375 C 22.43846893310547 11.4892578125 22.88964080810547 11.9541015625 23.53221893310547 11.9541015625 Z M 23.53221893310547 6.8271484375 C 24.18163299560547 6.8271484375 24.62596893310547 6.369140625 24.62596893310547 5.75390625 C 24.62596893310547 5.1318359375 24.18163299560547 4.673828125 23.53221893310547 4.673828125 C 22.88964080810547 4.673828125 22.43846893310547 5.1318359375 22.43846893310547 5.75390625 C 22.43846893310547 6.369140625 22.88964080810547 6.8271484375 23.53221893310547 6.8271484375 Z M 31.44532012939453 13 L 33.13379669189453 13 L 33.13379669189453 11.1611328125 L 34.46680450439453 11.1611328125 L 34.46680450439453 9.6708984375 L 33.13379669189453 9.6708984375 L 33.13379669189453 3.1357421875 L 30.64551544189453 3.1357421875 C 28.90235137939453 5.7607421875 27.51465606689453 7.955078125 26.62598419189453 9.5888671875 L 26.62598419189453 11.1611328125 L 31.44532012939453 11.1611328125 L 31.44532012939453 13 Z M 28.25977325439453 9.609375 C 29.40821075439453 7.5859375 30.43360137939453 5.9658203125 31.37696075439453 4.5712890625 L 31.47266387939453 4.5712890625 C 31.47266387939453 4.5712890625 31.47266387939453 6.256190299987793 31.47266387939453 7.541346549987793 C 31.47266387939453 8.826502799987793 31.47266387939453 9.7119140625 31.47266387939453 9.7119140625 L 28.25977325439453 9.7119140625 L 28.25977325439453 9.609375 Z M 38.51076507568359 13 L 40.27443695068359 13 L 40.27443695068359 3.1357421875 L 38.51760101318359 3.1357421875 L 35.94045257568359 4.9404296875 L 35.94045257568359 6.6357421875 L 38.39455413818359 4.9130859375 L 38.51076507568359 4.9130859375 L 38.51076507568359 13 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_mhz2ca =
    '<svg viewBox="0.0 70.0 375.0 44.0" ><path transform="translate(0.0, 114.0)" d="M 0 -44 L 375 -44 L 375 0 L 0 0 L 0 -44 Z" fill="#ffffff" fill-opacity="0.0" stroke="none" stroke-width="1" stroke-opacity="0.0" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_yqlrr2 =
    '<svg viewBox="20.0 235.0 14.8 21.1" ><path transform="translate(12.5, 232.0)" d="M 14.89445495605469 3 C 10.80637741088867 3 7.5 6.30637788772583 7.5 10.39445495605469 C 7.5 15.9402961730957 14.89445495605469 24.12701416015625 14.89445495605469 24.12701416015625 C 14.89445495605469 24.12701416015625 22.28890991210938 15.9402961730957 22.28890991210938 10.39445495605469 C 22.28890991210938 6.30637788772583 18.9825325012207 3 14.89445495605469 3 Z M 14.89445495605469 13.03533172607422 C 13.43669128417969 13.03533172607422 12.25357818603516 11.85221862792969 12.25357818603516 10.39445495605469 C 12.25357818603516 8.936691284179688 13.43669128417969 7.753578186035156 14.89445495605469 7.753578186035156 C 16.35221862792969 7.753578186035156 17.53533172607422 8.936691284179688 17.53533172607422 10.39445495605469 C 17.53533172607422 11.85221862792969 16.35221862792969 13.03533172607422 14.89445495605469 13.03533172607422 Z" fill="#004c98" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_cnz1c7 =
    '<svg viewBox="0.0 0.0 29.0 23.5" ><path transform="translate(0.0, 0.0)" d="M 0 13.10475158691406 L 0 11.52085971832275 C 0.06886117905378342 11.06713199615479 0.1236981973052025 10.61063289642334 0.209018886089325 10.15992832183838 C 0.7065828442573547 7.532286643981934 1.917448043823242 5.276243686676025 3.863196134567261 3.45074987411499 C 6.840014457702637 0.6580932140350342 10.36663055419922 -0.5025536417961121 14.41155433654785 0.2004182785749435 C 17.64794540405273 0.7627286314964294 20.26450157165527 2.404143810272217 22.23401641845703 5.049840927124023 C 22.31883430480957 5.163798332214355 22.40524482727051 5.276411533355713 22.53969383239746 5.454190254211426 C 22.53969383239746 5.099219799041748 22.50064277648926 4.829905033111572 22.54691505432129 4.576210498809814 C 22.69538497924805 3.762388944625854 23.20008850097656 3.169006824493408 23.88458442687988 2.77045202255249 C 24.52256011962891 2.39902138710022 25.2098274230957 2.104010105133057 25.89566802978516 1.825626134872437 C 26.57537651062012 1.549593567848206 27.22636795043945 1.263483762741089 27.68907928466797 0.6538103818893433 C 27.90137481689453 0.3741667568683624 28.26062965393066 0.4430279731750488 28.38500022888184 0.772134006023407 C 28.92194938659668 2.192437887191772 29.18404006958008 3.642385721206665 28.73661231994629 5.13852071762085 C 28.39616775512695 6.276577472686768 27.74559593200684 7.157665252685547 26.58511734008789 7.588467121124268 C 26.48476791381836 7.625752925872803 26.39474296569824 7.733999729156494 26.33511924743652 7.830993175506592 C 25.77222061157227 8.745082855224609 25.21310234069824 9.661608695983887 24.6638069152832 10.58384418487549 C 24.58621406555176 10.71426105499268 24.54682731628418 10.87658786773682 24.52457427978516 11.0291748046875 C 24.45974349975586 11.47517681121826 24.46285057067871 11.93705081939697 24.34931373596191 12.36902904510498 C 23.93051910400391 13.96249389648438 22.91288566589355 15.09441947937012 21.45160102844238 15.7876501083374 C 20.9294319152832 16.0353832244873 20.56001663208008 16.37028503417969 20.21881866455078 16.80200958251953 C 19.16616630554199 18.13388633728027 18.07891464233398 19.43695831298828 16.79314422607422 20.55586814880371 C 16.38837432861328 20.90815162658691 15.96983242034912 21.24985504150391 15.43422603607178 21.39404296875 C 14.75762271881104 21.5761890411377 14.13434505462646 21.19669723510742 14.0896692276001 20.49784088134766 C 14.06162166595459 20.05956268310547 14.10277080535889 19.57568740844727 14.26534938812256 19.17402648925781 C 14.75854682922363 17.95535087585449 15.32564353942871 16.76657104492188 15.86502933502197 15.56662273406982 C 15.90911674499512 15.4686222076416 15.96151828765869 15.37431526184082 16.01921081542969 15.2601900100708 C 15.86620426177979 15.22189712524414 15.74964332580566 15.18511486053467 15.6303129196167 15.1641206741333 C 14.58698177337646 14.98088359832764 13.77870273590088 15.55562210083008 13.6522331237793 16.59198379516602 C 13.61713027954102 16.87884902954102 13.65004920959473 17.1746997833252 13.66021060943604 17.46618461608887 C 13.6736478805542 17.85172271728516 13.73990535736084 18.24087333679199 13.70547485351562 18.62145614624023 C 13.59126567840576 19.88463973999023 13.06069850921631 20.97835731506348 12.21017932891846 21.90378379821777 C 11.16794109344482 23.03764343261719 9.859745979309082 23.56997299194336 8.31624698638916 23.47591781616211 C 6.747555732727051 23.38035202026367 5.420803070068359 22.68812942504883 4.2320237159729 21.71995735168457 C 2.062308549880981 19.95291328430176 0.8833546042442322 17.59559440612793 0.2879573106765747 14.91294574737549 C 0.1559453904628754 14.3182201385498 0.09413827955722809 13.7078742980957 0 13.10475158691406 M 15.70631217956543 19.4398136138916 C 15.73696327209473 19.45828819274902 15.76769828796387 19.47684669494629 15.79835033416748 19.49540519714355 C 19.37577438354492 15.97743797302246 22.1334114074707 11.83980464935303 24.74770164489746 7.616431713104248 C 24.27667427062988 7.326374530792236 23.84024620056152 7.057648658752441 23.39222717285156 6.781784057617188 C 23.34889602661133 6.836284637451172 23.29347038269043 6.8990159034729 23.24568748474121 6.967037200927734 C 22.045654296875 8.67764949798584 20.81060600280762 10.36508464813232 19.65650939941406 12.10618019104004 C 18.36158180236816 14.05965518951416 17.18178939819336 16.08543395996094 16.20975494384766 18.2239933013916 C 16.02828025817871 18.6230525970459 15.87342548370361 19.03420448303223 15.70631217956543 19.4398136138916 M 15.37250328063965 6.389526844024658 C 15.35973930358887 7.3089919090271 16.12846374511719 8.106605529785156 17.03407287597656 8.113407135009766 C 17.99216842651367 8.12071418762207 18.77055168151855 7.36794376373291 18.78532981872559 6.419842720031738 C 18.79977416992188 5.493576049804688 18.05145454406738 4.704527378082275 17.13786888122559 4.682693481445312 C 16.17549133300781 4.659767627716064 15.3859395980835 5.423035621643066 15.37250328063965 6.389526844024658 M 6.89787483215332 15.09945774078369 C 6.900058269500732 14.17957401275635 6.124446392059326 13.38708209991455 5.222532749176025 13.3877534866333 C 4.249322891235352 13.38859462738037 3.465396881103516 14.16059494018555 3.470183849334717 15.11348247528076 C 3.474802255630493 16.02816200256348 4.26301097869873 16.8198127746582 5.162153244018555 16.81284332275391 C 6.121170997619629 16.80537033081055 6.895523548126221 16.0410099029541 6.89787483215332 15.09945774078369 M 12.38787460327148 4.927738666534424 C 12.39753246307373 4.002647399902344 11.6387996673584 3.213011026382446 10.73058795928955 3.203101634979248 C 9.754186630249023 3.192520380020142 8.980673789978027 3.941847562789917 8.967405319213867 4.911363124847412 C 8.954809188842773 5.826461315155029 9.724878311157227 6.613241672515869 10.64022827148438 6.620463848114014 C 11.60151386260986 6.628106117248535 12.37788105010986 5.876175403594971 12.38787460327148 4.927738666534424 M 5.541309833526611 10.39985084533691 C 6.521573543548584 10.37717628479004 7.267961502075195 9.602236747741699 7.242096900939941 8.634065628051758 C 7.217827320098877 7.723754405975342 6.441207885742188 6.972243785858154 5.539462089538574 6.986268043518066 C 4.559365749359131 7.001551628112793 3.798785924911499 7.779095649719238 3.825574636459351 8.738364219665527 C 3.85160756111145 9.670425415039062 4.626631736755371 10.42101287841797 5.541309833526611 10.39985084533691" fill="#004c98" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_gmfcyn =
    '<svg viewBox="141.0 202.5 11.5 11.5" ><path transform="translate(136.5, 198.0)" d="M 14.72222232818604 4.5 L 5.777777671813965 4.5 C 5.068611145019531 4.5 4.5 5.074999809265137 4.5 5.777777671813965 L 4.5 14.72222232818604 C 4.5 15.42500019073486 5.068611145019531 16 5.777777671813965 16 L 14.72222232818604 16 C 15.43138980865479 16 16 15.42500019073486 16 14.72222232818604 L 16 5.777777671813965 C 16 5.074999809265137 15.43138980865479 4.5 14.72222232818604 4.5 Z M 8.972222328186035 13.44444465637207 L 5.777777671813965 10.25 L 6.678610801696777 9.349166870117188 L 8.972222328186035 11.63638877868652 L 13.82138919830322 6.787221908569336 L 14.72222232818604 7.69444465637207 L 8.972222328186035 13.44444465637207 Z" fill="#004c98" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_rmuu0 =
    '<svg viewBox="213.5 202.5 11.5 11.5" ><path transform="translate(209.0, 198.0)" d="M 14.72222232818604 4.5 L 5.777777671813965 4.5 C 5.068611145019531 4.5 4.5 5.074999809265137 4.5 5.777777671813965 L 4.5 14.72222232818604 C 4.5 15.42500019073486 5.068611145019531 16 5.777777671813965 16 L 14.72222232818604 16 C 15.43138980865479 16 16 15.42500019073486 16 14.72222232818604 L 16 5.777777671813965 C 16 5.074999809265137 15.43138980865479 4.5 14.72222232818604 4.5 Z M 8.972222328186035 13.44444465637207 L 5.777777671813965 10.25 L 6.678610801696777 9.349166870117188 L 8.972222328186035 11.63638877868652 L 13.82138919830322 6.787221908569336 L 14.72222232818604 7.69444465637207 L 8.972222328186035 13.44444465637207 Z" fill="#004c98" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_iufec1 =
    '<svg viewBox="3.6 9.5 16.9 8.6" ><path transform="translate(-67.54, -179.44)" d="M 88.04934692382812 190.5463104248047 C 87.89310455322266 190.8294525146484 87.75971221923828 191.1283874511719 87.57687377929688 191.3931274414062 C 86.54159545898438 192.8923950195312 85.48834991455078 194.3792724609375 84.45331573486328 195.8787384033203 C 83.67134094238281 197.0115661621094 82.60047912597656 197.5641479492188 81.2288818359375 197.5614929199219 C 79.05217742919922 197.5572662353516 76.87547302246094 197.5593872070312 74.69876861572266 197.5628051757812 C 74.57244110107422 197.5630035400391 74.49836730957031 197.5362854003906 74.43678283691406 197.4120941162109 C 73.35001373291016 195.2194213867188 72.25732421875 193.0297088623047 71.16602325439453 190.8393402099609 C 71.14580535888672 190.7987976074219 71.1268310546875 190.7577056884766 71.10399627685547 190.7099609375 C 71.83448791503906 190.0374908447266 72.57305145263672 189.3938903808594 73.54885864257812 189.1195983886719 C 75.06027221679688 188.6947631835938 76.43115234375 188.9628753662109 77.61855316162109 190.0061798095703 C 77.90036773681641 190.2537994384766 78.18743896484375 190.3589019775391 78.55812835693359 190.3518218994141 C 79.49258422851562 190.3339538574219 80.42763519287109 190.3390197753906 81.36233520507812 190.3480529785156 C 82.24132537841797 190.3565368652344 82.80770111083984 191.155029296875 82.5206298828125 191.963623046875 C 82.35208892822266 192.4383392333984 81.90351867675781 192.7460021972656 81.35415649414062 192.7494049072266 C 80.57965850830078 192.7542266845703 79.80504608154297 192.7471466064453 79.03055572509766 192.7522125244141 C 78.56741333007812 192.7552337646484 78.27706909179688 193.1568450927734 78.43582153320312 193.5680236816406 C 78.52931976318359 193.8103332519531 78.71727752685547 193.9468536376953 78.97317504882812 193.9486999511719 C 79.92123413085938 193.9555358886719 80.86968231201172 193.9647064208984 81.81734466552734 193.9442901611328 C 82.20268249511719 193.9359588623047 82.53337097167969 193.7568817138672 82.78441619873047 193.4473571777344 C 83.81060791015625 192.1822357177734 84.84096527099609 190.9205169677734 85.86641693115234 189.6547546386719 C 86.18270111083984 189.2643432617188 86.5770263671875 189.0719299316406 87.07851409912109 189.172607421875 C 87.58611297607422 189.2745361328125 87.89530944824219 189.5946197509766 88.01682281494141 190.0974578857422 C 88.02108764648438 190.1150360107422 88.03820037841797 190.1295318603516 88.04934692382812 190.1455078125 L 88.04934692382812 190.5463104248047 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_tb7ssu =
    '<svg viewBox="0.0 11.6 5.9 8.9" ><path transform="translate(0.0, -220.45)" d="M 4.043968677520752 240.9688262939453 C 3.809339046478271 240.8587799072266 3.677345275878906 240.664306640625 3.564271688461304 240.4369506835938 C 2.424400329589844 238.1450653076172 1.277904510498047 235.8565368652344 0.1334661692380905 233.5669555664062 C -0.1151152849197388 233.0696411132812 -0.02281944826245308 232.7919616699219 0.4714325368404388 232.5461273193359 C 0.6742926239967346 232.4452056884766 0.8753458857536316 232.3404083251953 1.080013036727905 232.2433013916016 C 1.760563254356384 231.9203338623047 2.428415536880493 232.1405639648438 2.767335414886475 232.81640625 C 3.774308443069458 234.8242645263672 4.777065753936768 236.8342895507812 5.774703502655029 238.8468933105469 C 6.115581035614014 239.5346221923828 5.883862972259521 240.1947021484375 5.198042869567871 240.5464172363281 C 4.920904636383057 240.6885375976562 4.642411231994629 240.8281097412109 4.364570140838623 240.9688262939453 L 4.043968677520752 240.9688262939453 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_zg7ex =
    '<svg viewBox="7.2 4.9 7.3 3.6" ><path transform="translate(-136.35, -92.21)" d="M 149.8793640136719 97.10664367675781 C 150.4411315917969 97.74252319335938 150.7545928955078 98.46894836425781 150.8070526123047 99.30337524414062 C 150.8220977783203 99.54281616210938 150.8152160644531 99.78376770019531 150.8144226074219 100.0239791870117 C 150.8128662109375 100.4680404663086 150.5780792236328 100.7058792114258 150.1363220214844 100.706428527832 C 148.8752136230469 100.7079391479492 147.6139831542969 100.7069854736328 146.3527526855469 100.7069854736328 C 145.6520690917969 100.7069854736328 144.9514007568359 100.7080917358398 144.2507781982422 100.7065277099609 C 143.7965393066406 100.7055282592773 143.5717315673828 100.4703979492188 143.5599365234375 100.0137329101562 C 143.5415649414062 99.30638122558594 143.5835723876953 98.60877227783203 143.9227905273438 97.96942901611328 C 144.0834503173828 97.66669464111328 144.283203125 97.38468933105469 144.4716033935547 97.0830078125 C 145.9483337402344 98.66342926025391 148.3788909912109 98.71974182128906 149.8793640136719 97.10664367675781" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_k1k1bd =
    '<svg viewBox="8.4 0.0 4.8 4.9" ><path transform="translate(-159.22, 0.0)" d="M 172.4793090820312 2.435449838638306 C 172.4831695556641 3.770502090454102 171.3978576660156 4.883071422576904 170.0864868164062 4.888340950012207 C 168.7596740722656 4.893611431121826 167.6312103271484 3.769146919250488 167.6320037841797 2.442676782608032 C 167.6326904296875 1.124086022377014 168.7507934570312 0.003537351731210947 170.0692749023438 -0.0001765646447893232 C 171.3814544677734 -0.003890481078997254 172.4754028320312 1.101702213287354 172.4793090820312 2.435449838638306" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_lxpd =
    '<svg viewBox="261.0 202.5 11.5 11.5" ><path transform="translate(256.5, 198.0)" d="M 14.72222232818604 4.5 L 5.777777671813965 4.5 C 5.068611145019531 4.5 4.5 5.074999809265137 4.5 5.777777671813965 L 4.5 14.72222232818604 C 4.5 15.42500019073486 5.068611145019531 16 5.777777671813965 16 L 14.72222232818604 16 C 15.43138980865479 16 16 15.42500019073486 16 14.72222232818604 L 16 5.777777671813965 C 16 5.074999809265137 15.43138980865479 4.5 14.72222232818604 4.5 Z M 8.972222328186035 13.44444465637207 L 5.777777671813965 10.25 L 6.678610801696777 9.349166870117188 L 8.972222328186035 11.63638877868652 L 13.82138919830322 6.787221908569336 L 14.72222232818604 7.69444465637207 L 8.972222328186035 13.44444465637207 Z" fill="#004c98" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
