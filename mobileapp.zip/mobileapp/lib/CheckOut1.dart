import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'package:flutter_svg/flutter_svg.dart';

class CheckOut1 extends StatelessWidget {
  const CheckOut1({
    Key key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 17.0, end: 15.0),
            Pin(size: 461.0, middle: 0.5185),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 93.0, end: 0.0),
                  child: Stack(
                    children: <Widget>[
                      Align(
                        alignment: const Alignment(1.0, 0.041),
                        child: SizedBox(
                          width: 20.0,
                          height: 20.0,
                          child: Stack(
                            children: <Widget>[
                              Container(
                                decoration: const BoxDecoration(
                                  color: Color(0x0f000000),
                                  borderRadius: BorderRadius.all(
                                      Radius.elliptical(9999.0, 9999.0)),
                                ),
                              ),
                              Center(
                                child: Container(
                                  width: 10.0,
                                  height: 10.0,
                                  decoration: BoxDecoration(
                                    color: Colors.transparent,
                                    borderRadius: const BorderRadius.all(
                                        Radius.elliptical(9999.0, 9999.0)),
                                    border: Border.all(
                                        width: 1.0, color: Colors.transparent),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 58.0),
                        Pin(size: 50.0, end: 0.0),
                        child: const Text(
                          'Pick a particular date from the calendar and order will be delivered on selected date',
                          style: TextStyle(
                            fontFamily: 'SF Pro Display',
                            fontSize: 14,
                            color: Color(0xff000000),
                            height: 1.6428571428571428,
                          ),
                          textHeightBehavior: TextHeightBehavior(
                              applyHeightToFirstAscent: false),
                        ),
                      ),
                      const Align(
                        alignment: Alignment.topLeft,
                        child: SizedBox(
                          width: 170.0,
                          height: 24.0,
                          child: Text(
                            'Nominated Delivery',
                            style: TextStyle(
                              fontFamily: 'SF Pro Display',
                              fontSize: 18,
                              color: Color(0xff000000),
                              fontWeight: FontWeight.w700,
                              height: 1.4444444444444444,
                            ),
                            textHeightBehavior: TextHeightBehavior(
                                applyHeightToFirstAscent: false),
                            softWrap: false,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 93.0, middle: 0.644),
                  child: Stack(
                    children: <Widget>[
                      Align(
                        alignment: const Alignment(1.0, 0.041),
                        child: SizedBox(
                          width: 20.0,
                          height: 20.0,
                          child: Stack(
                            children: <Widget>[
                              Container(
                                decoration: const BoxDecoration(
                                  color: Color(0x0f000000),
                                  borderRadius: BorderRadius.all(
                                      Radius.elliptical(9999.0, 9999.0)),
                                ),
                              ),
                              Center(
                                child: Container(
                                  width: 10.0,
                                  height: 10.0,
                                  decoration: BoxDecoration(
                                    color: Colors.transparent,
                                    borderRadius: const BorderRadius.all(
                                        Radius.elliptical(9999.0, 9999.0)),
                                    border: Border.all(
                                        width: 1.0, color: Colors.transparent),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 58.0),
                        Pin(size: 50.0, end: 0.0),
                        child: const Text(
                          'Go and pick up the product at the shop or agreed on location',
                          style: TextStyle(
                            fontFamily: 'SF Pro Display',
                            fontSize: 14,
                            color: Color(0xff000000),
                            height: 1.6428571428571428,
                          ),
                          textHeightBehavior: TextHeightBehavior(
                              applyHeightToFirstAscent: false),
                        ),
                      ),
                      const Align(
                        alignment: Alignment.topLeft,
                        child: SizedBox(
                          width: 58.0,
                          height: 24.0,
                          child: Text(
                            'Collect',
                            style: TextStyle(
                              fontFamily: 'SF Pro Display',
                              fontSize: 18,
                              color: Color(0xff000000),
                              fontWeight: FontWeight.w700,
                              height: 1.4444444444444444,
                            ),
                            textHeightBehavior: TextHeightBehavior(
                                applyHeightToFirstAscent: false),
                            softWrap: false,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 93.0, middle: 0.288),
                  child: Stack(
                    children: <Widget>[
                      Align(
                        alignment: const Alignment(1.0, 0.043),
                        child: SizedBox(
                          width: 24.0,
                          height: 24.0,
                          child: Stack(
                            children: <Widget>[
                              Container(
                                decoration: const BoxDecoration(
                                  color: Color(0x0f000000),
                                  borderRadius: BorderRadius.all(
                                      Radius.elliptical(9999.0, 9999.0)),
                                ),
                              ),
                              Container(
                                decoration: const BoxDecoration(
                                  color: Color(0xff004c98),
                                  borderRadius: BorderRadius.all(
                                      Radius.elliptical(9999.0, 9999.0)),
                                ),
                                margin: const EdgeInsets.all(5.0),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 58.0),
                        Pin(size: 50.0, end: 0.0),
                        child: const Text(
                          'Delivery option given  By Seller',
                          style: TextStyle(
                            fontFamily: 'SF Pro Display',
                            fontSize: 14,
                            color: Color(0xff000000),
                            height: 1.6428571428571428,
                          ),
                          textHeightBehavior: TextHeightBehavior(
                              applyHeightToFirstAscent: false),
                        ),
                      ),
                      const Align(
                        alignment: Alignment.topLeft,
                        child: SizedBox(
                          width: 151.0,
                          height: 24.0,
                          child: Text(
                            'Standard Delivery',
                            style: TextStyle(
                              fontFamily: 'SF Pro Display',
                              fontSize: 18,
                              color: Color(0xff000000),
                              fontWeight: FontWeight.w700,
                              height: 1.4444444444444444,
                            ),
                            textHeightBehavior: TextHeightBehavior(
                                applyHeightToFirstAscent: false),
                            softWrap: false,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 58.0, start: 0.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 20.0, end: 25.0),
                        Pin(size: 1.0, middle: 0.2632),
                        child: Container(
                          decoration: BoxDecoration(
                            color: const Color(0xffffffff),
                            borderRadius: BorderRadius.circular(4.0),
                            border: Border.all(
                                width: 1.0, color: const Color(0xffdddddd)),
                          ),
                        ),
                      ),
                      const Align(
                        alignment: Alignment.bottomRight,
                        child: SizedBox(
                          width: 51.0,
                          height: 16.0,
                          child: Text(
                            'Payments',
                            style: TextStyle(
                              fontFamily: 'SF Pro Display',
                              fontSize: 12,
                              color: Color(0x80000000),
                            ),
                            textAlign: TextAlign.right,
                            softWrap: false,
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: const Offset(303.0, 0.0),
                        child: SizedBox(
                          width: 30.0,
                          height: 30.0,
                          child: Stack(
                            children: <Widget>[
                              Container(
                                width: 30.0,
                                height: 30.0,
                                decoration: BoxDecoration(
                                  color: const Color(0xffffffff),
                                  borderRadius: const BorderRadius.all(
                                      Radius.elliptical(9999.0, 9999.0)),
                                  border: Border.all(
                                      width: 1.0,
                                      color: const Color(0xffdddddd)),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const Align(
                        alignment: Alignment(0.003, 1.0),
                        child: SizedBox(
                          width: 42.0,
                          height: 16.0,
                          child: Text(
                            'Address',
                            style: TextStyle(
                              fontFamily: 'SF Pro Display',
                              fontSize: 12,
                              color: Color(0x80000000),
                            ),
                            textAlign: TextAlign.center,
                            softWrap: false,
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: const Offset(157.0, 0.0),
                        child: SizedBox(
                          width: 30.0,
                          height: 30.0,
                          child: Stack(
                            children: <Widget>[
                              Container(
                                width: 30.0,
                                height: 30.0,
                                decoration: BoxDecoration(
                                  color: const Color(0xffffffff),
                                  borderRadius: const BorderRadius.all(
                                      Radius.elliptical(9999.0, 9999.0)),
                                  border: Border.all(
                                      width: 1.0,
                                      color: const Color(0xffdddddd)),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const Align(
                        alignment: Alignment.bottomLeft,
                        child: SizedBox(
                          width: 43.0,
                          height: 16.0,
                          child: Text(
                            'Delivery',
                            style: TextStyle(
                              fontFamily: 'SF Pro Display',
                              fontSize: 12,
                              color: Color(0xff000000),
                            ),
                            softWrap: false,
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: const Offset(5.0, 0.0),
                        child: SizedBox(
                          width: 30.0,
                          height: 30.0,
                          child: Stack(
                            children: <Widget>[
                              Container(
                                width: 30.0,
                                height: 30.0,
                                decoration: BoxDecoration(
                                  color: const Color(0xffffffff),
                                  borderRadius: const BorderRadius.all(
                                      Radius.elliptical(9999.0, 9999.0)),
                                  border: Border.all(
                                      width: 1.0,
                                      color: const Color(0xff004c98)),
                                ),
                              ),
                              Container(
                                decoration: const BoxDecoration(
                                  color: Color(0xff004c98),
                                  borderRadius: BorderRadius.all(
                                      Radius.elliptical(9999.0, 9999.0)),
                                ),
                                margin: const EdgeInsets.all(7.0),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(),
          Pinned.fromPins(
            Pin(size: 92.0, middle: 0.5018),
            Pin(size: 23.0, start: 126.0),
            child: const Text(
              'CHECK OUT',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 17,
                color: Color(0xff004c98),
                fontWeight: FontWeight.w700,
                height: 0.7058823529411765,
              ),
              textHeightBehavior:
                  TextHeightBehavior(applyHeightToFirstAscent: false),
              softWrap: false,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 117.0, start: 17.0),
            Pin(size: 24.0, end: 125.0),
            child: const Text(
              'Contact Seller',
              style: TextStyle(
                fontFamily: 'SF Pro Display',
                fontSize: 18,
                color: Color(0xff000000),
                fontWeight: FontWeight.w700,
                height: 1.2777777777777777,
              ),
              textHeightBehavior:
                  TextHeightBehavior(applyHeightToFirstAscent: false),
              softWrap: false,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 119.0, start: 0.0),
            child: Stack(
              children: <Widget>[
                SizedBox.expand(
                    child: SvgPicture.string(
                  _svg_jzx0na,
                  allowDrawingOutsideViewBox: true,
                  fit: BoxFit.fill,
                )),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 44.0, start: 0.0),
                  child: Stack(
                    children: <Widget>[
                      SizedBox.expand(
                          child: SvgPicture.string(
                        _svg_mhz2ca,
                        allowDrawingOutsideViewBox: true,
                        fit: BoxFit.fill,
                      )),
                      Pinned.fromPins(
                        Pin(start: 20.0, end: 14.7),
                        Pin(size: 16.0, middle: 0.5357),
                        child: Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(size: 24.3, end: 0.0),
                              Pin(start: 2.3, end: 2.3),
                              child: Stack(
                                children: <Widget>[
                                  Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(0.0, 0.0, 2.3, 0.0),
                                    child: Stack(
                                      children: <Widget>[
                                        SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_i4lwc,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                        SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_hn,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                      ],
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.centerRight,
                                    child: SizedBox(
                                      width: 1.0,
                                      height: 4.0,
                                      child: Stack(
                                        children: <Widget>[
                                          Padding(
                                            padding: const EdgeInsets.all(-5.0),
                                            child: SizedBox.expand(
                                                child: SvgPicture.string(
                                              _svg_tszyk4,
                                              allowDrawingOutsideViewBox: true,
                                              fit: BoxFit.fill,
                                            )),
                                          ),
                                          SizedBox.expand(
                                              child: SvgPicture.string(
                                            _svg_w6qqk0,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          )),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 18.0, start: 2.0),
                                    Pin(size: 7.3, middle: 0.5),
                                    child: Stack(
                                      children: <Widget>[
                                        Padding(
                                          padding: const EdgeInsets.all(-5.0),
                                          child: SizedBox.expand(
                                              child: SvgPicture.string(
                                            _svg_hy2fm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          )),
                                        ),
                                        SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_avi4k,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 15.3, end: 29.4),
                              Pin(size: 11.0, start: 2.3),
                              child: Stack(
                                children: <Widget>[
                                  Stack(
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.all(-5.0),
                                        child: SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_tav08,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                      ),
                                      SizedBox.expand(
                                          child: SvgPicture.string(
                                        _svg_iki5el,
                                        allowDrawingOutsideViewBox: true,
                                        fit: BoxFit.fill,
                                      )),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 17.0, end: 49.7),
                              Pin(size: 10.7, middle: 0.5),
                              child: Stack(
                                children: <Widget>[
                                  Stack(
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.all(-5.0),
                                        child: SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_nqpuq1,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                      ),
                                      SizedBox.expand(
                                          child: SvgPicture.string(
                                        _svg_n4r2,
                                        allowDrawingOutsideViewBox: true,
                                        fit: BoxFit.fill,
                                      )),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 54.0, start: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child: Stack(
                                children: <Widget>[
                                  SizedBox.expand(
                                      child: SvgPicture.string(
                                    _svg_u6yej,
                                    allowDrawingOutsideViewBox: true,
                                    fit: BoxFit.fill,
                                  )),
                                  Pinned.fromPins(
                                    Pin(start: 12.8, end: 13.7),
                                    Pin(size: 10.3, end: 0.8),
                                    child: SvgPicture.string(
                                      _svg_snrsq,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Container(),
                Container(),
                Container(),
                Align(
                  alignment: const Alignment(-0.099, 0.255),
                  child: SizedBox(
                    width: 81.0,
                    height: 57.0,
                    child: Stack(
                      children: <Widget>[
                        Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(size: 10.0, end: 6.7),
                              child: SvgPicture.string(
                                _svg_pyv499,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(start: 12.1, end: 12.1),
                              Pin(size: 3.6, end: 0.0),
                              child: SvgPicture.string(
                                _svg_vlvtax,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(start: 14.5, end: 14.5),
                              Pin(size: 30.6, start: 0.0),
                              child: SvgPicture.string(
                                _svg_iv1,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Container(
                              decoration: const BoxDecoration(),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_i4lwc =
    '<svg viewBox="336.0 17.3 22.0 11.3" ><path transform="translate(336.0, 17.33)" d="M 2.666666984558105 0 L 19.33333015441895 0 L 19.33333015441895 0 C 20.80608940124512 0 22 1.193907022476196 22 2.666666984558105 L 22 8.666666984558105 L 22 8.666666984558105 C 22 10.13943004608154 20.80608940124512 11.33333015441895 19.33333015441895 11.33333015441895 L 2.666666984558105 11.33333015441895 L 2.666666984558105 11.33333015441895 C 1.193907022476196 11.33333015441895 0 10.13943004608154 0 8.666666984558105 L 0 2.666666984558105 L 0 2.666666984558105 C 0 1.193907022476196 1.193907022476196 0 2.666666984558105 0 Z" fill="none" stroke="#000000" stroke-width="2" stroke-opacity="0.35" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_hn =
    '<svg viewBox="336.0 17.3 22.0 11.3" ><path transform="translate(0.0, 44.0)" d="M 338.6666870117188 -26.66666984558105 L 355.3333129882812 -26.66666984558105 L 355.3333129882812 -26.66666984558105 C 356.8060913085938 -26.66666984558105 358 -25.47275924682617 358 -24 L 358 -18 L 358 -18 C 358 -16.52724075317383 356.8060913085938 -15.33333015441895 355.3333129882812 -15.33333015441895 L 338.6666870117188 -15.33333015441895 L 338.6666870117188 -15.33333015441895 C 337.1939086914062 -15.33333015441895 336 -16.52724075317383 336 -18 L 336 -24 L 336 -24 C 336 -25.47275924682617 337.1939086914062 -26.66666984558105 338.6666870117188 -26.66666984558105 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tszyk4 =
    '<svg viewBox="354.0 16.0 11.3 14.0" ><path transform="translate(0.0, 44.0)" d="M 354 -28 L 365.3280029296875 -28 L 365.3280029296875 -14 L 354 -14 L 354 -28 Z" fill="#000000" fill-opacity="0.4" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_w6qqk0 =
    '<svg viewBox="359.0 21.0 1.3 4.0" ><path transform="translate(0.0, 44.0)" d="M 359 -23 L 359 -19 C 359.8046875 -19.33877944946289 360.3280029296875 -20.12686920166016 360.3280029296875 -21 C 360.3280029296875 -21.87313079833984 359.8046875 -22.66122055053711 359 -23" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_hy2fm =
    '<svg viewBox="333.0 14.3 28.0 17.3" ><path transform="translate(0.0, 44.0)" d="M 333 -29.66666984558105 L 361 -29.66666984558105 L 361 -12.33333015441895 L 333 -12.33333015441895 L 333 -29.66666984558105 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_avi4k =
    '<svg viewBox="338.0 19.3 18.0 7.3" ><path transform="translate(0.0, 44.0)" d="M 339.3333129882812 -24.66666984558105 L 354.6666870117188 -24.66666984558105 L 354.6666870117188 -24.66666984558105 C 355.4030151367188 -24.66666984558105 356 -24.06970977783203 356 -23.33333015441895 L 356 -18.66666984558105 L 356 -18.66666984558105 C 356 -17.93029022216797 355.4030151367188 -17.33333015441895 354.6666870117188 -17.33333015441895 L 339.3333129882812 -17.33333015441895 L 339.3333129882812 -17.33333015441895 C 338.5969848632812 -17.33333015441895 338 -17.93029022216797 338 -18.66666984558105 L 338 -23.33333015441895 L 338 -23.33333015441895 C 338 -24.06970977783203 338.5969848632812 -24.66666984558105 339.3333129882812 -24.66666984558105 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tav08 =
    '<svg viewBox="310.7 12.3 25.3 21.0" ><path transform="translate(0.0, 44.0)" d="M 310.6936950683594 -31.66933059692383 L 335.9660949707031 -31.66933059692383 L 335.9660949707031 -10.70376014709473 L 310.6936950683594 -10.70376014709473 L 310.6936950683594 -31.66933059692383 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_iki5el =
    '<svg viewBox="315.7 17.3 15.3 11.0" ><path transform="translate(0.0, 44.0)" d="M 323.3302917480469 -24.39200019836426 C 325.5462036132812 -24.39189910888672 327.6773986816406 -23.54047012329102 329.2832946777344 -22.01366996765137 C 329.404296875 -21.89579010009766 329.5975952148438 -21.89727973937988 329.7167053222656 -22.01700019836426 L 330.8727111816406 -23.18367004394531 C 330.9330139160156 -23.2443904876709 330.9666137695312 -23.32663917541504 330.9660949707031 -23.4122200012207 C 330.9656066894531 -23.49780082702637 330.9309997558594 -23.57965087890625 330.8699951171875 -23.63966941833496 C 326.6549072265625 -27.6792106628418 320.0050964355469 -27.6792106628418 315.7900085449219 -23.63966941833496 C 315.7289123535156 -23.5797004699707 315.6943054199219 -23.49786949157715 315.6936950683594 -23.41229057312012 C 315.6932067871094 -23.32670974731445 315.7267150878906 -23.24443054199219 315.7869873046875 -23.18367004394531 L 316.9432983398438 -22.01700019836426 C 317.0624084472656 -21.8971004486084 317.2557983398438 -21.89561080932617 317.376708984375 -22.01366996765137 C 318.9827880859375 -23.54056930541992 321.1141967773438 -24.39200973510742 323.3302917480469 -24.39200019836426 L 323.3302917480469 -24.39200019836426 Z M 323.3302917480469 -20.5963306427002 C 324.5477905273438 -20.59641075134277 325.7218933105469 -20.14388084411621 326.6242980957031 -19.32666969299316 C 326.7463989257812 -19.21068954467773 326.9386901855469 -19.21319961547852 327.0577087402344 -19.33233070373535 L 328.2123107910156 -20.49900054931641 C 328.2731018066406 -20.56019020080566 328.306884765625 -20.64320945739746 328.3059997558594 -20.7294807434082 C 328.3051147460938 -20.81574058532715 328.2697143554688 -20.89805030822754 328.2077026367188 -20.95800018310547 C 325.4595031738281 -23.51437950134277 321.2034912109375 -23.51437950134277 318.4552917480469 -20.95800018310547 C 318.393310546875 -20.89805030822754 318.3577880859375 -20.81570053100586 318.3569946289062 -20.72941017150879 C 318.356201171875 -20.64311981201172 318.3901062011719 -20.56011009216309 318.4509887695312 -20.49900054931641 L 319.6052856445312 -19.33233070373535 C 319.7243041992188 -19.21319961547852 319.9165954589844 -19.21068954467773 320.0386962890625 -19.32666969299316 C 320.9404907226562 -20.14333915710449 322.1135864257812 -20.5958309173584 323.3302917480469 -20.5963306427002 L 323.3302917480469 -20.5963306427002 Z M 325.5492858886719 -17.8120002746582 C 325.6111145019531 -17.87261009216309 325.6451110839844 -17.95601081848145 325.643310546875 -18.04250907897949 C 325.6416015625 -18.12902069091797 325.6041870117188 -18.21096992492676 325.5400085449219 -18.26899909973145 C 324.264404296875 -19.34787940979004 322.3962097167969 -19.34787940979004 321.1206970214844 -18.26899909973145 C 321.056396484375 -18.21100997924805 321.0190124511719 -18.12908935546875 321.0172119140625 -18.04258918762207 C 321.0152893066406 -17.95607948303223 321.0492858886719 -17.87265014648438 321.1109924316406 -17.8120002746582 L 323.1087036132812 -15.79633045196533 C 323.1672058105469 -15.73709011077881 323.2470092773438 -15.70376014709473 323.3302917480469 -15.70376014709473 C 323.4136047363281 -15.70376014709473 323.493408203125 -15.73709011077881 323.552001953125 -15.79633045196533 L 325.5492858886719 -17.8120002746582 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_nqpuq1 =
    '<svg viewBox="288.7 12.7 27.0 20.7" ><path transform="translate(0.0, 44.0)" d="M 288.6666870117188 -31.33333015441895 L 315.6666870117188 -31.33333015441895 L 315.6666870117188 -10.66666984558105 L 288.6666870117188 -10.66666984558105 L 288.6666870117188 -31.33333015441895 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_n4r2 =
    '<svg viewBox="293.7 17.7 17.0 10.7" ><path transform="translate(0.0, 44.0)" d="M 294.6666870117188 -19.66666984558105 L 295.6666870117188 -19.66666984558105 C 296.218994140625 -19.66666984558105 296.6666870117188 -19.21895027160645 296.6666870117188 -18.66666984558105 L 296.6666870117188 -16.66666984558105 C 296.6666870117188 -16.1143798828125 296.218994140625 -15.66666984558105 295.6666870117188 -15.66666984558105 L 294.6666870117188 -15.66666984558105 C 294.1144104003906 -15.66666984558105 293.6666870117188 -16.1143798828125 293.6666870117188 -16.66666984558105 L 293.6666870117188 -18.66666984558105 C 293.6666870117188 -19.21895027160645 294.1144104003906 -19.66666984558105 294.6666870117188 -19.66666984558105 L 294.6666870117188 -19.66666984558105 Z M 299.3333129882812 -21.66666984558105 L 300.3333129882812 -21.66666984558105 C 300.8855895996094 -21.66666984558105 301.3333129882812 -21.21895027160645 301.3333129882812 -20.66666984558105 L 301.3333129882812 -16.66666984558105 C 301.3333129882812 -16.1143798828125 300.8855895996094 -15.66666984558105 300.3333129882812 -15.66666984558105 L 299.3333129882812 -15.66666984558105 C 298.781005859375 -15.66666984558105 298.3333129882812 -16.1143798828125 298.3333129882812 -16.66666984558105 L 298.3333129882812 -20.66666984558105 C 298.3333129882812 -21.21895027160645 298.781005859375 -21.66666984558105 299.3333129882812 -21.66666984558105 Z M 304 -24 L 305 -24 C 305.5523071289062 -24 306 -23.55228042602539 306 -23 L 306 -16.66666984558105 C 306 -16.1143798828125 305.5523071289062 -15.66666984558105 305 -15.66666984558105 L 304 -15.66666984558105 C 303.4476928710938 -15.66666984558105 303 -16.1143798828125 303 -16.66666984558105 L 303 -23 C 303 -23.55228042602539 303.4476928710938 -24 304 -24 Z M 308.6666870117188 -26.33333015441895 L 309.6666870117188 -26.33333015441895 C 310.218994140625 -26.33333015441895 310.6666870117188 -25.8856201171875 310.6666870117188 -25.33333015441895 L 310.6666870117188 -16.66666984558105 C 310.6666870117188 -16.1143798828125 310.218994140625 -15.66666984558105 309.6666870117188 -15.66666984558105 L 308.6666870117188 -15.66666984558105 C 308.1144104003906 -15.66666984558105 307.6666870117188 -16.1143798828125 307.6666870117188 -16.66666984558105 L 307.6666870117188 -25.33333015441895 C 307.6666870117188 -25.8856201171875 308.1144104003906 -26.33333015441895 308.6666870117188 -26.33333015441895 L 308.6666870117188 -26.33333015441895 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_u6yej =
    '<svg viewBox="29.0 15.0 54.0 16.0" ><path transform="translate(8.0, 50.0)" d="M 21 -19 L 75 -19 L 75 -35 L 21 -35 L 21 -19 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_snrsq =
    '<svg viewBox="41.8 19.9 27.5 10.3" ><path transform="translate(29.0, 17.0)" d="M 16.43259620666504 13.2392578125 C 18.94138526916504 13.2392578125 20.43161964416504 11.27734375 20.43161964416504 7.955078125 C 20.43161964416504 6.7041015625 20.19236183166504 5.6513671875 19.73435401916504 4.837890625 C 19.07126808166504 3.5732421875 17.92966651916504 2.8896484375 16.48728370666504 2.8896484375 C 14.34079933166504 2.8896484375 12.82322120666504 4.33203125 12.82322120666504 6.35546875 C 12.82322120666504 8.255859375 14.19040870666504 9.63671875 16.07029151916504 9.63671875 C 17.22556495666504 9.63671875 18.16208839416504 9.0966796875 18.62693214416504 8.16015625 L 18.64743995666504 8.16015625 C 18.64743995666504 8.16015625 18.67478370666504 8.16015625 18.68161964416504 8.16015625 C 18.69529151916504 8.16015625 18.74314308166504 8.16015625 18.74314308166504 8.16015625 C 18.74314308166504 10.416015625 17.88865089416504 11.7626953125 16.44626808166504 11.7626953125 C 15.59861183166504 11.7626953125 14.94236183166504 11.2978515625 14.71677589416504 10.552734375 L 12.95993995666504 10.552734375 C 13.25388526916504 12.1728515625 14.62790870666504 13.2392578125 16.43259620666504 13.2392578125 Z M 16.49411964416504 8.2353515625 C 15.35935401916504 8.2353515625 14.55271339416504 7.4287109375 14.55271339416504 6.30078125 C 14.55271339416504 5.2001953125 15.40036964416504 4.359375 16.50095558166504 4.359375 C 17.60154151916504 4.359375 18.44919776916504 5.2138671875 18.44919776916504 6.328125 C 18.44919776916504 7.4287109375 17.62204933166504 8.2353515625 16.49411964416504 8.2353515625 Z M 23.53221893310547 11.9541015625 C 24.18163299560547 11.9541015625 24.62596893310547 11.4892578125 24.62596893310547 10.8740234375 C 24.62596893310547 10.251953125 24.18163299560547 9.7939453125 23.53221893310547 9.7939453125 C 22.88964080810547 9.7939453125 22.43846893310547 10.251953125 22.43846893310547 10.8740234375 C 22.43846893310547 11.4892578125 22.88964080810547 11.9541015625 23.53221893310547 11.9541015625 Z M 23.53221893310547 6.8271484375 C 24.18163299560547 6.8271484375 24.62596893310547 6.369140625 24.62596893310547 5.75390625 C 24.62596893310547 5.1318359375 24.18163299560547 4.673828125 23.53221893310547 4.673828125 C 22.88964080810547 4.673828125 22.43846893310547 5.1318359375 22.43846893310547 5.75390625 C 22.43846893310547 6.369140625 22.88964080810547 6.8271484375 23.53221893310547 6.8271484375 Z M 31.44532012939453 13 L 33.13379669189453 13 L 33.13379669189453 11.1611328125 L 34.46680450439453 11.1611328125 L 34.46680450439453 9.6708984375 L 33.13379669189453 9.6708984375 L 33.13379669189453 3.1357421875 L 30.64551544189453 3.1357421875 C 28.90235137939453 5.7607421875 27.51465606689453 7.955078125 26.62598419189453 9.5888671875 L 26.62598419189453 11.1611328125 L 31.44532012939453 11.1611328125 L 31.44532012939453 13 Z M 28.25977325439453 9.609375 C 29.40821075439453 7.5859375 30.43360137939453 5.9658203125 31.37696075439453 4.5712890625 L 31.47266387939453 4.5712890625 C 31.47266387939453 4.5712890625 31.47266387939453 6.256190299987793 31.47266387939453 7.541346549987793 C 31.47266387939453 8.826502799987793 31.47266387939453 9.7119140625 31.47266387939453 9.7119140625 L 28.25977325439453 9.7119140625 L 28.25977325439453 9.609375 Z M 38.51076507568359 13 L 40.27443695068359 13 L 40.27443695068359 3.1357421875 L 38.51760101318359 3.1357421875 L 35.94045257568359 4.9404296875 L 35.94045257568359 6.6357421875 L 38.39455413818359 4.9130859375 L 38.51076507568359 4.9130859375 L 38.51076507568359 13 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_mhz2ca =
    '<svg viewBox="0.0 70.0 375.0 44.0" ><path transform="translate(0.0, 114.0)" d="M 0 -44 L 375 -44 L 375 0 L 0 0 L 0 -44 Z" fill="#ffffff" fill-opacity="0.0" stroke="none" stroke-width="1" stroke-opacity="0.0" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_jzx0na =
    '<svg viewBox="0.0 0.0 375.0 119.0" ><path  d="M 0 0 L 375 0 L 375 119 L 0 119 L 0 0 Z" fill="#ecf9fe" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_pyv499 =
    '<svg viewBox="0.0 40.6 81.1 10.0" ><path transform="translate(0.0, -252.8)" d="M 75.88474273681641 295.4244079589844 L 81.07770538330078 295.4244079589844 L 81.07770538330078 293.5283203125 L 73.76620483398438 293.5283203125 L 73.76620483398438 295.4244079589844 L 75.88474273681641 295.4244079589844 Z M 81.14710998535156 303.2200622558594 L 81.14710998535156 301.3232727050781 L 75.88474273681641 301.3232727050781 L 75.88474273681641 299.2883911132812 L 80.45461273193359 299.2883911132812 L 80.45461273193359 297.3911743164062 L 75.88474273681641 297.3911743164062 L 73.76620483398438 297.3911743164062 L 73.76620483398438 303.2200622558594 L 81.14710998535156 303.2200622558594 Z M 70.82423400878906 293.5283203125 L 68.52595520019531 293.5283203125 L 65.99197387695312 300.3544311523438 L 63.45757293701172 293.5283203125 L 61.10372161865234 293.5283203125 L 65.02284240722656 303.2900390625 L 66.90553283691406 303.2900390625 L 70.82423400878906 293.5283203125 Z M 58.06470489501953 293.5283203125 L 55.93246841430664 293.5283203125 L 55.93246841430664 303.22021484375 L 58.06470489501953 303.22021484375 L 58.06470489501953 293.5283203125 Z M 52.75561904907227 295.494384765625 L 52.75561904907227 293.5283203125 L 44.72355270385742 293.5283203125 L 44.72355270385742 295.494384765625 L 47.67339706420898 295.494384765625 L 47.67339706420898 303.2200622558594 L 49.80577087402344 303.2200622558594 L 49.80577087402344 295.494384765625 L 52.75561904907227 295.494384765625 Z M 43.72040557861328 303.2200622558594 L 39.56654357910156 293.4583740234375 L 37.60006713867188 293.4583740234375 L 33.44564437866211 303.2200622558594 L 35.61977005004883 303.2200622558594 C 37.03945922851562 299.7372741699219 37.08674240112305 299.6053771972656 38.55593109130859 296.0198669433594 C 40.05179595947266 299.6732788085938 40.02774429321289 299.6300048828125 41.49111938476562 303.2200622558594 L 43.72040557861328 303.2200622558594 Z M 25.6710033416748 295.4244079589844 L 30.86396026611328 295.4244079589844 L 30.86396026611328 293.5283203125 L 23.55301094055176 293.5283203125 L 23.55301094055176 295.4244079589844 L 25.6710033416748 295.4244079589844 Z M 30.93280792236328 303.2200622558594 L 30.93280792236328 301.3232727050781 L 25.6710033416748 301.3232727050781 L 25.6710033416748 299.2883911132812 L 30.24031257629395 299.2883911132812 L 30.24031257629395 297.3911743164062 L 25.6710033416748 297.3911743164062 L 23.55301094055176 297.3911743164062 L 23.55301094055176 303.2200622558594 L 30.93280792236328 303.2200622558594 Z M 18.02133750915527 296.8646850585938 C 18.02133750915527 297.6817626953125 17.42575645446777 298.2360229492188 16.38722038269043 298.2360229492188 L 14.22733688354492 298.2360229492188 L 14.22733688354492 295.452880859375 L 16.34574508666992 295.452880859375 C 17.38442039489746 295.452880859375 18.02133750915527 295.9234924316406 18.02133750915527 296.8369140625 L 18.02133750915527 296.8646850585938 Z M 20.47265434265137 303.2200622558594 L 18.10456466674805 299.7588500976562 C 19.33651351928711 299.3021850585938 20.18122100830078 298.3185424804688 20.18122100830078 296.75439453125 L 20.18122100830078 296.7268676757812 C 20.18122100830078 294.7323608398438 18.81088447570801 293.5283203125 16.52547073364258 293.5283203125 L 12.09441089630127 293.5283203125 L 12.09441089630127 303.2200622558594 L 14.22733688354492 303.2200622558594 L 14.22733688354492 300.1192626953125 L 15.90279102325439 300.1192626953125 L 17.97958755493164 303.2200622558594 L 20.47265434265137 303.2200622558594 Z M 8.945208549499512 301.6559143066406 L 7.588143348693848 300.2855834960938 C 6.826661109924316 300.9776611328125 6.147990226745605 301.4205932617188 5.040467262268066 301.4205932617188 C 3.378698587417603 301.4205932617188 2.229285717010498 300.0364379882812 2.229285717010498 298.3748168945312 L 2.229285717010498 298.34619140625 C 2.229285717010498 296.6844482421875 3.406210422515869 295.3277587890625 5.040467262268066 295.3277587890625 C 6.009601593017578 295.3277587890625 6.771083831787109 295.7432250976562 7.519294261932373 296.421630859375 L 8.875805854797363 294.8572998046875 C 7.976073265075684 293.9702758789062 6.881822109222412 293.3619995117188 5.054153442382812 293.3619995117188 C 2.077210426330566 293.3619995117188 0 295.6182250976562 0 298.3748168945312 L 0 298.40234375 C 0 301.1854248046875 2.118547439575195 303.3875122070312 4.971065521240234 303.3875122070312 C 6.839932441711426 303.3875122070312 7.948423385620117 302.7221069335938 8.945208549499512 301.6559143066406" fill="#00070f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_vlvtax =
    '<svg viewBox="12.1 53.7 57.0 3.6" ><path transform="translate(-75.39, -334.5)" d="M 144.4387664794922 391.6971435546875 L 144.4387664794922 388.2200317382812 L 143.6830749511719 388.2200317382812 L 143.6830749511719 390.3612670898438 L 142.053955078125 388.2200317382812 L 141.3486022949219 388.2200317382812 L 141.3486022949219 391.6971435546875 L 142.1037292480469 391.6971435546875 L 142.1037292480469 389.4861450195312 L 143.7874603271484 391.6971435546875 L 144.4387664794922 391.6971435546875 Z M 137.4654235839844 390.2422180175781 L 136.5409545898438 390.2422180175781 L 137.0032653808594 389.1139526367188 L 137.4654235839844 390.2422180175781 Z M 138.85595703125 391.6971435546875 L 137.3660278320312 388.1944580078125 L 136.6606750488281 388.1944580078125 L 135.1701965332031 391.6971435546875 L 135.9497985839844 391.6971435546875 L 136.2679138183594 390.9175720214844 L 137.7386169433594 390.9175720214844 L 138.0565795898438 391.6971435546875 L 138.85595703125 391.6971435546875 Z M 132.7774963378906 391.2049865722656 L 132.7774963378906 389.6947631835938 L 131.266845703125 389.6947631835938 L 131.266845703125 390.3562622070312 L 132.0371704101562 390.3562622070312 L 132.0371704101562 390.8524780273438 C 131.8432006835938 390.9923706054688 131.5951843261719 391.0612182617188 131.3164672851562 391.0612182617188 C 130.7006988525391 391.0612182617188 130.2637023925781 390.5946044921875 130.2637023925781 389.9586791992188 L 130.2637023925781 389.9488525390625 C 130.2637023925781 389.3571472167969 130.7056884765625 388.8659362792969 131.2624206542969 388.8659362792969 C 131.6645812988281 388.8659362792969 131.9027862548828 388.9949340820312 132.1709899902344 389.2183227539062 L 132.6533508300781 388.6365661621094 C 132.2901611328125 388.3294067382812 131.91259765625 388.1600341796875 131.2870178222656 388.1600341796875 C 130.2335510253906 388.1600341796875 129.4637756347656 388.9703063964844 129.4637756347656 389.9586791992188 L 129.4637756347656 389.9683532714844 C 129.4637756347656 390.9971923828125 130.2089385986328 391.7572937011719 131.2919921875 391.7572937011719 C 131.9278106689453 391.7572937011719 132.4195556640625 391.5081787109375 132.7774963378906 391.2049865722656 M 126.1817169189453 389.9683532714844 C 126.1817169189453 390.5650329589844 125.7543792724609 391.0513916015625 125.1386108398438 391.0513916015625 C 124.5224304199219 391.0513916015625 124.0852813720703 390.5542602539062 124.0852813720703 389.9586791992188 L 124.0852813720703 389.9488525390625 C 124.0852813720703 389.3521728515625 124.5124740600586 388.8659362792969 125.1282424926758 388.8659362792969 C 125.7441558837891 388.8659362792969 126.1817169189453 389.3630981445312 126.1817169189453 389.9586791992188 L 126.1817169189453 389.9683532714844 Z M 126.9814910888672 389.9586791992188 L 126.9814910888672 389.9488525390625 C 126.9814910888672 388.9603576660156 126.2115783691406 388.1600341796875 125.1386108398438 388.1600341796875 C 124.0650939941406 388.1600341796875 123.285514831543 388.9703063964844 123.285514831543 389.9586791992188 L 123.285514831543 389.9683532714844 C 123.285514831543 390.9568481445312 124.0556945800781 391.7572937011719 125.1282424926758 391.7572937011719 C 126.2013473510742 391.7572937011719 126.9814910888672 390.947021484375 126.9814910888672 389.9586791992188 M 121.1058502197266 391.6971435546875 L 121.1058502197266 391.002197265625 L 119.3721923828125 391.002197265625 L 119.3721923828125 388.2200317382812 L 118.6073913574219 388.2200317382812 L 118.6073913574219 391.6971435546875 L 121.1058502197266 391.6971435546875 Z M 115.9857559204102 390.66943359375 L 115.9857559204102 390.6586303710938 C 115.9857559204102 390.05322265625 115.5885620117188 389.8002319335938 114.8832092285156 389.6160888671875 C 114.282096862793 389.4615173339844 114.132926940918 389.3875427246094 114.132926940918 389.1583251953125 L 114.132926940918 389.1483764648438 C 114.132926940918 388.9801330566406 114.2870788574219 388.84619140625 114.5798873901367 388.84619140625 C 114.8732528686523 388.84619140625 115.1760177612305 388.9751586914062 115.4841842651367 389.1889038085938 L 115.8813781738281 388.6119689941406 C 115.5289764404297 388.3294067382812 115.0962524414062 388.1699829101562 114.5896987915039 388.1699829101562 C 113.879508972168 388.1699829101562 113.3729629516602 388.5872192382812 113.3729629516602 389.2183227539062 L 113.3729629516602 389.2281494140625 C 113.3729629516602 389.9192504882812 113.8249053955078 390.1122436523438 114.525276184082 390.2913208007812 C 115.1066284179688 390.4400634765625 115.226203918457 390.5394592285156 115.226203918457 390.7333984375 L 115.226203918457 390.7432250976562 C 115.226203918457 390.947021484375 115.0372161865234 391.071044921875 114.7242202758789 391.071044921875 C 114.3268814086914 391.071044921875 113.9986801147461 390.9075927734375 113.685546875 390.648681640625 L 113.2336044311523 391.190185546875 C 113.6511154174805 391.5633544921875 114.1826934814453 391.7463684082031 114.7088775634766 391.7463684082031 C 115.4590148925781 391.7463684082031 115.9857559204102 391.3595581054688 115.9857559204102 390.66943359375 M 107.0705490112305 389.4171447753906 C 107.0705490112305 389.7095336914062 106.8569488525391 389.9084777832031 106.4843597412109 389.9084777832031 L 105.7090606689453 389.9084777832031 L 105.7090606689453 388.91015625 L 106.4695739746094 388.91015625 C 106.842155456543 388.91015625 107.0705490112305 389.0795288085938 107.0705490112305 389.4073486328125 L 107.0705490112305 389.4171447753906 Z M 107.9496841430664 391.6971435546875 L 107.1005477905273 390.454833984375 C 107.5425338745117 390.2913208007812 107.8452987670898 389.9390258789062 107.8452987670898 389.3778686523438 L 107.8452987670898 389.366943359375 C 107.8452987670898 388.65234375 107.3535461425781 388.2200317382812 106.5339965820312 388.2200317382812 L 104.9441223144531 388.2200317382812 L 104.9441223144531 391.6971435546875 L 105.7090606689453 391.6971435546875 L 105.7090606689453 390.5847778320312 L 106.3105926513672 390.5847778320312 L 107.0557556152344 391.6971435546875 L 107.9496841430664 391.6971435546875 Z M 102.2088394165039 390.1820678710938 L 102.2088394165039 388.2200317382812 L 101.4434814453125 388.2200317382812 L 101.4434814453125 390.211669921875 C 101.4434814453125 390.7630004882812 101.1609039306641 391.0464172363281 100.6931991577148 391.0464172363281 C 100.2266082763672 391.0464172363281 99.94319152832031 390.7530517578125 99.94319152832031 390.1870727539062 L 99.94319152832031 388.2200317382812 L 99.17825317382812 388.2200317382812 L 99.17825317382812 390.2066955566406 C 99.17825317382812 391.2304077148438 99.74964141845703 391.7523193359375 100.6839370727539 391.7523193359375 C 101.61767578125 391.7523193359375 102.2088394165039 391.2355346679688 102.2088394165039 390.1820678710938 M 95.79664611816406 389.9683532714844 C 95.79664611816406 390.5650329589844 95.36946105957031 391.0513916015625 94.75369262695312 391.0513916015625 C 94.13778686523438 391.0513916015625 93.70022583007812 390.5542602539062 93.70022583007812 389.9586791992188 L 93.70022583007812 389.9488525390625 C 93.70022583007812 389.3521728515625 94.1275634765625 388.8659362792969 94.74373626708984 388.8659362792969 C 95.35950469970703 388.8659362792969 95.79664611816406 389.3630981445312 95.79664611816406 389.9586791992188 L 95.79664611816406 389.9683532714844 Z M 96.59656524658203 389.9586791992188 L 96.59656524658203 389.9488525390625 C 96.59656524658203 388.9603576660156 95.82665252685547 388.1600341796875 94.75369262695312 388.1600341796875 C 93.68059539794922 388.1600341796875 92.90045166015625 388.9703063964844 92.90045166015625 389.9586791992188 L 92.90045166015625 389.9683532714844 C 92.90045166015625 390.9568481445312 93.67063903808594 391.7572937011719 94.74373626708984 391.7572937011719 C 95.81683349609375 391.7572937011719 96.59656524658203 390.947021484375 96.59656524658203 389.9586791992188 M 90.92015075683594 388.2200317382812 L 90.0504150390625 388.2200317382812 L 89.20626068115234 389.6160888671875 L 88.37648010253906 388.2200317382812 L 87.48200225830078 388.2200317382812 L 88.81832885742188 390.3257141113281 L 88.81832885742188 391.6971435546875 L 89.58382415771484 391.6971435546875 L 89.58382415771484 390.3110656738281 L 90.92015075683594 388.2200317382812 Z" fill="#00070f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_iv1 =
    '<svg viewBox="14.5 0.0 52.1 30.6" ><path transform="translate(-90.51, 0.0)" d="M 128.1074523925781 0 L 142.9529113769531 19.14102745056152 C 143.0213623046875 19.24499130249023 143.09765625 19.34328651428223 143.1808776855469 19.43536186218262 C 143.6115417480469 19.90845680236816 144.2321472167969 20.2047233581543 144.9217376708984 20.2047233581543 C 146.8089904785156 20.2047233581543 147.8972930908203 18.10940361022949 146.8966369628906 16.56971168518066 C 146.8252868652344 16.45993995666504 146.7449798583984 16.35652923583984 146.6563720703125 16.26058197021484 L 139.7579345703125 7.365560531616211 L 151.1445159912109 7.365560531616211 C 154.4538269042969 7.365560531616211 157.1364135742188 10.04830646514893 157.1364135742188 13.35788059234619 C 157.1364135742188 14.60227203369141 156.7573394775391 15.75749015808105 156.1081237792969 16.71542549133301 L 146.7095947265625 28.83444595336914 C 145.779296875 29.90547180175781 144.4074401855469 30.58178901672363 142.8775634765625 30.58178901672363 C 141.3398132324219 30.58178901672363 139.9625549316406 29.89772987365723 139.0324096679688 28.81771850585938 L 134.1953125 22.58124732971191 L 129.3457641601562 28.83444595336914 C 128.4156188964844 29.90547180175781 127.0437698364258 30.58178901672363 125.5138778686523 30.58178901672363 C 123.9766845703125 30.58178901672363 122.5990219116211 29.89772987365723 121.668586730957 28.81771850585938 L 105.0309982299805 7.365560531616211 L 110.7437744140625 0 L 116.456413269043 7.365560531616211 L 125.589225769043 19.14102745056152 C 125.6576690673828 19.24499130249023 125.7338333129883 19.34328651428223 125.8176193237305 19.43536186218262 C 126.2478561401367 19.90845680236816 126.8684616088867 20.2047233581543 127.5586090087891 20.2047233581543 C 129.4447479248047 20.2047233581543 130.5335998535156 18.10940361022949 129.532958984375 16.56971168518066 C 129.4614868164062 16.45993995666504 129.3812866210938 16.35652923583984 129.2926940917969 16.26058197021484 L 122.3946838378906 7.365560531616211 L 128.1074523925781 0 Z" fill="#004c98" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
