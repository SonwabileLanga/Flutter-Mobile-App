import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'package:flutter_svg/flutter_svg.dart';

class Search extends StatelessWidget {
  const Search({
    Key key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 310.0, start: 68.0),
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment(0.0, 0.614),
                  end: Alignment(0.0, 1.0),
                  colors: [Color(0xffffffff), Color(0x00ffffff)],
                  stops: [0.0, 1.0],
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 49.0, middle: 0.81),
            child: Stack(
              children: <Widget>[
                Container(
                  color: const Color(0xffffffff),
                ),
                Pinned.fromPins(
                  Pin(start: 15.0, end: 15.0),
                  Pin(size: 11.0, end: 4.0),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(size: 29.0, start: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child: const Text(
                          'Home',
                          style: TextStyle(
                            fontFamily: 'Neusa Next Std',
                            fontSize: 11,
                            color: Color(0xff727c8e),
                            letterSpacing: 0.22,
                          ),
                          softWrap: false,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 22.0, middle: 0.5015),
                        Pin(start: 0.0, end: 0.0),
                        child: const Text(
                          'Cart',
                          style: TextStyle(
                            fontFamily: 'Neusa Next Std',
                            fontSize: 11,
                            color: Color(0xff727c8e),
                            letterSpacing: 0.22,
                          ),
                          textAlign: TextAlign.center,
                          softWrap: false,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 32.0, middle: 0.7508),
                        Pin(start: 0.0, end: 0.0),
                        child: const Text(
                          'Profile',
                          style: TextStyle(
                            fontFamily: 'Neusa Next Std',
                            fontSize: 11,
                            color: Color(0xff727c8e),
                            letterSpacing: 0.22,
                          ),
                          textAlign: TextAlign.center,
                          softWrap: false,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 25.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child: const Text(
                          'More',
                          style: TextStyle(
                            fontFamily: 'Neusa Next Std',
                            fontSize: 11,
                            color: Color(0xff727c8e),
                            letterSpacing: 0.22,
                          ),
                          textAlign: TextAlign.right,
                          softWrap: false,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 36.0, middle: 0.2524),
                        Pin(start: 0.0, end: 0.0),
                        child: const Text(
                          'Search',
                          style: TextStyle(
                            fontFamily: 'Neusa Next Std',
                            fontSize: 11,
                            color: Color(0xffff6969),
                            letterSpacing: 0.22,
                          ),
                          textAlign: TextAlign.center,
                          softWrap: false,
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 19.0, end: 18.5),
                  Pin(size: 18.6, middle: 0.2632),
                  child: Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(size: 19.0, start: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child: SvgPicture.string(
                          _svg_d68v4,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 17.0, middle: 0.2559),
                        Pin(start: 1.0, end: 0.6),
                        child: SvgPicture.string(
                          _svg_xas88,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 18.5, middle: 0.4985),
                        Pin(start: 0.0, end: 0.6),
                        child: SvgPicture.string(
                          _svg_ahnr0,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 18.0, middle: 0.7449),
                        Pin(start: 0.0, end: 0.6),
                        child: SvgPicture.string(
                          _svg_ij0dtz,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 18.0, end: 0.0),
                        Pin(start: 3.5, end: 3.1),
                        child: SvgPicture.string(
                          _svg_nmdgvf,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 25.0, end: 20.0),
            Pin(size: 35.0, middle: 0.2136),
            child: Stack(
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0x1a727c8e),
                    borderRadius: BorderRadius.circular(18.0),
                  ),
                ),
                Align(
                  alignment: const Alignment(0.0, -0.2),
                  child: SizedBox(
                    width: 140.0,
                    height: 20.0,
                    child: Stack(
                      children: <Widget>[
                        Stack(
                          children: <Widget>[
                            const Padding(
                              padding: EdgeInsets.fromLTRB(18.0, 0.0, 0.0, 0.0),
                              child: SizedBox.expand(
                                  child: Text(
                                'Search Something',
                                style: TextStyle(
                                  fontFamily: 'Roboto',
                                  fontSize: 15,
                                  color: Color(0x66515c6f),
                                ),
                                softWrap: false,
                              )),
                            ),
                            Align(
                              alignment: const Alignment(-1.0, 0.333),
                              child: SizedBox(
                                width: 11.0,
                                height: 11.0,
                                child: SvgPicture.string(
                                  _svg_rs6te1,
                                  allowDrawingOutsideViewBox: true,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 25.0, end: 20.0),
            Pin(size: 96.0, middle: 0.4651),
            child: Stack(
              children: <Widget>[
                const Align(
                  alignment: Alignment.topLeft,
                  child: SizedBox(
                    width: 98.0,
                    height: 16.0,
                    child: Text(
                      'RECOMMENDED',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 12,
                        color: Color(0x80515c6f),
                        letterSpacing: 0.8400000000000001,
                        fontWeight: FontWeight.w500,
                      ),
                      softWrap: false,
                    ),
                  ),
                ),
                const Align(
                  alignment: Alignment.topRight,
                  child: SizedBox(
                    width: 56.0,
                    height: 16.0,
                    child: Text(
                      'REFRESH',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 12,
                        color: Color(0xffff6969),
                        letterSpacing: 0.8400000000000001,
                        fontWeight: FontWeight.w500,
                      ),
                      textAlign: TextAlign.right,
                      softWrap: false,
                    ),
                  ),
                ),
                Align(
                  alignment: const Alignment(-1.0, -0.118),
                  child: SizedBox(
                    width: 88.0,
                    height: 28.0,
                    child: Stack(
                      children: <Widget>[
                        Container(
                          decoration: BoxDecoration(
                            color: const Color(0xffffffff),
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                        ),
                        Pinned.fromPins(
                          Pin(size: 33.0, start: 10.0),
                          Pin(size: 16.0, middle: 0.4167),
                          child: const Text(
                            'Books',
                            style: TextStyle(
                              fontFamily: 'Roboto',
                              fontSize: 12,
                              color: Color(0xff515c6f),
                            ),
                            softWrap: false,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.bottomLeft,
                  child: SizedBox(
                    width: 123.0,
                    height: 28.0,
                    child: Stack(
                      children: <Widget>[
                        Container(
                          decoration: BoxDecoration(
                            color: const Color(0xffffffff),
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                        ),
                        Pinned.fromPins(
                          Pin(start: 10.0, end: 9.0),
                          Pin(size: 16.0, middle: 0.4167),
                          child: const Text(
                            'Sports Accessories',
                            style: TextStyle(
                              fontFamily: 'Roboto',
                              fontSize: 12,
                              color: Color(0xff515c6f),
                            ),
                            softWrap: false,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Align(
                  alignment: const Alignment(0.056, 1.0),
                  child: SizedBox(
                    width: 78.0,
                    height: 28.0,
                    child: Stack(
                      children: <Widget>[
                        Container(
                          decoration: BoxDecoration(
                            color: const Color(0xffffffff),
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                        ),
                        Pinned.fromPins(
                          Pin(start: 10.0, end: 7.0),
                          Pin(size: 16.0, middle: 0.4167),
                          child: const Text(
                            'Yoga Pants',
                            style: TextStyle(
                              fontFamily: 'Roboto',
                              fontSize: 12,
                              color: Color(0xff515c6f),
                            ),
                            softWrap: false,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 83.0, end: 26.0),
                  Pin(size: 28.0, end: 0.0),
                  child: Stack(
                    children: <Widget>[
                      Container(
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 10.0, end: 8.0),
                        Pin(size: 16.0, middle: 0.4167),
                        child: const Text(
                          'Eye Shadow',
                          style: TextStyle(
                            fontFamily: 'Roboto',
                            fontSize: 12,
                            color: Color(0xff515c6f),
                          ),
                          softWrap: false,
                        ),
                      ),
                    ],
                  ),
                ),
                Align(
                  alignment: const Alignment(1.0, -0.118),
                  child: SizedBox(
                    width: 87.0,
                    height: 28.0,
                    child: Stack(
                      children: <Widget>[
                        Container(
                          decoration: BoxDecoration(
                            color: const Color(0xffffffff),
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                        ),
                        Pinned.fromPins(
                          Pin(start: 12.0, end: 10.0),
                          Pin(size: 16.0, middle: 0.4167),
                          child: const Text(
                            'Accessories',
                            style: TextStyle(
                              fontFamily: 'Roboto',
                              fontSize: 12,
                              color: Color(0xff515c6f),
                            ),
                            softWrap: false,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Align(
                  alignment: const Alignment(-0.249, -0.118),
                  child: SizedBox(
                    width: 69.0,
                    height: 28.0,
                    child: Stack(
                      children: <Widget>[
                        Container(
                          decoration: BoxDecoration(
                            color: const Color(0xffffffff),
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                        ),
                        Pinned.fromPins(
                          Pin(size: 27.0, start: 10.0),
                          Pin(size: 16.0, middle: 0.4167),
                          child: const Text(
                            'Solar',
                            style: TextStyle(
                              fontFamily: 'Roboto',
                              fontSize: 12,
                              color: Color(0xff515c6f),
                            ),
                            softWrap: false,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Align(
                  alignment: const Alignment(0.292, -0.118),
                  child: SizedBox(
                    width: 56.0,
                    height: 28.0,
                    child: Stack(
                      children: <Widget>[
                        Container(
                          decoration: BoxDecoration(
                            color: const Color(0xffffffff),
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                        ),
                        const Align(
                          alignment: Alignment(0.0, -0.167),
                          child: SizedBox(
                            width: 36.0,
                            height: 16.0,
                            child: Text(
                              'Jacket',
                              style: TextStyle(
                                fontFamily: 'Roboto',
                                fontSize: 12,
                                color: Color(0xff515c6f),
                              ),
                              softWrap: false,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 25.0, end: -67.0),
            Pin(size: 89.0, middle: 0.3043),
            child: Stack(
              children: <Widget>[
                Align(
                  alignment: Alignment.topLeft,
                  child: SizedBox(
                    width: 330.0,
                    height: 16.0,
                    child: Stack(
                      children: <Widget>[
                        Pinned.fromPins(
                          Pin(size: 115.0, start: 0.0),
                          Pin(start: 0.0, end: 0.0),
                          child: const Text(
                            'RECENTLY VIEWED',
                            style: TextStyle(
                              fontFamily: 'Roboto',
                              fontSize: 12,
                              color: Color(0x80515c6f),
                              letterSpacing: 0.8400000000000001,
                              fontWeight: FontWeight.w500,
                            ),
                            softWrap: false,
                          ),
                        ),
                        Pinned.fromPins(
                          Pin(size: 40.0, end: 0.0),
                          Pin(start: 0.0, end: 0.0),
                          child: const Text(
                            'CLEAR',
                            style: TextStyle(
                              fontFamily: 'Roboto',
                              fontSize: 12,
                              color: Color(0xffff6969),
                              letterSpacing: 0.8400000000000001,
                              fontWeight: FontWeight.w500,
                            ),
                            textAlign: TextAlign.right,
                            softWrap: false,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 59.0, end: 0.0),
                  child: SingleChildScrollView(
                    primary: false,
                    child: Wrap(
                      alignment: WrapAlignment.center,
                      spacing: 0,
                      runSpacing: 0,
                      children: [{}].map((itemData) {
                        return SizedBox(
                          width: 417.0,
                          height: 59.0,
                          child: Stack(
                            children: <Widget>[
                              Pinned.fromPins(
                                Pin(size: 185.0, start: 0.0),
                                Pin(start: 0.0, end: 0.0),
                                child: Stack(
                                  children: <Widget>[
                                    Container(
                                      decoration: BoxDecoration(
                                        color: const Color(0xffffffff),
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                        boxShadow: const [
                                          BoxShadow(
                                            color: Color(0xffe7eaf0),
                                            offset: Offset(0, 8),
                                            blurRadius: 15,
                                          ),
                                        ],
                                      ),
                                    ),
                                    Pinned.fromPins(
                                      Pin(size: 39.5, start: 8.3),
                                      Pin(size: 39.5, start: 8.8),
                                      child: Stack(
                                        children: <Widget>[
                                          Container(
                                            decoration: const BoxDecoration(
                                              image: DecorationImage(
                                                image: AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const Align(
                                      alignment: Alignment(-0.123, 0.436),
                                      child: SizedBox(
                                        width: 55.0,
                                        height: 20.0,
                                        child: Text(
                                          'R931.50',
                                          style: TextStyle(
                                            fontFamily: 'Roboto',
                                            fontSize: 15,
                                            color: Color(0xff515c6f),
                                          ),
                                          softWrap: false,
                                        ),
                                      ),
                                    ),
                                    Pinned.fromPins(
                                      Pin(size: 95.0, middle: 0.6333),
                                      Pin(size: 20.0, start: 8.0),
                                      child: const Text(
                                        'E-Max Display',
                                        style: TextStyle(
                                          fontFamily: 'Roboto',
                                          fontSize: 15,
                                          color: Color(0xff515c6f),
                                          fontWeight: FontWeight.w500,
                                        ),
                                        softWrap: false,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Pinned.fromPins(
                                Pin(size: 222.0, end: 0.0),
                                Pin(start: 0.0, end: 0.0),
                                child: Stack(
                                  children: <Widget>[
                                    Container(
                                      decoration: BoxDecoration(
                                        color: const Color(0xffffffff),
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                        boxShadow: const [
                                          BoxShadow(
                                            color: Color(0xffe7eaf0),
                                            offset: Offset(0, 8),
                                            blurRadius: 15,
                                          ),
                                        ],
                                      ),
                                    ),
                                    const Align(
                                      alignment: Alignment(-0.265, 0.436),
                                      child: SizedBox(
                                        width: 67.0,
                                        height: 20.0,
                                        child: Text(
                                          'R5,796.00',
                                          style: TextStyle(
                                            fontFamily: 'Roboto',
                                            fontSize: 15,
                                            color: Color(0xff515c6f),
                                          ),
                                          softWrap: false,
                                        ),
                                      ),
                                    ),
                                    Pinned.fromPins(
                                      Pin(size: 159.0, end: 6.0),
                                      Pin(size: 20.0, start: 8.0),
                                      child: const Text(
                                        'Invest Solar 200ah Gel..',
                                        style: TextStyle(
                                          fontFamily: 'Roboto',
                                          fontSize: 15,
                                          color: Color(0xff515c6f),
                                          fontWeight: FontWeight.w500,
                                        ),
                                        softWrap: false,
                                      ),
                                    ),
                                    Pinned.fromPins(
                                      Pin(size: 36.0, start: 12.0),
                                      Pin(start: 12.0, end: 11.0),
                                      child: Container(
                                        decoration: const BoxDecoration(
                                          image: DecorationImage(
                                            image: AssetImage(''),
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 44.0, middle: 0.7188),
            child: Stack(
              children: <Widget>[
                Container(
                  color: const Color(0xffffffff),
                ),
                Align(
                  alignment: const Alignment(0.014, -0.083),
                  child: SizedBox(
                    width: 223.0,
                    height: 20.0,
                    child: Stack(
                      children: <Widget>[
                        const Padding(
                          padding: EdgeInsets.fromLTRB(19.1, 0.0, 0.0, 0.0),
                          child: SizedBox.expand(
                              child: Text(
                            'Tap & hold to search with voice',
                            style: TextStyle(
                              fontFamily: 'Roboto',
                              fontSize: 15,
                              color: Color(0xff515c6f),
                              fontWeight: FontWeight.w300,
                            ),
                            textAlign: TextAlign.center,
                            softWrap: false,
                          )),
                        ),
                        Pinned.fromPins(
                          Pin(size: 11.7, start: 0.0),
                          Pin(start: 2.8, end: 0.2),
                          child: SvgPicture.string(
                            _svg_t474y,
                            allowDrawingOutsideViewBox: true,
                            fit: BoxFit.fill,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 216.0, end: 0.0),
            child: Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(''),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 65.0, middle: 0.5),
            Pin(size: 23.0, start: 126.0),
            child: const Text(
              'SEARCH',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 17,
                color: Color(0xff004c98),
                fontWeight: FontWeight.w700,
                height: 0.7058823529411765,
              ),
              textHeightBehavior:
                  TextHeightBehavior(applyHeightToFirstAscent: false),
              softWrap: false,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 10.0, end: 10.0),
            Pin(size: 121.0, middle: 0.6324),
            child: Stack(
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xffffffff),
                    border:
                        Border.all(width: 1.0, color: const Color(0xff707070)),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 119.0, start: 0.0),
            child: Stack(
              children: <Widget>[
                SizedBox.expand(
                    child: SvgPicture.string(
                  _svg_jzx0na,
                  allowDrawingOutsideViewBox: true,
                  fit: BoxFit.fill,
                )),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 44.0, start: 0.0),
                  child: Stack(
                    children: <Widget>[
                      SizedBox.expand(
                          child: SvgPicture.string(
                        _svg_mhz2ca,
                        allowDrawingOutsideViewBox: true,
                        fit: BoxFit.fill,
                      )),
                      Pinned.fromPins(
                        Pin(start: 20.0, end: 14.7),
                        Pin(size: 16.0, middle: 0.5357),
                        child: Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(size: 24.3, end: 0.0),
                              Pin(start: 2.3, end: 2.3),
                              child: Stack(
                                children: <Widget>[
                                  Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(0.0, 0.0, 2.3, 0.0),
                                    child: Stack(
                                      children: <Widget>[
                                        SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_i4lwc,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                        SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_hn,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                      ],
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.centerRight,
                                    child: SizedBox(
                                      width: 1.0,
                                      height: 4.0,
                                      child: Stack(
                                        children: <Widget>[
                                          Padding(
                                            padding: const EdgeInsets.all(-5.0),
                                            child: SizedBox.expand(
                                                child: SvgPicture.string(
                                              _svg_tszyk4,
                                              allowDrawingOutsideViewBox: true,
                                              fit: BoxFit.fill,
                                            )),
                                          ),
                                          SizedBox.expand(
                                              child: SvgPicture.string(
                                            _svg_w6qqk0,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          )),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(size: 18.0, start: 2.0),
                                    Pin(size: 7.3, middle: 0.5),
                                    child: Stack(
                                      children: <Widget>[
                                        Padding(
                                          padding: const EdgeInsets.all(-5.0),
                                          child: SizedBox.expand(
                                              child: SvgPicture.string(
                                            _svg_hy2fm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          )),
                                        ),
                                        SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_avi4k,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 15.3, end: 29.4),
                              Pin(size: 11.0, start: 2.3),
                              child: Stack(
                                children: <Widget>[
                                  Stack(
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.all(-5.0),
                                        child: SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_tav08,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                      ),
                                      SizedBox.expand(
                                          child: SvgPicture.string(
                                        _svg_iki5el,
                                        allowDrawingOutsideViewBox: true,
                                        fit: BoxFit.fill,
                                      )),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 17.0, end: 49.7),
                              Pin(size: 10.7, middle: 0.5),
                              child: Stack(
                                children: <Widget>[
                                  Stack(
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.all(-5.0),
                                        child: SizedBox.expand(
                                            child: SvgPicture.string(
                                          _svg_nqpuq1,
                                          allowDrawingOutsideViewBox: true,
                                          fit: BoxFit.fill,
                                        )),
                                      ),
                                      SizedBox.expand(
                                          child: SvgPicture.string(
                                        _svg_n4r2,
                                        allowDrawingOutsideViewBox: true,
                                        fit: BoxFit.fill,
                                      )),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 54.0, start: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child: Stack(
                                children: <Widget>[
                                  SizedBox.expand(
                                      child: SvgPicture.string(
                                    _svg_u6yej,
                                    allowDrawingOutsideViewBox: true,
                                    fit: BoxFit.fill,
                                  )),
                                  Pinned.fromPins(
                                    Pin(start: 12.8, end: 13.7),
                                    Pin(size: 10.3, end: 0.8),
                                    child: SvgPicture.string(
                                      _svg_snrsq,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Container(),
                Container(),
                Container(),
                Align(
                  alignment: const Alignment(-0.099, 0.255),
                  child: SizedBox(
                    width: 81.0,
                    height: 57.0,
                    child: Stack(
                      children: <Widget>[
                        Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(size: 10.0, end: 6.7),
                              child: SvgPicture.string(
                                _svg_pyv499,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(start: 12.1, end: 12.1),
                              Pin(size: 3.6, end: 0.0),
                              child: SvgPicture.string(
                                _svg_vlvtax,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(start: 14.5, end: 14.5),
                              Pin(size: 30.6, start: 0.0),
                              child: SvgPicture.string(
                                _svg_iv1,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Container(
                              decoration: const BoxDecoration(),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_d68v4 =
    '<svg viewBox="19.0 626.0 19.0 18.6" ><path transform="translate(-54.5, 548.89)" d="M 92.25342559814453 85.01753997802734 L 83.41555786132812 77.27140808105469 C 83.17037200927734 77.05654144287109 82.80403137207031 77.05654144287109 82.55885314941406 77.27140808105469 L 73.72097778320312 85.01753997802734 C 73.45111846923828 85.25408935546875 73.42408752441406 85.66466522216797 73.66062164306641 85.93459320068359 C 73.89716339111328 86.20446014404297 74.30782318115234 86.23149871826172 74.57768249511719 85.99495697021484 L 75.26200103759766 85.39517211914062 L 75.26200103759766 95.06041717529297 C 75.26200103759766 95.41928863525391 75.55291748046875 95.71025848388672 75.91183471679688 95.71025848388672 L 80.83676910400391 95.71025848388672 L 85.13763427734375 95.71025848388672 L 90.06258392333984 95.71025848388672 C 90.42148590087891 95.71025848388672 90.71240234375 95.41928863525391 90.71240234375 95.06041717529297 L 90.71240234375 85.39522552490234 L 91.39672088623047 85.99500274658203 C 91.52009582519531 86.10308074951172 91.67278289794922 86.15616607666016 91.82479095458984 86.15616607666016 C 92.00548553466797 86.15616607666016 92.18525695800781 86.08126068115234 92.31372833251953 85.93464660644531 C 92.55037689208984 85.66466522216797 92.52334594726562 85.25412750244141 92.25342559814453 85.01753997802734 Z M 81.48661041259766 94.41057586669922 L 81.48661041259766 89.05732727050781 L 84.48779296875 89.05732727050781 L 84.48779296875 94.41062927246094 L 81.48661041259766 94.41062927246094 Z M 89.41278839111328 84.26112365722656 L 89.41278839111328 94.41057586669922 L 85.78753662109375 94.41057586669922 L 85.78753662109375 88.407470703125 C 85.78753662109375 88.04855346679688 85.49657440185547 87.75763702392578 85.1376953125 87.75763702392578 L 80.83682250976562 87.75763702392578 C 80.47795104980469 87.75763702392578 80.18698120117188 88.04855346679688 80.18698120117188 88.407470703125 L 80.18698120117188 94.41062927246094 L 76.56173706054688 94.41062927246094 L 76.56173706054688 84.26112365722656 C 76.56173706054688 84.25946807861328 76.56151580810547 84.25789642333984 76.56151580810547 84.25627899169922 L 82.98723602294922 78.62422180175781 L 89.41304779052734 84.25623321533203 C 89.41304779052734 84.25789642333984 89.41278839111328 84.25946807861328 89.41278839111328 84.26112365722656 Z" fill="#515c6f" stroke="#515c6f" stroke-width="0.20000000298023224" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_xas88 =
    '<svg viewBox="101.0 627.0 17.0 17.0" ><path transform="translate(97.0, 623.0)" d="M 20.76047706604004 19.60336303710938 L 17.11709022521973 15.95997714996338 C 18.12488746643066 14.70018196105957 18.72727203369141 13.10227203369141 18.72727203369141 11.3636360168457 C 18.72727203369141 7.296863555908203 15.43061351776123 4 11.3636360168457 4 C 7.296863555908203 4 4 7.296863555908203 4 11.3636360168457 C 4 15.4304084777832 7.296863555908203 18.72727203369141 11.3636360168457 18.72727203369141 C 13.10227203369141 18.72727203369141 14.70018196105957 18.12468147277832 15.95997714996338 17.11688613891602 L 19.60336303710938 20.76027297973633 C 19.76311302185059 20.92002296447754 19.97256660461426 21 20.18181800842285 21 C 20.39127349853516 21 20.60072708129883 20.92002296447754 20.76047706604004 20.76027297973633 C 21.07997703552246 20.44097709655762 21.07997703552246 19.92265892028809 20.76047706604004 19.60336303710938 Z M 11.3636360168457 17.09090995788574 C 8.200545310974121 17.09090995788574 5.636363983154297 14.52672672271729 5.636363983154297 11.3636360168457 C 5.636363983154297 8.200545310974121 8.200545310974121 5.636363983154297 11.3636360168457 5.636363983154297 C 14.52693176269531 5.636363983154297 17.09090995788574 8.200545310974121 17.09090995788574 11.3636360168457 C 17.09090995788574 14.52672672271729 14.52693176269531 17.09090995788574 11.3636360168457 17.09090995788574 Z" fill="#ff6969" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_ahnr0 =
    '<svg viewBox="178.0 626.0 18.5 18.0" ><path transform="translate(104.5, 547.16)" d="M 91.40633392333984 81.63162231445312 L 77.98178100585938 81.63162231445312 L 77.20851898193359 79.81398010253906 C 77.12937927246094 79.62793731689453 76.96635437011719 79.49073028564453 76.76959991455078 79.44440460205078 L 74.27919006347656 78.85844421386719 C 73.93779754638672 78.77787017822266 73.59590911865234 78.98971557617188 73.51564025878906 79.33116149902344 C 73.43527221679688 79.67254638671875 73.64691162109375 80.01438903808594 73.98835754394531 80.09471130371094 L 76.16571807861328 80.60704040527344 L 81.73983001708984 93.71003723144531 C 81.56720733642578 94.014892578125 81.46804046630859 94.36669921875 81.46804046630859 94.74135589599609 C 81.46804046630859 95.89928436279297 82.41011810302734 96.84134674072266 83.56803894042969 96.84134674072266 C 84.7259521484375 96.84134674072266 85.66802215576172 95.89933776855469 85.66802215576172 94.74135589599609 C 85.66802215576172 94.45051574707031 85.60848999023438 94.17333984375 85.50113677978516 93.92121124267578 L 87.78772735595703 93.92121124267578 C 87.68038177490234 94.17329406738281 87.62084197998047 94.45046997070312 87.62084197998047 94.74135589599609 C 87.62084197998047 95.89928436279297 88.56295776367188 96.84134674072266 89.720947265625 96.84134674072266 C 90.87881469726562 96.84134674072266 91.82082366943359 95.89933776855469 91.82082366943359 94.74135589599609 C 91.82082366943359 93.58338165283203 90.87881469726562 92.64136505126953 89.720947265625 92.64136505126953 L 82.66960144042969 92.65116882324219 L 81.79987335205078 90.60675048828125 L 91.40638732910156 90.60675048828125 C 91.75711822509766 90.60675048828125 92.04141235351562 90.32242584228516 92.04141235351562 89.97172546386719 L 92.04141235351562 82.26663970947266 C 92.04135131835938 81.91594696044922 91.75706481933594 81.63162231445312 91.40633392333984 81.63162231445312 Z M 89.72220611572266 93.91207122802734 C 90.18049621582031 93.91207122802734 90.55199432373047 94.28358459472656 90.55199432373047 94.74181365966797 C 90.55199432373047 95.20005035400391 90.18049621582031 95.57155609130859 89.72221374511719 95.57155609130859 C 89.26392364501953 95.57155609130859 88.89246368408203 95.20005035400391 88.89246368408203 94.74181365966797 C 88.89246368408203 94.28358459472656 89.26392364501953 93.91207122802734 89.72220611572266 93.91207122802734 Z M 83.57118225097656 93.91207122802734 C 84.02947235107422 93.91207122802734 84.40097808837891 94.28358459472656 84.40097808837891 94.74181365966797 C 84.40097808837891 95.20005035400391 84.02947235107422 95.57155609130859 83.57118225097656 95.57155609130859 C 83.11289978027344 95.57155609130859 82.74143218994141 95.20005035400391 82.74143218994141 94.74181365966797 C 82.74143218994141 94.28358459472656 83.11296081542969 93.91207122802734 83.57118225097656 93.91207122802734 Z M 90.77130889892578 85.48416900634766 L 86.56217956542969 85.48416900634766 C 86.21150970458984 85.48416900634766 85.92716217041016 85.76850128173828 85.92716217041016 86.11919403076172 C 85.92716217041016 86.46987152099609 86.21150970458984 86.75421142578125 86.56217956542969 86.75421142578125 L 90.77130889892578 86.75421142578125 L 90.77130889892578 89.33670806884766 L 81.25960540771484 89.33670806884766 L 78.52205657958984 82.90165710449219 L 90.77130889892578 82.90165710449219 L 90.77130889892578 85.48416900634766 Z" fill="#515c6f" stroke="#515c6f" stroke-width="0.10000000149011612" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_ij0dtz =
    '<svg viewBox="257.0 626.0 18.0 18.0" ><path transform="translate(257.0, 626.0)" d="M 16.72729110717773 12.93928909301758 C 16.19600677490234 12.40814399719238 15.30696773529053 11.94449996948242 13.90548801422119 11.24347877502441 C 13.19898223876953 10.89022636413574 12.02306652069092 10.30254936218262 11.73801708221436 10.03339195251465 C 12.93179225921631 8.566100120544434 13.62465763092041 6.908820629119873 13.62465763092041 5.458121776580811 C 13.62465763092041 4.473739147186279 13.62465763092041 3.248745203018188 13.0736837387085 2.156221151351929 C 12.57699298858643 1.172259211540222 11.46703147888184 0 9.000168800354004 0 C 6.532743453979492 0 5.422781467437744 1.172259211540222 4.926652431488037 2.156079292297363 C 4.37497615814209 3.248744010925293 4.37497615814209 4.473597526550293 4.37497615814209 5.457980155944824 C 4.37497615814209 6.909241676330566 5.067278385162354 8.566098213195801 6.261756420135498 10.03325080871582 C 5.976004123687744 10.30297088623047 4.800229549407959 10.89078807830811 4.093723773956299 11.24333763122559 C 2.692665576934814 11.94421863555908 1.803627729415894 12.40786170959473 1.271920442581177 12.93914794921875 C 0.09502046555280685 14.1168909072876 0.006004222203046083 16.09282875061035 -4.273137892596424e-05 16.47729873657227 C -0.006089653819799423 16.87836456298828 0.1488803029060364 17.26607131958008 0.4312575161457062 17.55280876159668 C 0.7125096917152405 17.83841896057129 1.098247170448303 18 1.49931275844574 18 L 16.49975967407227 18 C 16.90194892883301 18 17.28670310974121 17.83856010437012 17.56851768493652 17.55280876159668 C 17.85033226013184 17.26607131958008 18.00586318969727 16.87822532653809 17.99981689453125 16.47673797607422 C 17.99377059936523 16.09296989440918 17.90405082702637 14.11703300476074 16.72729110717773 12.93928909301758 Z M 16.76737022399902 16.76305389404297 C 16.69593238830566 16.83505439758301 16.60087013244629 16.87513160705566 16.49975967407227 16.87513160705566 L 1.499312877655029 16.87513160705566 C 1.399890303611755 16.87513160705566 1.302717685699463 16.83449172973633 1.232826352119446 16.76305389404297 C 1.163075804710388 16.69217872619629 1.123559951782227 16.59444427490234 1.124544262886047 16.49445724487305 C 1.127778768539429 16.3060188293457 1.179529190063477 14.62342739105225 2.067442178726196 13.73523235321045 C 2.477367401123047 13.32544803619385 3.33546781539917 12.88107013702393 4.597024917602539 12.24979782104492 C 5.943660736083984 11.57690143585205 6.690385341644287 11.17583656311035 7.034356594085693 10.85070991516113 L 7.793597221374512 10.1328125 L 7.134342193603516 9.323087692260742 C 6.095959186553955 8.047608375549316 5.499845027923584 6.638535022735596 5.499845027923584 5.45811939239502 C 5.499845027923584 4.547846794128418 5.499845027923584 3.516775846481323 5.930582523345947 2.663175582885742 C 6.446398735046387 1.642512917518616 7.478172302246094 1.125008821487427 9.000168800354004 1.125008821487427 C 10.52089977264404 1.125008821487427 11.55379772186279 1.642512917518616 12.06919193267822 2.662614583969116 C 12.4999303817749 3.516777515411377 12.4999303817749 4.547848224639893 12.4999303817749 5.458120822906494 C 12.4999303817749 6.638114452362061 11.90437889099121 8.04704761505127 10.86473083496094 9.323088645935059 L 10.20547485351562 10.133376121521 L 10.96485614776611 10.85085010528564 C 11.30868625640869 11.17555522918701 12.05484867095947 11.57648086547852 13.4020471572876 12.24993896484375 C 14.66360378265381 12.88050651550293 15.52170372009277 13.32502460479736 15.9316291809082 13.73537158966064 C 16.65416717529297 14.45776844024658 16.86454391479492 15.80960655212402 16.87438774108887 16.49459648132324 C 16.8762149810791 16.59444236755371 16.83712196350098 16.69217681884766 16.76737022399902 16.76305389404297 Z" fill="#515c6f" stroke="#515c6f" stroke-width="0.30000001192092896" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_nmdgvf =
    '<svg viewBox="338.5 629.5 18.0 12.0" ><path transform="translate(338.5, 629.5)" d="M 0 11.99970054626465 L 18 11.99970054626465 L 0 11.99970054626465 Z M 0 6.00029993057251 L 18 6.00029993057251 L 0 6.00029993057251 Z M 0 0 L 18 0 L 0 0 Z" fill="none" stroke="#515c6f" stroke-width="1.2999999523162842" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_rs6te1 =
    '<svg viewBox="104.0 128.0 11.0 11.0" ><path transform="translate(100.0, 124.0)" d="M 14.84501552581787 14.09629344940186 L 12.4875316619873 11.73880863189697 C 13.13963508605957 10.92364692687988 13.52941226959229 9.889705657958984 13.52941226959229 8.764705657958984 C 13.52941226959229 6.133265018463135 11.39628124237061 4 8.764706611633301 4 C 6.133265495300293 4 4 6.133265018463135 4 8.764705657958984 C 4 11.39614677429199 6.133265495300293 13.52941036224365 8.764706611633301 13.52941036224365 C 9.889706611633301 13.52941036224365 10.92364883422852 13.13949871063232 11.73881053924561 12.48739624023438 L 14.09629535675049 14.84488296508789 C 14.19966316223145 14.94824981689453 14.33519077301025 15 14.47058963775635 15 C 14.60612010955811 15 14.74164772033691 14.94824981689453 14.84501552581787 14.84488296508789 C 15.05175113677979 14.63827896118164 15.05175113677979 14.30289936065674 14.84501552581787 14.09629344940186 Z M 8.764706611633301 12.47058773040771 C 6.718000411987305 12.47058773040771 5.05882453918457 10.81141090393066 5.05882453918457 8.764705657958984 C 5.05882453918457 6.717999935150146 6.718000411987305 5.05882453918457 8.764706611633301 5.05882453918457 C 10.81154632568359 5.05882453918457 12.47058963775635 6.717999935150146 12.47058963775635 8.764705657958984 C 12.47058963775635 10.81141090393066 10.81154632568359 12.47058773040771 8.764706611633301 12.47058773040771 Z" fill="#515c6f" fill-opacity="0.4" stroke="none" stroke-width="1" stroke-opacity="0.4" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_t474y =
    '<svg viewBox="66.9 420.8 11.7 17.0" ><path transform="translate(-56.89, 420.8)" d="M 135.4375 10.09375 L 134.3749847412109 10.09375 C 133.8915710449219 12.22246360778809 131.8685455322266 13.81250095367432 129.59375 13.81250095367432 C 127.3189544677734 13.81250095367432 125.2959365844727 12.22246360778809 124.8125 10.09375 L 123.7500076293945 10.09375 C 124.2190933227539 12.64321517944336 126.4397201538086 14.61467838287354 129.0625 14.85110950469971 L 129.0625 15.93750190734863 L 128.53125 15.93750190734863 C 128.2379913330078 15.93750190734863 128 16.17550277709961 128 16.46875190734863 C 128 16.76200294494629 128.2379913330078 17 128.53125 17 L 130.65625 17 C 130.9495086669922 17 131.1875 16.76200294494629 131.1875 16.46875190734863 C 131.1875 16.17550277709961 130.9495086669922 15.93750190734863 130.65625 15.93750190734863 L 130.125 15.93750190734863 L 130.125 14.85111141204834 C 132.7477722167969 14.61467838287354 134.9684143066406 12.64321517944336 135.4375 10.09375 Z M 129.59375 12.75000095367432 C 131.6475677490234 12.75000095367432 133.3125 11.08507442474365 133.3125 9.03125 L 133.3125 3.718750238418579 C 133.3125 1.664926886558533 131.6475677490234 0 129.59375 0 C 127.5399322509766 0 125.8750076293945 1.664926886558533 125.8750076293945 3.718750238418579 L 125.8750076293945 9.03125 C 125.8750076293945 11.08507442474365 127.5399322509766 12.75000095367432 129.59375 12.75000095367432 Z M 126.9375 3.718750238418579 C 126.9375 2.25196361541748 128.126953125 1.0625 129.59375 1.0625 C 131.060546875 1.0625 132.25 2.25196361541748 132.25 3.718750238418579 L 132.25 9.03125 C 132.25 10.49803638458252 131.060546875 11.68750095367432 129.59375 11.68750095367432 C 128.126953125 11.68750095367432 126.9375 10.49803638458252 126.9375 9.03125 L 126.9375 3.718750238418579 Z" fill="#727c8e" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_i4lwc =
    '<svg viewBox="336.0 17.3 22.0 11.3" ><path transform="translate(336.0, 17.33)" d="M 2.666666984558105 0 L 19.33333015441895 0 L 19.33333015441895 0 C 20.80608940124512 0 22 1.193907022476196 22 2.666666984558105 L 22 8.666666984558105 L 22 8.666666984558105 C 22 10.13943004608154 20.80608940124512 11.33333015441895 19.33333015441895 11.33333015441895 L 2.666666984558105 11.33333015441895 L 2.666666984558105 11.33333015441895 C 1.193907022476196 11.33333015441895 0 10.13943004608154 0 8.666666984558105 L 0 2.666666984558105 L 0 2.666666984558105 C 0 1.193907022476196 1.193907022476196 0 2.666666984558105 0 Z" fill="none" stroke="#000000" stroke-width="2" stroke-opacity="0.35" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_hn =
    '<svg viewBox="336.0 17.3 22.0 11.3" ><path transform="translate(0.0, 44.0)" d="M 338.6666870117188 -26.66666984558105 L 355.3333129882812 -26.66666984558105 L 355.3333129882812 -26.66666984558105 C 356.8060913085938 -26.66666984558105 358 -25.47275924682617 358 -24 L 358 -18 L 358 -18 C 358 -16.52724075317383 356.8060913085938 -15.33333015441895 355.3333129882812 -15.33333015441895 L 338.6666870117188 -15.33333015441895 L 338.6666870117188 -15.33333015441895 C 337.1939086914062 -15.33333015441895 336 -16.52724075317383 336 -18 L 336 -24 L 336 -24 C 336 -25.47275924682617 337.1939086914062 -26.66666984558105 338.6666870117188 -26.66666984558105 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tszyk4 =
    '<svg viewBox="354.0 16.0 11.3 14.0" ><path transform="translate(0.0, 44.0)" d="M 354 -28 L 365.3280029296875 -28 L 365.3280029296875 -14 L 354 -14 L 354 -28 Z" fill="#000000" fill-opacity="0.4" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_w6qqk0 =
    '<svg viewBox="359.0 21.0 1.3 4.0" ><path transform="translate(0.0, 44.0)" d="M 359 -23 L 359 -19 C 359.8046875 -19.33877944946289 360.3280029296875 -20.12686920166016 360.3280029296875 -21 C 360.3280029296875 -21.87313079833984 359.8046875 -22.66122055053711 359 -23" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_hy2fm =
    '<svg viewBox="333.0 14.3 28.0 17.3" ><path transform="translate(0.0, 44.0)" d="M 333 -29.66666984558105 L 361 -29.66666984558105 L 361 -12.33333015441895 L 333 -12.33333015441895 L 333 -29.66666984558105 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_avi4k =
    '<svg viewBox="338.0 19.3 18.0 7.3" ><path transform="translate(0.0, 44.0)" d="M 339.3333129882812 -24.66666984558105 L 354.6666870117188 -24.66666984558105 L 354.6666870117188 -24.66666984558105 C 355.4030151367188 -24.66666984558105 356 -24.06970977783203 356 -23.33333015441895 L 356 -18.66666984558105 L 356 -18.66666984558105 C 356 -17.93029022216797 355.4030151367188 -17.33333015441895 354.6666870117188 -17.33333015441895 L 339.3333129882812 -17.33333015441895 L 339.3333129882812 -17.33333015441895 C 338.5969848632812 -17.33333015441895 338 -17.93029022216797 338 -18.66666984558105 L 338 -23.33333015441895 L 338 -23.33333015441895 C 338 -24.06970977783203 338.5969848632812 -24.66666984558105 339.3333129882812 -24.66666984558105 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tav08 =
    '<svg viewBox="310.7 12.3 25.3 21.0" ><path transform="translate(0.0, 44.0)" d="M 310.6936950683594 -31.66933059692383 L 335.9660949707031 -31.66933059692383 L 335.9660949707031 -10.70376014709473 L 310.6936950683594 -10.70376014709473 L 310.6936950683594 -31.66933059692383 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_iki5el =
    '<svg viewBox="315.7 17.3 15.3 11.0" ><path transform="translate(0.0, 44.0)" d="M 323.3302917480469 -24.39200019836426 C 325.5462036132812 -24.39189910888672 327.6773986816406 -23.54047012329102 329.2832946777344 -22.01366996765137 C 329.404296875 -21.89579010009766 329.5975952148438 -21.89727973937988 329.7167053222656 -22.01700019836426 L 330.8727111816406 -23.18367004394531 C 330.9330139160156 -23.2443904876709 330.9666137695312 -23.32663917541504 330.9660949707031 -23.4122200012207 C 330.9656066894531 -23.49780082702637 330.9309997558594 -23.57965087890625 330.8699951171875 -23.63966941833496 C 326.6549072265625 -27.6792106628418 320.0050964355469 -27.6792106628418 315.7900085449219 -23.63966941833496 C 315.7289123535156 -23.5797004699707 315.6943054199219 -23.49786949157715 315.6936950683594 -23.41229057312012 C 315.6932067871094 -23.32670974731445 315.7267150878906 -23.24443054199219 315.7869873046875 -23.18367004394531 L 316.9432983398438 -22.01700019836426 C 317.0624084472656 -21.8971004486084 317.2557983398438 -21.89561080932617 317.376708984375 -22.01366996765137 C 318.9827880859375 -23.54056930541992 321.1141967773438 -24.39200973510742 323.3302917480469 -24.39200019836426 L 323.3302917480469 -24.39200019836426 Z M 323.3302917480469 -20.5963306427002 C 324.5477905273438 -20.59641075134277 325.7218933105469 -20.14388084411621 326.6242980957031 -19.32666969299316 C 326.7463989257812 -19.21068954467773 326.9386901855469 -19.21319961547852 327.0577087402344 -19.33233070373535 L 328.2123107910156 -20.49900054931641 C 328.2731018066406 -20.56019020080566 328.306884765625 -20.64320945739746 328.3059997558594 -20.7294807434082 C 328.3051147460938 -20.81574058532715 328.2697143554688 -20.89805030822754 328.2077026367188 -20.95800018310547 C 325.4595031738281 -23.51437950134277 321.2034912109375 -23.51437950134277 318.4552917480469 -20.95800018310547 C 318.393310546875 -20.89805030822754 318.3577880859375 -20.81570053100586 318.3569946289062 -20.72941017150879 C 318.356201171875 -20.64311981201172 318.3901062011719 -20.56011009216309 318.4509887695312 -20.49900054931641 L 319.6052856445312 -19.33233070373535 C 319.7243041992188 -19.21319961547852 319.9165954589844 -19.21068954467773 320.0386962890625 -19.32666969299316 C 320.9404907226562 -20.14333915710449 322.1135864257812 -20.5958309173584 323.3302917480469 -20.5963306427002 L 323.3302917480469 -20.5963306427002 Z M 325.5492858886719 -17.8120002746582 C 325.6111145019531 -17.87261009216309 325.6451110839844 -17.95601081848145 325.643310546875 -18.04250907897949 C 325.6416015625 -18.12902069091797 325.6041870117188 -18.21096992492676 325.5400085449219 -18.26899909973145 C 324.264404296875 -19.34787940979004 322.3962097167969 -19.34787940979004 321.1206970214844 -18.26899909973145 C 321.056396484375 -18.21100997924805 321.0190124511719 -18.12908935546875 321.0172119140625 -18.04258918762207 C 321.0152893066406 -17.95607948303223 321.0492858886719 -17.87265014648438 321.1109924316406 -17.8120002746582 L 323.1087036132812 -15.79633045196533 C 323.1672058105469 -15.73709011077881 323.2470092773438 -15.70376014709473 323.3302917480469 -15.70376014709473 C 323.4136047363281 -15.70376014709473 323.493408203125 -15.73709011077881 323.552001953125 -15.79633045196533 L 325.5492858886719 -17.8120002746582 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_nqpuq1 =
    '<svg viewBox="288.7 12.7 27.0 20.7" ><path transform="translate(0.0, 44.0)" d="M 288.6666870117188 -31.33333015441895 L 315.6666870117188 -31.33333015441895 L 315.6666870117188 -10.66666984558105 L 288.6666870117188 -10.66666984558105 L 288.6666870117188 -31.33333015441895 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_n4r2 =
    '<svg viewBox="293.7 17.7 17.0 10.7" ><path transform="translate(0.0, 44.0)" d="M 294.6666870117188 -19.66666984558105 L 295.6666870117188 -19.66666984558105 C 296.218994140625 -19.66666984558105 296.6666870117188 -19.21895027160645 296.6666870117188 -18.66666984558105 L 296.6666870117188 -16.66666984558105 C 296.6666870117188 -16.1143798828125 296.218994140625 -15.66666984558105 295.6666870117188 -15.66666984558105 L 294.6666870117188 -15.66666984558105 C 294.1144104003906 -15.66666984558105 293.6666870117188 -16.1143798828125 293.6666870117188 -16.66666984558105 L 293.6666870117188 -18.66666984558105 C 293.6666870117188 -19.21895027160645 294.1144104003906 -19.66666984558105 294.6666870117188 -19.66666984558105 L 294.6666870117188 -19.66666984558105 Z M 299.3333129882812 -21.66666984558105 L 300.3333129882812 -21.66666984558105 C 300.8855895996094 -21.66666984558105 301.3333129882812 -21.21895027160645 301.3333129882812 -20.66666984558105 L 301.3333129882812 -16.66666984558105 C 301.3333129882812 -16.1143798828125 300.8855895996094 -15.66666984558105 300.3333129882812 -15.66666984558105 L 299.3333129882812 -15.66666984558105 C 298.781005859375 -15.66666984558105 298.3333129882812 -16.1143798828125 298.3333129882812 -16.66666984558105 L 298.3333129882812 -20.66666984558105 C 298.3333129882812 -21.21895027160645 298.781005859375 -21.66666984558105 299.3333129882812 -21.66666984558105 Z M 304 -24 L 305 -24 C 305.5523071289062 -24 306 -23.55228042602539 306 -23 L 306 -16.66666984558105 C 306 -16.1143798828125 305.5523071289062 -15.66666984558105 305 -15.66666984558105 L 304 -15.66666984558105 C 303.4476928710938 -15.66666984558105 303 -16.1143798828125 303 -16.66666984558105 L 303 -23 C 303 -23.55228042602539 303.4476928710938 -24 304 -24 Z M 308.6666870117188 -26.33333015441895 L 309.6666870117188 -26.33333015441895 C 310.218994140625 -26.33333015441895 310.6666870117188 -25.8856201171875 310.6666870117188 -25.33333015441895 L 310.6666870117188 -16.66666984558105 C 310.6666870117188 -16.1143798828125 310.218994140625 -15.66666984558105 309.6666870117188 -15.66666984558105 L 308.6666870117188 -15.66666984558105 C 308.1144104003906 -15.66666984558105 307.6666870117188 -16.1143798828125 307.6666870117188 -16.66666984558105 L 307.6666870117188 -25.33333015441895 C 307.6666870117188 -25.8856201171875 308.1144104003906 -26.33333015441895 308.6666870117188 -26.33333015441895 L 308.6666870117188 -26.33333015441895 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_u6yej =
    '<svg viewBox="29.0 15.0 54.0 16.0" ><path transform="translate(8.0, 50.0)" d="M 21 -19 L 75 -19 L 75 -35 L 21 -35 L 21 -19 Z" fill="none" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_snrsq =
    '<svg viewBox="41.8 19.9 27.5 10.3" ><path transform="translate(29.0, 17.0)" d="M 16.43259620666504 13.2392578125 C 18.94138526916504 13.2392578125 20.43161964416504 11.27734375 20.43161964416504 7.955078125 C 20.43161964416504 6.7041015625 20.19236183166504 5.6513671875 19.73435401916504 4.837890625 C 19.07126808166504 3.5732421875 17.92966651916504 2.8896484375 16.48728370666504 2.8896484375 C 14.34079933166504 2.8896484375 12.82322120666504 4.33203125 12.82322120666504 6.35546875 C 12.82322120666504 8.255859375 14.19040870666504 9.63671875 16.07029151916504 9.63671875 C 17.22556495666504 9.63671875 18.16208839416504 9.0966796875 18.62693214416504 8.16015625 L 18.64743995666504 8.16015625 C 18.64743995666504 8.16015625 18.67478370666504 8.16015625 18.68161964416504 8.16015625 C 18.69529151916504 8.16015625 18.74314308166504 8.16015625 18.74314308166504 8.16015625 C 18.74314308166504 10.416015625 17.88865089416504 11.7626953125 16.44626808166504 11.7626953125 C 15.59861183166504 11.7626953125 14.94236183166504 11.2978515625 14.71677589416504 10.552734375 L 12.95993995666504 10.552734375 C 13.25388526916504 12.1728515625 14.62790870666504 13.2392578125 16.43259620666504 13.2392578125 Z M 16.49411964416504 8.2353515625 C 15.35935401916504 8.2353515625 14.55271339416504 7.4287109375 14.55271339416504 6.30078125 C 14.55271339416504 5.2001953125 15.40036964416504 4.359375 16.50095558166504 4.359375 C 17.60154151916504 4.359375 18.44919776916504 5.2138671875 18.44919776916504 6.328125 C 18.44919776916504 7.4287109375 17.62204933166504 8.2353515625 16.49411964416504 8.2353515625 Z M 23.53221893310547 11.9541015625 C 24.18163299560547 11.9541015625 24.62596893310547 11.4892578125 24.62596893310547 10.8740234375 C 24.62596893310547 10.251953125 24.18163299560547 9.7939453125 23.53221893310547 9.7939453125 C 22.88964080810547 9.7939453125 22.43846893310547 10.251953125 22.43846893310547 10.8740234375 C 22.43846893310547 11.4892578125 22.88964080810547 11.9541015625 23.53221893310547 11.9541015625 Z M 23.53221893310547 6.8271484375 C 24.18163299560547 6.8271484375 24.62596893310547 6.369140625 24.62596893310547 5.75390625 C 24.62596893310547 5.1318359375 24.18163299560547 4.673828125 23.53221893310547 4.673828125 C 22.88964080810547 4.673828125 22.43846893310547 5.1318359375 22.43846893310547 5.75390625 C 22.43846893310547 6.369140625 22.88964080810547 6.8271484375 23.53221893310547 6.8271484375 Z M 31.44532012939453 13 L 33.13379669189453 13 L 33.13379669189453 11.1611328125 L 34.46680450439453 11.1611328125 L 34.46680450439453 9.6708984375 L 33.13379669189453 9.6708984375 L 33.13379669189453 3.1357421875 L 30.64551544189453 3.1357421875 C 28.90235137939453 5.7607421875 27.51465606689453 7.955078125 26.62598419189453 9.5888671875 L 26.62598419189453 11.1611328125 L 31.44532012939453 11.1611328125 L 31.44532012939453 13 Z M 28.25977325439453 9.609375 C 29.40821075439453 7.5859375 30.43360137939453 5.9658203125 31.37696075439453 4.5712890625 L 31.47266387939453 4.5712890625 C 31.47266387939453 4.5712890625 31.47266387939453 6.256190299987793 31.47266387939453 7.541346549987793 C 31.47266387939453 8.826502799987793 31.47266387939453 9.7119140625 31.47266387939453 9.7119140625 L 28.25977325439453 9.7119140625 L 28.25977325439453 9.609375 Z M 38.51076507568359 13 L 40.27443695068359 13 L 40.27443695068359 3.1357421875 L 38.51760101318359 3.1357421875 L 35.94045257568359 4.9404296875 L 35.94045257568359 6.6357421875 L 38.39455413818359 4.9130859375 L 38.51076507568359 4.9130859375 L 38.51076507568359 13 Z" fill="#000000" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_mhz2ca =
    '<svg viewBox="0.0 70.0 375.0 44.0" ><path transform="translate(0.0, 114.0)" d="M 0 -44 L 375 -44 L 375 0 L 0 0 L 0 -44 Z" fill="#ffffff" fill-opacity="0.0" stroke="none" stroke-width="1" stroke-opacity="0.0" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_jzx0na =
    '<svg viewBox="0.0 0.0 375.0 119.0" ><path  d="M 0 0 L 375 0 L 375 119 L 0 119 L 0 0 Z" fill="#ecf9fe" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_pyv499 =
    '<svg viewBox="0.0 40.6 81.1 10.0" ><path transform="translate(0.0, -252.8)" d="M 75.88474273681641 295.4244079589844 L 81.07770538330078 295.4244079589844 L 81.07770538330078 293.5283203125 L 73.76620483398438 293.5283203125 L 73.76620483398438 295.4244079589844 L 75.88474273681641 295.4244079589844 Z M 81.14710998535156 303.2200622558594 L 81.14710998535156 301.3232727050781 L 75.88474273681641 301.3232727050781 L 75.88474273681641 299.2883911132812 L 80.45461273193359 299.2883911132812 L 80.45461273193359 297.3911743164062 L 75.88474273681641 297.3911743164062 L 73.76620483398438 297.3911743164062 L 73.76620483398438 303.2200622558594 L 81.14710998535156 303.2200622558594 Z M 70.82423400878906 293.5283203125 L 68.52595520019531 293.5283203125 L 65.99197387695312 300.3544311523438 L 63.45757293701172 293.5283203125 L 61.10372161865234 293.5283203125 L 65.02284240722656 303.2900390625 L 66.90553283691406 303.2900390625 L 70.82423400878906 293.5283203125 Z M 58.06470489501953 293.5283203125 L 55.93246841430664 293.5283203125 L 55.93246841430664 303.22021484375 L 58.06470489501953 303.22021484375 L 58.06470489501953 293.5283203125 Z M 52.75561904907227 295.494384765625 L 52.75561904907227 293.5283203125 L 44.72355270385742 293.5283203125 L 44.72355270385742 295.494384765625 L 47.67339706420898 295.494384765625 L 47.67339706420898 303.2200622558594 L 49.80577087402344 303.2200622558594 L 49.80577087402344 295.494384765625 L 52.75561904907227 295.494384765625 Z M 43.72040557861328 303.2200622558594 L 39.56654357910156 293.4583740234375 L 37.60006713867188 293.4583740234375 L 33.44564437866211 303.2200622558594 L 35.61977005004883 303.2200622558594 C 37.03945922851562 299.7372741699219 37.08674240112305 299.6053771972656 38.55593109130859 296.0198669433594 C 40.05179595947266 299.6732788085938 40.02774429321289 299.6300048828125 41.49111938476562 303.2200622558594 L 43.72040557861328 303.2200622558594 Z M 25.6710033416748 295.4244079589844 L 30.86396026611328 295.4244079589844 L 30.86396026611328 293.5283203125 L 23.55301094055176 293.5283203125 L 23.55301094055176 295.4244079589844 L 25.6710033416748 295.4244079589844 Z M 30.93280792236328 303.2200622558594 L 30.93280792236328 301.3232727050781 L 25.6710033416748 301.3232727050781 L 25.6710033416748 299.2883911132812 L 30.24031257629395 299.2883911132812 L 30.24031257629395 297.3911743164062 L 25.6710033416748 297.3911743164062 L 23.55301094055176 297.3911743164062 L 23.55301094055176 303.2200622558594 L 30.93280792236328 303.2200622558594 Z M 18.02133750915527 296.8646850585938 C 18.02133750915527 297.6817626953125 17.42575645446777 298.2360229492188 16.38722038269043 298.2360229492188 L 14.22733688354492 298.2360229492188 L 14.22733688354492 295.452880859375 L 16.34574508666992 295.452880859375 C 17.38442039489746 295.452880859375 18.02133750915527 295.9234924316406 18.02133750915527 296.8369140625 L 18.02133750915527 296.8646850585938 Z M 20.47265434265137 303.2200622558594 L 18.10456466674805 299.7588500976562 C 19.33651351928711 299.3021850585938 20.18122100830078 298.3185424804688 20.18122100830078 296.75439453125 L 20.18122100830078 296.7268676757812 C 20.18122100830078 294.7323608398438 18.81088447570801 293.5283203125 16.52547073364258 293.5283203125 L 12.09441089630127 293.5283203125 L 12.09441089630127 303.2200622558594 L 14.22733688354492 303.2200622558594 L 14.22733688354492 300.1192626953125 L 15.90279102325439 300.1192626953125 L 17.97958755493164 303.2200622558594 L 20.47265434265137 303.2200622558594 Z M 8.945208549499512 301.6559143066406 L 7.588143348693848 300.2855834960938 C 6.826661109924316 300.9776611328125 6.147990226745605 301.4205932617188 5.040467262268066 301.4205932617188 C 3.378698587417603 301.4205932617188 2.229285717010498 300.0364379882812 2.229285717010498 298.3748168945312 L 2.229285717010498 298.34619140625 C 2.229285717010498 296.6844482421875 3.406210422515869 295.3277587890625 5.040467262268066 295.3277587890625 C 6.009601593017578 295.3277587890625 6.771083831787109 295.7432250976562 7.519294261932373 296.421630859375 L 8.875805854797363 294.8572998046875 C 7.976073265075684 293.9702758789062 6.881822109222412 293.3619995117188 5.054153442382812 293.3619995117188 C 2.077210426330566 293.3619995117188 0 295.6182250976562 0 298.3748168945312 L 0 298.40234375 C 0 301.1854248046875 2.118547439575195 303.3875122070312 4.971065521240234 303.3875122070312 C 6.839932441711426 303.3875122070312 7.948423385620117 302.7221069335938 8.945208549499512 301.6559143066406" fill="#00070f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_vlvtax =
    '<svg viewBox="12.1 53.7 57.0 3.6" ><path transform="translate(-75.39, -334.5)" d="M 144.4387664794922 391.6971435546875 L 144.4387664794922 388.2200317382812 L 143.6830749511719 388.2200317382812 L 143.6830749511719 390.3612670898438 L 142.053955078125 388.2200317382812 L 141.3486022949219 388.2200317382812 L 141.3486022949219 391.6971435546875 L 142.1037292480469 391.6971435546875 L 142.1037292480469 389.4861450195312 L 143.7874603271484 391.6971435546875 L 144.4387664794922 391.6971435546875 Z M 137.4654235839844 390.2422180175781 L 136.5409545898438 390.2422180175781 L 137.0032653808594 389.1139526367188 L 137.4654235839844 390.2422180175781 Z M 138.85595703125 391.6971435546875 L 137.3660278320312 388.1944580078125 L 136.6606750488281 388.1944580078125 L 135.1701965332031 391.6971435546875 L 135.9497985839844 391.6971435546875 L 136.2679138183594 390.9175720214844 L 137.7386169433594 390.9175720214844 L 138.0565795898438 391.6971435546875 L 138.85595703125 391.6971435546875 Z M 132.7774963378906 391.2049865722656 L 132.7774963378906 389.6947631835938 L 131.266845703125 389.6947631835938 L 131.266845703125 390.3562622070312 L 132.0371704101562 390.3562622070312 L 132.0371704101562 390.8524780273438 C 131.8432006835938 390.9923706054688 131.5951843261719 391.0612182617188 131.3164672851562 391.0612182617188 C 130.7006988525391 391.0612182617188 130.2637023925781 390.5946044921875 130.2637023925781 389.9586791992188 L 130.2637023925781 389.9488525390625 C 130.2637023925781 389.3571472167969 130.7056884765625 388.8659362792969 131.2624206542969 388.8659362792969 C 131.6645812988281 388.8659362792969 131.9027862548828 388.9949340820312 132.1709899902344 389.2183227539062 L 132.6533508300781 388.6365661621094 C 132.2901611328125 388.3294067382812 131.91259765625 388.1600341796875 131.2870178222656 388.1600341796875 C 130.2335510253906 388.1600341796875 129.4637756347656 388.9703063964844 129.4637756347656 389.9586791992188 L 129.4637756347656 389.9683532714844 C 129.4637756347656 390.9971923828125 130.2089385986328 391.7572937011719 131.2919921875 391.7572937011719 C 131.9278106689453 391.7572937011719 132.4195556640625 391.5081787109375 132.7774963378906 391.2049865722656 M 126.1817169189453 389.9683532714844 C 126.1817169189453 390.5650329589844 125.7543792724609 391.0513916015625 125.1386108398438 391.0513916015625 C 124.5224304199219 391.0513916015625 124.0852813720703 390.5542602539062 124.0852813720703 389.9586791992188 L 124.0852813720703 389.9488525390625 C 124.0852813720703 389.3521728515625 124.5124740600586 388.8659362792969 125.1282424926758 388.8659362792969 C 125.7441558837891 388.8659362792969 126.1817169189453 389.3630981445312 126.1817169189453 389.9586791992188 L 126.1817169189453 389.9683532714844 Z M 126.9814910888672 389.9586791992188 L 126.9814910888672 389.9488525390625 C 126.9814910888672 388.9603576660156 126.2115783691406 388.1600341796875 125.1386108398438 388.1600341796875 C 124.0650939941406 388.1600341796875 123.285514831543 388.9703063964844 123.285514831543 389.9586791992188 L 123.285514831543 389.9683532714844 C 123.285514831543 390.9568481445312 124.0556945800781 391.7572937011719 125.1282424926758 391.7572937011719 C 126.2013473510742 391.7572937011719 126.9814910888672 390.947021484375 126.9814910888672 389.9586791992188 M 121.1058502197266 391.6971435546875 L 121.1058502197266 391.002197265625 L 119.3721923828125 391.002197265625 L 119.3721923828125 388.2200317382812 L 118.6073913574219 388.2200317382812 L 118.6073913574219 391.6971435546875 L 121.1058502197266 391.6971435546875 Z M 115.9857559204102 390.66943359375 L 115.9857559204102 390.6586303710938 C 115.9857559204102 390.05322265625 115.5885620117188 389.8002319335938 114.8832092285156 389.6160888671875 C 114.282096862793 389.4615173339844 114.132926940918 389.3875427246094 114.132926940918 389.1583251953125 L 114.132926940918 389.1483764648438 C 114.132926940918 388.9801330566406 114.2870788574219 388.84619140625 114.5798873901367 388.84619140625 C 114.8732528686523 388.84619140625 115.1760177612305 388.9751586914062 115.4841842651367 389.1889038085938 L 115.8813781738281 388.6119689941406 C 115.5289764404297 388.3294067382812 115.0962524414062 388.1699829101562 114.5896987915039 388.1699829101562 C 113.879508972168 388.1699829101562 113.3729629516602 388.5872192382812 113.3729629516602 389.2183227539062 L 113.3729629516602 389.2281494140625 C 113.3729629516602 389.9192504882812 113.8249053955078 390.1122436523438 114.525276184082 390.2913208007812 C 115.1066284179688 390.4400634765625 115.226203918457 390.5394592285156 115.226203918457 390.7333984375 L 115.226203918457 390.7432250976562 C 115.226203918457 390.947021484375 115.0372161865234 391.071044921875 114.7242202758789 391.071044921875 C 114.3268814086914 391.071044921875 113.9986801147461 390.9075927734375 113.685546875 390.648681640625 L 113.2336044311523 391.190185546875 C 113.6511154174805 391.5633544921875 114.1826934814453 391.7463684082031 114.7088775634766 391.7463684082031 C 115.4590148925781 391.7463684082031 115.9857559204102 391.3595581054688 115.9857559204102 390.66943359375 M 107.0705490112305 389.4171447753906 C 107.0705490112305 389.7095336914062 106.8569488525391 389.9084777832031 106.4843597412109 389.9084777832031 L 105.7090606689453 389.9084777832031 L 105.7090606689453 388.91015625 L 106.4695739746094 388.91015625 C 106.842155456543 388.91015625 107.0705490112305 389.0795288085938 107.0705490112305 389.4073486328125 L 107.0705490112305 389.4171447753906 Z M 107.9496841430664 391.6971435546875 L 107.1005477905273 390.454833984375 C 107.5425338745117 390.2913208007812 107.8452987670898 389.9390258789062 107.8452987670898 389.3778686523438 L 107.8452987670898 389.366943359375 C 107.8452987670898 388.65234375 107.3535461425781 388.2200317382812 106.5339965820312 388.2200317382812 L 104.9441223144531 388.2200317382812 L 104.9441223144531 391.6971435546875 L 105.7090606689453 391.6971435546875 L 105.7090606689453 390.5847778320312 L 106.3105926513672 390.5847778320312 L 107.0557556152344 391.6971435546875 L 107.9496841430664 391.6971435546875 Z M 102.2088394165039 390.1820678710938 L 102.2088394165039 388.2200317382812 L 101.4434814453125 388.2200317382812 L 101.4434814453125 390.211669921875 C 101.4434814453125 390.7630004882812 101.1609039306641 391.0464172363281 100.6931991577148 391.0464172363281 C 100.2266082763672 391.0464172363281 99.94319152832031 390.7530517578125 99.94319152832031 390.1870727539062 L 99.94319152832031 388.2200317382812 L 99.17825317382812 388.2200317382812 L 99.17825317382812 390.2066955566406 C 99.17825317382812 391.2304077148438 99.74964141845703 391.7523193359375 100.6839370727539 391.7523193359375 C 101.61767578125 391.7523193359375 102.2088394165039 391.2355346679688 102.2088394165039 390.1820678710938 M 95.79664611816406 389.9683532714844 C 95.79664611816406 390.5650329589844 95.36946105957031 391.0513916015625 94.75369262695312 391.0513916015625 C 94.13778686523438 391.0513916015625 93.70022583007812 390.5542602539062 93.70022583007812 389.9586791992188 L 93.70022583007812 389.9488525390625 C 93.70022583007812 389.3521728515625 94.1275634765625 388.8659362792969 94.74373626708984 388.8659362792969 C 95.35950469970703 388.8659362792969 95.79664611816406 389.3630981445312 95.79664611816406 389.9586791992188 L 95.79664611816406 389.9683532714844 Z M 96.59656524658203 389.9586791992188 L 96.59656524658203 389.9488525390625 C 96.59656524658203 388.9603576660156 95.82665252685547 388.1600341796875 94.75369262695312 388.1600341796875 C 93.68059539794922 388.1600341796875 92.90045166015625 388.9703063964844 92.90045166015625 389.9586791992188 L 92.90045166015625 389.9683532714844 C 92.90045166015625 390.9568481445312 93.67063903808594 391.7572937011719 94.74373626708984 391.7572937011719 C 95.81683349609375 391.7572937011719 96.59656524658203 390.947021484375 96.59656524658203 389.9586791992188 M 90.92015075683594 388.2200317382812 L 90.0504150390625 388.2200317382812 L 89.20626068115234 389.6160888671875 L 88.37648010253906 388.2200317382812 L 87.48200225830078 388.2200317382812 L 88.81832885742188 390.3257141113281 L 88.81832885742188 391.6971435546875 L 89.58382415771484 391.6971435546875 L 89.58382415771484 390.3110656738281 L 90.92015075683594 388.2200317382812 Z" fill="#00070f" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
const String _svg_iv1 =
    '<svg viewBox="14.5 0.0 52.1 30.6" ><path transform="translate(-90.51, 0.0)" d="M 128.1074523925781 0 L 142.9529113769531 19.14102745056152 C 143.0213623046875 19.24499130249023 143.09765625 19.34328651428223 143.1808776855469 19.43536186218262 C 143.6115417480469 19.90845680236816 144.2321472167969 20.2047233581543 144.9217376708984 20.2047233581543 C 146.8089904785156 20.2047233581543 147.8972930908203 18.10940361022949 146.8966369628906 16.56971168518066 C 146.8252868652344 16.45993995666504 146.7449798583984 16.35652923583984 146.6563720703125 16.26058197021484 L 139.7579345703125 7.365560531616211 L 151.1445159912109 7.365560531616211 C 154.4538269042969 7.365560531616211 157.1364135742188 10.04830646514893 157.1364135742188 13.35788059234619 C 157.1364135742188 14.60227203369141 156.7573394775391 15.75749015808105 156.1081237792969 16.71542549133301 L 146.7095947265625 28.83444595336914 C 145.779296875 29.90547180175781 144.4074401855469 30.58178901672363 142.8775634765625 30.58178901672363 C 141.3398132324219 30.58178901672363 139.9625549316406 29.89772987365723 139.0324096679688 28.81771850585938 L 134.1953125 22.58124732971191 L 129.3457641601562 28.83444595336914 C 128.4156188964844 29.90547180175781 127.0437698364258 30.58178901672363 125.5138778686523 30.58178901672363 C 123.9766845703125 30.58178901672363 122.5990219116211 29.89772987365723 121.668586730957 28.81771850585938 L 105.0309982299805 7.365560531616211 L 110.7437744140625 0 L 116.456413269043 7.365560531616211 L 125.589225769043 19.14102745056152 C 125.6576690673828 19.24499130249023 125.7338333129883 19.34328651428223 125.8176193237305 19.43536186218262 C 126.2478561401367 19.90845680236816 126.8684616088867 20.2047233581543 127.5586090087891 20.2047233581543 C 129.4447479248047 20.2047233581543 130.5335998535156 18.10940361022949 129.532958984375 16.56971168518066 C 129.4614868164062 16.45993995666504 129.3812866210938 16.35652923583984 129.2926940917969 16.26058197021484 L 122.3946838378906 7.365560531616211 L 128.1074523925781 0 Z" fill="#004c98" stroke="none" stroke-width="1" stroke-miterlimit="10" stroke-linecap="butt" /></svg>';
